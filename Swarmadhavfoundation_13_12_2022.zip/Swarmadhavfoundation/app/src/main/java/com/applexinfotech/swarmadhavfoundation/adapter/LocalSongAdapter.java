package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.fragment.LocalMusicFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.LOCAL_SONGS;

public class LocalSongAdapter extends RecyclerView.Adapter<LocalSongAdapter.ViewHolder> {
    private final MainActivity mContext;
    private final ArrayList<SubCategoryModel> localSongList;
    private final LocalMusicFragment localMusicFragment;
    PopupMenu menu;

    public LocalSongAdapter(MainActivity mContext, ArrayList<SubCategoryModel> localSongList, LocalMusicFragment localMusicFragment) {
        this.mContext = mContext;
        this.localSongList = localSongList;
        this.localMusicFragment = localMusicFragment;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.subcategory_list_item, parent, false);
        return new LocalSongAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        if (localSongList != null) {
            holder.download.setVisibility(View.GONE);
            holder.play.setVisibility(View.GONE);
            holder.playListName.setTypeface(mContext.getTypeFace());
            holder.playListName.setText(localSongList.get(position).getDownload_name());
            holder.songCount.setTypeface(mContext.getTypeFace());
            String desc = localSongList.get(position).getItem_description() != null ? localSongList.get(position).getItem_description() : localSongList.get(position).getCategory_name() != null ? localSongList.get(position).getCategory_name() : "";
            holder.songCount.setText(desc);
            Picasso.with(mContext).load(localSongList.get(position).getItem_image()).placeholder(R.drawable.no_image).fit().into(holder.cat_image);

            holder.play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    holder.rootView.performClick();
                }
            });

            holder.rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("SONG_PATH", "" + localSongList.get(position).getItem_file());
                    StorageUtil storage = new StorageUtil(getApplicationContext());
                    storeGlobalSongInfo(storage, position);
                        if (MasterActivity.serviceBound && mContext.isPlaying()) {
                            Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                            mContext.sendBroadcast(broadcastIntent);
                        } else if (MasterActivity.serviceBound) {
                            mContext.playSong();
                        }

                    Fragment streaming = new Streaming();
                    Bundle bundle = new Bundle();
                    bundle.putInt("mode", 3);
                    bundle.putString("isFrom", LOCAL_SONGS);
                    bundle.putInt("position", position);
                    bundle.putSerializable("data", localSongList);
                    streaming.setArguments(bundle);
                    mContext.ReplaceFragment(streaming);
                }
            });

            holder.popupMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    if (menu != null) {
                        menu.dismiss();
                    }
                    menu = new PopupMenu(mContext, v);
                    menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch (item.getItemId()) {
                                case R.id.popup_song_set_default_ringtone:
                                    if (localSongList != null && !localSongList.isEmpty() && localSongList.size() > position) {
                                        mContext.startRingdroidEditor(localSongList.get(position));
                                    }
                                    break;
                                case R.id.popup_song_play:
                                    holder.play.performClick();
                                    break;

                            }
                            return false;
                        }
                    });
                    menu.inflate(R.menu.popup_local_song);
                    menu.show();
                }
            });


        }

    }

    private void storeGlobalSongInfo(StorageUtil storage, int position) {
        storage.clearCachedAudioPlaylist();
        storage.storeAudio(localSongList);
        storage.storeAudioIndex(position);
        storage.storeMode(3);
        storage.storeIsPlayingFrom(LOCAL_SONGS);
        mContext.setShuffleMode(false);
        mContext.setRepeatMode(false);
        mContext.setNoOfRepeats(0);
        mContext.setMode(3);
    }

    @Override
    public int getItemCount() {
        return localSongList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView playListName;
        private final TextView songCount;
        final LinearLayout rootView;
        private final ImageView cat_image;
        private final ImageView imagePlay;
        private final ImageButton play;
        private final ImageButton playlist;
        private final ImageButton popupMenu;
        final ImageButton download;
        private TextView tv_title;
        private TextView tv_desc;
        private final TextView tv_duration;
        private String urls;
        private String imgpath;
        private LinearLayout layout_main;
        final ProgressBar downloadProgress;

        ViewHolder(View itemView) {
            super(itemView);
            cat_image = itemView.findViewById(R.id.image);
            play = itemView.findViewById(R.id.play);
            download = itemView.findViewById(R.id.download);
            playlist = itemView.findViewById(R.id.add_to_playlist);
            popupMenu = itemView.findViewById(R.id.popup_menu);
            playListName = itemView.findViewById(R.id.tv_title);
            songCount = itemView.findViewById(R.id.tv_desc);
            tv_duration = itemView.findViewById(R.id.tv_duration);
            rootView = itemView.findViewById(R.id.layout_main);
            downloadProgress = itemView.findViewById(R.id.download_progress_normal);
            imagePlay = itemView.findViewById(R.id.img_play);
        }
    }


}
