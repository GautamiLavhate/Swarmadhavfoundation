package com.applexinfotech.swarmadhavfoundation.helpers;

import android.view.View;

/**
 * Created by JD Android on 11-Aug-18.
 */

public interface OnItemClickListener<T> {
    void onItemClick(View v, int position, T t);
}
