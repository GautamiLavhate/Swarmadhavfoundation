package com.applexinfotech.swarmadhavfoundation.neavigation;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ExpandableListView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import com.applexinfotech.swarmadhavfoundation.LoginActivity;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.downloadvedio.DownloadsMainVedioFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.AboutUs;
import com.applexinfotech.swarmadhavfoundation.fragment.DashBoardFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.DownloadsMainFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.Notification;
import com.applexinfotech.swarmadhavfoundation.fragment.PlaylistFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.ProfileDetailFragment;
import com.applexinfotech.swarmadhavfoundation.vedio.HomeFragmentVedio;
import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.PlaylistVedioFragment;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import static android.view.Gravity.START;
import static com.facebook.FacebookSdk.getApplicationContext;

public class NavigationDrawerFragment extends MasterFragment {

    private static final String STATE_SELECTED_POSITION = "selected_navigation_drawer_position";
    private NavigationDrawerCallbacks mCallbacks;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private ExpandableListView mDrawerListView;
    private View mFragmentContainerView;
    private int mCurrentSelectedPosition = 0;
    private MainActivity mContext;
    private int lastExpandedPosition = -1;
    ArrayList<String> groupItem = new ArrayList<String>();
    ArrayList<Object> childItem = new ArrayList<Object>();
    List<String> expandableListTitle;
    HashMap<String, List<String>> expandableListDetail;
    SessionManager sessionManager;
    Button btnNO,btnYes;

    public NavigationDrawerFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onActivityCreated (Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // Indicate that this fragment would like to influence the set of actions in the action bar.
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mDrawerListView = (ExpandableListView) inflater.inflate(
                R.layout.drawer_drawer, container, false);

        mDrawerListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectItem(position);
            }
        });
        mContext = (MainActivity) getMasterActivity();
        sessionManager=new SessionManager(getMasterActivity());

        expandableListDetail = ExpandableListDataPump.getData();
        expandableListTitle = new ArrayList<String>(expandableListDetail.keySet());

        ExpandableListAdapter expandableListAdapter=new ExpandableListAdapter(mContext, expandableListTitle, expandableListDetail);
        mDrawerListView.setAdapter(expandableListAdapter);
        expandableListAdapter.notifyDataSetChanged();


        mDrawerListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                if(lastExpandedPosition != -1 && groupPosition != lastExpandedPosition) {
                    mDrawerListView.collapseGroup(lastExpandedPosition);
                }
                lastExpandedPosition = groupPosition;
            }
        });


        mDrawerListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @SuppressLint("WrongConstant")
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                boolean retVal = true;

                    if (groupPosition == ExpandableListAdapter.ITEM1) {
                        Fragment homeFragment = new DashBoardFragment();
                        mContext.ReplaceFragment(homeFragment);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                    } else if (groupPosition == ExpandableListAdapter.ITEM2) {
                        retVal = false;
                    } else if (groupPosition == ExpandableListAdapter.ITEM3) {
                        retVal = false;
                    } else if (groupPosition == ExpandableListAdapter.ITEM4) {
                        Fragment NotFragment = new Notification();
                        mContext.ReplaceFragment(NotFragment);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                    } else if (groupPosition == ExpandableListAdapter.ITEM5) {
                        Fragment uinFragment = new ProfileDetailFragment();
                        mContext.ReplaceFragment(uinFragment);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                    } else if (groupPosition == ExpandableListAdapter.ITEM6) {
                        Fragment aboutus = new AboutUs();
                        mContext.ReplaceFragment(aboutus);
                        mDrawerLayout.closeDrawer(START);

                    } else if (groupPosition == ExpandableListAdapter.ITEM7) {
                        final AlertDialog.Builder alert_logout=new AlertDialog.Builder(mContext,R.style.NewCustomAlertDialog);
                        final View custom_logout=getLayoutInflater()
                                .inflate(R.layout.custom_confirm_logout,null);
                        alert_logout.setView(custom_logout);
                        //add a button
                        btnNO=custom_logout.findViewById(R.id.btnNo);
                        btnYes=custom_logout.findViewById(R.id.btnYes);
                        final AlertDialog alertDialog=alert_logout.create();
                        btnNO.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                   alertDialog.dismiss();
//                                Fragment homeFragment = new DashBoardFragment();
//                                mContext.ReplaceFragment(homeFragment);
//                                mDrawerLayout.closeDrawer(START);
                            }
                        });
                        btnYes.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                postlogout();
                                mDrawerLayout.closeDrawer(START);
                            }
                        });
                        alertDialog.show();
                        alertDialog.setCancelable(false);

//                        alert_logout.setCancelable(true)
//                                .create()
//                                .show();
//                        AlertDialog.Builder builder = new AlertDialog.Builder(
//                                mContext);
//                        builder.setTitle("Alert....!");
//                        builder.setMessage("Confirm Logout")
//                                .setCancelable(false)
//                                .setPositiveButton("Yes",
//                                        new DialogInterface.OnClickListener() {
//                                            public void onClick(DialogInterface dialog,
//                                                                int id) {
//                                                postlogout();
//                                                mDrawerLayout.closeDrawer(START);
//                                            }
//                                        })
//                                .setNegativeButton("No",
//                                        new DialogInterface.OnClickListener() {
//                                            public void onClick(DialogInterface dialog,
//                                                                int id) {
//                                                dialog.cancel();
//                                            }
//                                        });
//                        AlertDialog alert = builder.create();
//                        alert.show();

                    }
                v.setSelected(false);
                return retVal;
            }
        });

        mDrawerListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @SuppressLint("WrongConstant")
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                if (groupPosition == ExpandableListAdapter.ITEM2) {
                    if (childPosition == ExpandableListAdapter.SUBITEM1_1) {

                        mContext.ReplaceFragment(new HomeFragment());
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                        mDrawerListView.collapseGroup(groupPosition);

                    }
                    else if (childPosition == ExpandableListAdapter.SUBITEM1_2) {

                        Fragment playlists = new PlaylistFragment();
                        mContext.ReplaceFragment(playlists);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                        mDrawerListView.collapseGroup(groupPosition);

                    }
                    else if (childPosition == ExpandableListAdapter.SUBITEM1_3) {

                        Fragment Downloads = new DownloadsMainFragment();
                        mContext.ReplaceFragment(Downloads);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                        mDrawerListView.collapseGroup(groupPosition);

                    }


                } else if (groupPosition == ExpandableListAdapter.ITEM3) {

                    if (childPosition == ExpandableListAdapter.SUBITEM2_1) {

                        mContext.ReplaceFragment(new HomeFragmentVedio());
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                        mDrawerListView.collapseGroup(groupPosition);

                    }
                    else if (childPosition == ExpandableListAdapter.SUBITEM2_2) {

                        Fragment playlists = new PlaylistVedioFragment();
                        mContext.ReplaceFragment(playlists);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                        mDrawerListView.collapseGroup(groupPosition);

                    }
                    else if (childPosition == ExpandableListAdapter.SUBITEM2_3) {

                        Fragment DownloadsMainVedio = new DownloadsMainVedioFragment();
                        mContext.ReplaceFragment(DownloadsMainVedio);
                        mDrawerLayout.closeDrawer(START);
                        v.setSelected(true);
                        mDrawerListView.collapseGroup(groupPosition);

                    }
                }
                v.setSelected(false);
                return true;
            }
        });

        mDrawerListView.setItemChecked(mCurrentSelectedPosition, true);
        return mDrawerListView;
    }

    public void showAlertDialog(){}

    public boolean isDrawerOpen() {
        return mDrawerLayout != null && mDrawerLayout.isDrawerOpen(mFragmentContainerView);
    }

    /**
     * Users of this fragment must call this method to set up the navigation drawer interactions.
     *
     * @param fragmentId   The android:id of this fragment in its activity's layout.
     * @param drawerLayout The DrawerLayout containing this fragment's UI.
     */
    public void setUp(int fragmentId, DrawerLayout drawerLayout) {
        mFragmentContainerView = mContext.findViewById(fragmentId);
        mDrawerLayout = drawerLayout;

        // set a custom shadow that overlays the main content when the drawer opens
        mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);
        // set up the drawer's list view with items and click listener

    }

    private void selectItem(int position) {
        mCurrentSelectedPosition = position;
        if (mDrawerListView != null) {
            mDrawerListView.setItemChecked(position, true);
        }
        if (mDrawerLayout != null) {
            mDrawerLayout.closeDrawer(mFragmentContainerView);
        }
        if (mCallbacks != null) {
            mCallbacks.onNavigationDrawerItemSelected(position);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            Activity a;

            if (context instanceof Activity){
                a=(Activity) context;
                mCallbacks = (NavigationDrawerCallbacks) a;
            }
        } catch (ClassCastException e) {
            throw new ClassCastException("Activity must implement NavigationDrawerCallbacks.");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SELECTED_POSITION, mCurrentSelectedPosition);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Forward the new configuration the drawer toggle component.
        if (mDrawerToggle != null) mDrawerToggle.onConfigurationChanged(newConfig);
       // mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // If the drawer is open, show the global app actions in the action bar. See also
        // showGlobalContextActionBar, which controls the top-left area of the action bar.
        if (mDrawerLayout != null && isDrawerOpen()) {
            //inflater.inflate(R.menu.menu_main, menu);
          //  showGlobalContextActionBar();
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

    /**
     * Per the navigation drawer design guidelines, updates the action bar to show the global app
     * 'context', rather than just what's in the current screen.
     */
    private void showGlobalContextActionBar() {
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);

    }

    private ActionBar getActionBar() {
        return ((MainActivity) getActivity()).getSupportActionBar();
    }

    /**
     * Callbacks interface that all activities using this fragment must implement.
     */
    public static interface NavigationDrawerCallbacks {
        /**
         * Called when an item in the navigation drawer is selected.
         */
        void onNavigationDrawerItemSelected(int position);
    }

    private void postlogout() {
        mContext.showWaitIndicator(true);
        String mobile_IDst=sessionManager.getKEY_mobile();

        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.mobile_ID,mobile_IDst));
        dishRequest.sendRequest(Constants.API_Logout,
                carData, catCallback);
    }

    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("Logout", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    String response_message=jObject.getString("response_message");
                    if (status.equalsIgnoreCase("1")) {
                        ToastUtil.showLongToastMessage(getMasterActivity(),response_message);
                        sessionManager.logoutUser();
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        mContext.finish();

                    }else{
                        mContext.showWaitIndicator(false);
                        ToastUtil.showLongToastMessage(getMasterActivity(),response_message);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);

        }
    };
}
