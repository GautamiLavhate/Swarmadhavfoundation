package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.PlayListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.NotificationRecord;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;

import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_PLAYLIST;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.IS_FROM;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.PLAYLIST_ID;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2018.
 */
public class PlaylistFragment extends MasterFragment implements OnItemClickListener {
    MainActivity mContext;
    ListView listView_notification;
    ArrayList<NotificationRecord> notif = new ArrayList<>();
    ArrayList<Playlist> playList;
    private RealmHelper realmHelper;
    private PlayListAdapter playListAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.add_to_playlist_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.playlists));
        realmHelper = new RealmHelper();


        Button newPlaylist = view.findViewById(R.id.new_playlist);
        RecyclerView playlistRecycler = view.findViewById(R.id.playlist_recycler);
        LinearLayout noPlaylist = view.findViewById(R.id.noItemFound);
        Button close = view.findViewById(R.id.close);
        newPlaylist.setVisibility(View.GONE);
        close.setVisibility(View.GONE);
        playList = new ArrayList<>();
        playList = realmHelper.getAllPlaylist();
        if (playList != null && !playList.isEmpty()) {
            noPlaylist.setVisibility(View.GONE);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            playlistRecycler.setLayoutManager(linearLayoutManager);
            playListAdapter = new PlayListAdapter(mContext, playList, this, null, false);
            playlistRecycler.setAdapter(playListAdapter);
        } else {
            noPlaylist.setVisibility(View.VISIBLE);
            playlistRecycler.setVisibility(View.GONE);
        }


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });
    }

    @Override
    public void onItemClick(View v, int position, Object o) {
        if (v.getId() == R.id.root_playlist) {
            if (playList != null && !playList.isEmpty() && playList.size() > position) {
                MasterActivity.songListWithAd = new ArrayList();
                SongsList fragment = new SongsList();
                Bundle bundle = new Bundle();
                bundle.putString(IS_FROM, FROM_PLAYLIST);
                bundle.putInt(PLAYLIST_ID, playList.get(position).getId());
                bundle.putString("Type", playList.get(position).getType());
                fragment.setArguments(bundle);
                mContext.ReplaceFragment(fragment);
            }
        } else if (v.getId() == R.id.delete_playlist) {
            if (playList != null && !playList.isEmpty() && playList.size() > position) {
                StorageUtil storage = new StorageUtil(getApplicationContext());
                int currentId = storage.loadCurrentPlaylistId();
                int mode=storage.loadMode();
                if (mode == 2 &&  currentId!= -1) {
                    int selectedId = playList.get(position).getId();
                    if (currentId == selectedId) {
                        Toast.makeText(mContext, R.string.can_not_remove_playlist, Toast.LENGTH_SHORT).show();
                    } else {
                        showDeleteAlert(position);
                    }
                } else {
                    showDeleteAlert(position);
                }
            }
        }
    }

    private void showDeleteAlert(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

        builder.setTitle(R.string.confirm);
        builder.setMessage(R.string.remove_playlist);

        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog
                deletePlaylist(position);
                dialog.dismiss();
            }
        });

        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    private void deletePlaylist(int position) {
        if (playList != null && playListAdapter != null && !playList.isEmpty() && playList.size() > position) {
            realmHelper.deletePlaylist(playList.get(position));
            playList.remove(position);
            playListAdapter.notifyDataSetChanged();
        }

    }
}
