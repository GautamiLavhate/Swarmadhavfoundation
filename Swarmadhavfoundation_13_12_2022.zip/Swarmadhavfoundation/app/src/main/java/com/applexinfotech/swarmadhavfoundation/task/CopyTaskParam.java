package com.applexinfotech.swarmadhavfoundation.task;

import com.github.mjdev.libaums.fs.UsbFile;

import java.io.File;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 23/08/15.
 */
public class CopyTaskParam {
    public UsbFile from;
    public File to;
    public int position;
}
