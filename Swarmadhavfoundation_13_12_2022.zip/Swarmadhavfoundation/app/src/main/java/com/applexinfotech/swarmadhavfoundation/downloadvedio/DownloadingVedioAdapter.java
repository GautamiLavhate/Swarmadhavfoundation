package com.applexinfotech.swarmadhavfoundation.downloadvedio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.VideoPlayer;
import com.bumptech.glide.Glide;

import java.util.ArrayList;


/**
 * Created by Adite on 03-01-2016.
 */
public class DownloadingVedioAdapter extends ArrayAdapter<SubCategoryModel> {
    private final String fragmentTag;
    private RealmHelper realmHelper;
    private LayoutInflater layoutInflater;
    public ArrayList<SubCategoryModel> mItem;
    String categoryImage;
    public MainActivity mContext;
    private OnItemClickListener mListener;
    private SubCategoryModel selectedObject;


    int resource;

    private String fileName, imagename, file_id;

    private ProgressDialog pDialog;

    private Typeface font;
    private HomeModel homeModel;
    public static ArrayList<SongModel> songsID = new ArrayList<>();
    int pos;
    private String aDataid;
    private String categoryImageName;

    public static class ViewHolder {

        private ImageView cat_image, imagePlay;
        private ImageButton play;
        public ImageButton download;
        private TextView tv_title, tv_desc, tv_duration,tv_youtube_label;
        private String urls;
        private String imgpath;
        private LinearLayout layout_main,linearlayoutvedio;
        public ProgressBar downloadProgress,downloadProgressCircular;
        public TextView tv;
        public  ImageButton close;
        public LinearLayout linearLayoutVideo;

    }

    public DownloadingVedioAdapter(MainActivity context, int resource, ArrayList<SubCategoryModel> list, HomeModel homeModel, String fragmentTag) {
        super(context, resource);
        mContext = context;
        this.mItem = list;
        this.resource = resource;
        this.homeModel = homeModel;
        this.fragmentTag = fragmentTag;
        font = Typeface.createFromAsset(mContext.getAssets(), "ProximaNova-Light.otf");
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //Get path of song name
        realmHelper = new RealmHelper();
        songsID = realmHelper.retrieveVideoIdListDEmo();

    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    public int getCount() {
        return mItem.size();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        final ViewHolder mViewHolder;
        LayoutInflater inflater = (LayoutInflater) (mContext).getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        try {

            if (itemView == null) {

                itemView = inflater.inflate(R.layout.subcategory_list_itemvedio, null, true);

                mViewHolder = new ViewHolder();

                mViewHolder.cat_image = (ImageView) itemView.findViewById(R.id.image);

                mViewHolder.play = (ImageButton) itemView.findViewById(R.id.play);
                mViewHolder.download = (ImageButton) itemView.findViewById(R.id.download);

                mViewHolder.tv_title = (TextView) itemView.findViewById(R.id.tv_title);
                mViewHolder.tv_desc = (TextView) itemView.findViewById(R.id.tv_desc);
                mViewHolder.tv_duration = (TextView) itemView.findViewById(R.id.tv_duration);
                mViewHolder.tv_youtube_label = (TextView) itemView.findViewById(R.id.label_youTube);

                mViewHolder.layout_main = (LinearLayout) itemView.findViewById(R.id.layout_main);
                mViewHolder.downloadProgress = itemView.findViewById(R.id.download_progress_normal);
                mViewHolder.downloadProgressCircular=itemView.findViewById(R.id.circularProgressbar);
                mViewHolder.tv=itemView.findViewById(R.id.tv);
                mViewHolder.close=itemView.findViewById(R.id.img_btn_close);
                mViewHolder.linearLayoutVideo=itemView.findViewById(R.id.linearLayoutVideo);
                mViewHolder.imagePlay = itemView.findViewById(R.id.img_play);
                mViewHolder.linearlayoutvedio= itemView.findViewById(R.id.linearlayoutvedio);
                itemView.setTag(mViewHolder);

            } else {
                mViewHolder = (ViewHolder) itemView.getTag();
            }
            mViewHolder.tv_youtube_label.setVisibility(View.GONE);

            if (mItem.get(position) != null) {
                String videost = mItem.get(position).getVideo_url();
                if (!videost.equals("null")) {
                    mViewHolder.linearlayoutvedio.setVisibility(View.VISIBLE);
                    mViewHolder.download.setVisibility(View.GONE);
                    //mViewHolder.tv_title.setTypeface(font);
                    mViewHolder.tv_desc.setTypeface(font);
                    mViewHolder.tv_duration.setTypeface(font);

                    mViewHolder.tv_title.setText(mItem.get(position).getItem_name());
                    mViewHolder.tv_desc.setText(mItem.get(position).getItem_description());


                    Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                    mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    mViewHolder.download.setImageDrawable(mDrawable);
                    Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                    arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    mViewHolder.play.setImageDrawable(arrowDrawable);

                    /*if (mItem.get(position).getVideo_url().https) {
                        Picasso.with(mContext).load(mItem.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.cat_image);

                    } else {
                        try {
                            Bitmap bitmap = BitmapFactory.decodeFile(mItem.get(position).getItem_image());
                            mViewHolder.cat_image.setImageBitmap(bitmap);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }*/

                    Glide.with(mContext).load(mItem.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.cat_image);


                    mViewHolder.play.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mViewHolder.layout_main.performClick();
                        }
                    });

                    mViewHolder.imagePlay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mViewHolder.layout_main.performClick();
                        }
                    });
                    mViewHolder.layout_main.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mContext.player != null) {
                                if (mContext.isPlaying()) {
                                    mContext.pauseSong();
                                    ((MainActivity) mContext).bottum_layout.setVisibility(View.GONE);
                                }
                            }
                            Utilities.hideKeyboard(mContext);
                            StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                            storage.clearCachedAudioPlaylist();
                            storage.storeAudio(mItem);
                            storage.storeAudioIndex(position);
                            storage.storeMode(0);
                            mContext.setMode(0);
                            storage.storeIsPlayingFrom("Category");
                            Intent intent = new Intent(mContext, VideoPlayer.class);
                            mContext.startActivity(intent);

                        }
                    });


                }else {
                    mViewHolder.linearlayoutvedio.setVisibility(View.GONE);
                    mViewHolder.tv_title.setText(null);
                    mViewHolder.tv_desc.setText(null);
                }
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        return itemView;
    }

}