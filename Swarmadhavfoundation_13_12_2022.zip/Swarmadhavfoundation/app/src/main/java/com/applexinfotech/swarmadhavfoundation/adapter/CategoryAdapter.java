package com.applexinfotech.swarmadhavfoundation.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.AddPlaylistVedioDialog;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.CircularImageView;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.ClickGuard;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.fragment.AddPlaylistDialog;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.VideoPlayer;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.CATEGORY;


/**
 * Created by JD(jikadrajaydeep@gmail.com) on 03-01-2016.
 */
public class CategoryAdapter extends ArrayAdapter<SubCategoryModel> {
    private final String fragmentTag;
    private final RealmHelper realmHelper;
    private final LayoutInflater layoutInflater;
    private final ArrayList<SubCategoryModel> mItem;
    String categoryImage;
    private final MainActivity mContext;
    private OnItemClickListener mListener;
    private SubCategoryModel selectedObject;


    private final int resource;

    private String fileName, imagename, file_id;

    private ProgressDialog pDialog;

    private final Typeface font;
    private final HomeModel homeModel;
    private static ArrayList<String> songsID = new ArrayList<>();
    int pos;
    private String aDataid;
    private String categoryImageName;
    private PopupMenu menu;

    public static class ViewHolder {

        private CircularImageView cat_image;
        private ImageButton play, playlist, popupMenu;
        ImageButton download;
        private TextView tv_title, tv_desc, tv_duration;
        private String urls;
        private String imgpath;
        private LinearLayout layout_main;
        ProgressBar downloadProgress;
        ImageButton share;
    }

    public CategoryAdapter(MainActivity context, int resource, ArrayList<SubCategoryModel> list, HomeModel homeModel, String fragmentTag) {
        super(context, resource);
        mContext = context;
        this.mItem = list;
        this.resource = resource;
        this.homeModel = homeModel;
        this.fragmentTag = fragmentTag;
        font = Typeface.createFromAsset(mContext.getAssets(), "ProximaNova-Light.otf");
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (fragmentTag.equalsIgnoreCase("com.applex.swarsageetmala.fragment.CategoryList")) {
            for (SubCategoryModel item : mItem) {
                if (homeModel != null) {
                    if (homeModel.getCategory_id() != null) {
                        item.setCategory_id(homeModel.getCategory_id());
                        item.setCategory_image(homeModel.getCategory_image());
                        item.setCategory_name(homeModel.getCategory_name());
                    }
                }

            }
        }
        //Get path of song name
        realmHelper = new RealmHelper();

    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    public int getCount() {
        return mItem.size();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        final ViewHolder mViewHolder;
        LayoutInflater inflater = (LayoutInflater) (mContext).getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //Get path of song name
        songsID = new ArrayList<>();
        songsID = realmHelper.retrieveSongIdList();
        try {

            if (itemView == null) {

                itemView = inflater.inflate(R.layout.subcategory_list_item, null, true);

                mViewHolder = new ViewHolder();

                mViewHolder.cat_image = itemView.findViewById(R.id.image);

                mViewHolder.play = itemView.findViewById(R.id.play);
                mViewHolder.download = itemView.findViewById(R.id.download);
                mViewHolder.share = itemView.findViewById(R.id.share_download);
                mViewHolder.playlist = itemView.findViewById(R.id.add_to_playlist);
                mViewHolder.popupMenu = itemView.findViewById(R.id.popup_menu);


                mViewHolder.tv_title = itemView.findViewById(R.id.tv_title);
                mViewHolder.tv_desc = itemView.findViewById(R.id.tv_desc);
                mViewHolder.tv_duration = itemView.findViewById(R.id.tv_duration);

                mViewHolder.layout_main = itemView.findViewById(R.id.layout_main);
                mViewHolder.downloadProgress = itemView.findViewById(R.id.download_progress_normal);

                itemView.setTag(mViewHolder);

            } else {
                mViewHolder = (ViewHolder) itemView.getTag();
            }

            if (mItem.get(position) != null) {
                mViewHolder.playlist.setVisibility(View.GONE);
                //mViewHolder.tv_title.setTypeface(font);
                mViewHolder.tv_desc.setTypeface(font);
                mViewHolder.tv_duration.setTypeface(font);

                mViewHolder.tv_title.setText(mItem.get(position).getItem_name());
                mViewHolder.tv_desc.setText(mItem.get(position).getItem_description());


                Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                mViewHolder.download.setImageDrawable(mDrawable);
                Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                mViewHolder.play.setImageDrawable(arrowDrawable);
                Drawable shareDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_share_new);
                shareDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                mViewHolder.share.setImageDrawable(shareDrawable);
                mViewHolder.download.setVisibility(View.GONE);

                /*if (InternetStatus.isInternetOn(mContext)) {
                    Picasso.with(mContext).load(mItem.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.cat_image);

                } else {
                    try {
                        Bitmap bitmap = BitmapFactory.decodeFile(mItem.get(position).getItem_image());
                        if(bitmap!=null){
                            mViewHolder.cat_image.setImageBitmap(bitmap);
                        }else {
                            Picasso.with(mContext).load(mItem.get(position).getItem_image()).placeholder(R.drawable.no_image).fit().into(mViewHolder.cat_image);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }*/

                Glide.with(mContext).load(mItem.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.cat_image);

                mViewHolder.popupMenu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        if (menu != null) {
                            menu.dismiss();
                        }
                        menu = new PopupMenu(mContext, v);
                        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.popup_song_play:
                                        mViewHolder.layout_main.performClick();
                                        break;
                                    case R.id.popup_song_addto_playlist:
                                        if (mItem != null && !mItem.isEmpty() && mItem.size() > position) {
                                            String videoSt=mItem.get(position).getVideo_url();
                                            if(videoSt.equals("null")) {
                                                FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("SearchFragment",  mItem.get(position),"Audio");
                                                infoDialog.setCancelable(false);
                                                infoDialog.show(fragmentManager, "Dialog");
                                            }else {
                                                FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                AddPlaylistVedioDialog infoDialog = AddPlaylistVedioDialog.newInstance("SearchFragment",  mItem.get(position),"Vedio");
                                                infoDialog.setCancelable(false);
                                                infoDialog.show(fragmentManager, "Dialog");
                                            }
                                        }
                                        break;
                                }
                                return false;
                            }
                        });
                        menu.inflate(R.menu.popup_song);
                        menu.show();
                    }
                });

                mViewHolder.play.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mViewHolder.layout_main.performClick();
                    }
                });

                mViewHolder.layout_main.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SubCategoryModel selectedModel=mItem.get(position);
                        String videoUrl = selectedModel.getVideo_url();

                        if(videoUrl.equals("null")) {

                            StorageUtil storage = new StorageUtil(getApplicationContext());
                            if (storage.loadAudio() != null) {
                                storeGlobalSongInfo(storage, position);
                                if (MasterActivity.serviceBound && mContext.isPlaying()) {
                                    Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                                    mContext.sendBroadcast(broadcastIntent);
                                } else if (MasterActivity.serviceBound) {
                                    mContext.playSong();
                                }

                            } else if (MasterActivity.serviceBound) {
                                storeGlobalSongInfo(storage, position);
                                mContext.playSong();
                            }


                            Fragment investProgramDetail = new Streaming();
                            MainActivity.AudioType = "MainAudio";
                            Bundle bundle = new Bundle();
                            bundle.putString("isFrom", CATEGORY);
                            bundle.putInt("mode", 0);
                            bundle.putSerializable("data", mItem);
                            bundle.putInt("position", position);
                            bundle.putSerializable("CAT_ID", homeModel);

                            investProgramDetail.setArguments(bundle);
                            mContext.ReplaceFragment(investProgramDetail);
                        }else {
                            Utilities.hideKeyboard(mContext);
                            if (Utils.isYoutubeLink(videoUrl)) {
                                //mContext.playYoutubeVideo(selectedModel);
                            } else {
                                int audIndex = 0;
                                ArrayList<SubCategoryModel> filteredList = new ArrayList<>();
                                for (SubCategoryModel subCategoryModel : mItem) {
                                    if (!Utils.isYoutubeLink(subCategoryModel.getVideo_url())) {
                                        filteredList.add(subCategoryModel);
                                    }
                                }
                                for (int i = 0; i < filteredList.size(); i++) {
                                    String id = filteredList.get(i).getItem_id();
                                    if (selectedModel.getItem_id().equals(id)) {
                                        audIndex = i;
                                        break;
                                    }
                                }
                                StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                                storage.clearCachedAudioPlaylist();
                                storage.storeAudio(filteredList);
                                storage.storeAudioIndex(audIndex);
                                storage.storeMode(0);
                                mContext.setMode(0);
                                storage.storeIsPlayingFrom("Category");
                                Intent intent = new Intent(mContext, VideoPlayer.class);
                                mContext.startActivity(intent);
                            }
                        }
                    }
                });


                if (!mItem.get(0).getItem_file().startsWith("https")) {
                    mViewHolder.download.setVisibility(View.GONE);
                    mItem.get(position).setDownloaded(true);
                } else {
                    //mViewHolder.download.setVisibility(View.VISIBLE);
                    //  mViewHolder.download.setBackgroundResource(R.drawable.download);

                    Drawable mDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                    mDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    mViewHolder.download.setImageDrawable(mDrawable1);
                    if (songsID != null) {

                        if (songsID.size() > 0) {

                            for (int i = 0; i < songsID.size(); i++) {

                                if (mItem.get(position).getItem_id().equalsIgnoreCase(songsID.get(i))) {
                                    mItem.get(position).setDownloaded(true);
                                    Drawable arrowDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_download_complete);

                                    arrowDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                                    mViewHolder.download.setBackgroundResource(0);
                                    mViewHolder.download.setImageDrawable(arrowDrawable1);


                                    // mViewHolder.download.setBackgroundResource(R.drawable.download_finished);
                                    mViewHolder.download.setClickable(false);
                                    ClickGuard.guard(mViewHolder.download);
                                    mViewHolder.download.setOnClickListener(null);
                                    break;
                                } else {
                                    mItem.get(position).setDownloaded(false);
                                }
                            }
                        }
                    }

                }

                mViewHolder.download.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mListener != null) {
                            selectedObject = mItem.get(position);
                            if (selectedObject.getCategory_id() == null) {
                                if (homeModel != null) {
                                    if (homeModel.getCategory_id() != null) {
                                        selectedObject.setCategory_id(homeModel.getCategory_id());
                                        selectedObject.setCategory_image(homeModel.getCategory_image());
                                        selectedObject.setCategory_name(homeModel.getCategory_name());
                                    }
                                }
                            }
                            if (!selectedObject.isDownloaded) {
                                mListener.onItemClick(v, position, selectedObject);
                                mViewHolder.download.setClickable(false);
                                ClickGuard.guard(mViewHolder.download);
                                selectedObject.setDownloaded(true);
                            } else {
                                ToastUtil.showShortToastMessage(getApplicationContext(), "Already Downloading.." + selectedObject.getDownload_name());
                            }
                        }
                    }
                });

                mViewHolder.share.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // shareSong(position);
                    }
                });
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        return itemView;
    }

    private void storeGlobalSongInfo(StorageUtil storage, int position) {
        storage.clearCachedAudioPlaylist();
        storage.storeAudio(mItem);
        storage.storeAudioIndex(position);
        storage.storeMode(0);
        storage.storeIsPlayingFrom(CATEGORY);
        mContext.setShuffleMode(false);
        mContext.setRepeatMode(false);
        mContext.setNoOfRepeats(0);
        mContext.setMode(0);
        mContext.stopProgressHandler();
    }

    private void shareSong(int position) {
        String fileName = mItem.get(position).getDownload_name() + ".mp3";
        String path = mItem.get(position).getItem_file();
        String EXTRA_TEXT = "I'm listening to '" + mItem.get(position).getDownload_name() + "' by " + mContext.getString(R.string.app_name) + "! \n" + "Checkout here : " + path;
        String EXTRA_SUBJECT = "'" + mItem.get(position).getDownload_name() + "' from " + mContext.getString(R.string.app_name) + "...";
        Intent share = new Intent(Intent.ACTION_SEND);
        //share.putExtra(Intent.EXTRA_STREAM, photoURI);
        share.putExtra(Intent.EXTRA_TEXT, EXTRA_TEXT);
        share.putExtra(Intent.EXTRA_SUBJECT, EXTRA_SUBJECT);
        //share.setType("audio/*");
        share.setType("text/plain");
        mContext.startActivity(Intent.createChooser(share, "Share with"));

    }
}