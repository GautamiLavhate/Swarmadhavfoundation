package com.applexinfotech.swarmadhavfoundation;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SetPasswordActivity extends MasterActivity {
    private Button ChangePassword;
    private EditText password,confirmpass;
    private String passwordST,confirmpassST;
    private TextView ChangeText;
    private LinearLayout LinerlayourCurrentpassword;
    private ProgressDialog dialog;
    private ImageView NewpasswordImg,Confirmpasswordimg;
    String Userid,mobilenum;
    public SetPasswordActivity(){

    }

    private void launchHomeScreen() {
        startActivity(new Intent(SetPasswordActivity.this, LoginActivity.class));
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changepassword_layout);
        isInternet = InternetStatus.isInternetOn(this);
        ChangeText=findViewById(R.id.ChangeText);
        ChangeText.setText("Set New Password");
        password=findViewById(R.id.Newpassword);
        confirmpass=findViewById(R.id.Confirmpassword);
        NewpasswordImg=findViewById(R.id.NewpasswordImg);
        Confirmpasswordimg=findViewById(R.id.Confirmpasswordimg);
        ChangePassword=findViewById(R.id.Save);
        LinerlayourCurrentpassword=findViewById(R.id.LinerlayourCurrentpassword);

        LinerlayourCurrentpassword.setVisibility(View.GONE);

        Intent intent=getIntent();
        Userid=intent.getStringExtra("SetPss");
        mobilenum=intent.getStringExtra("MobileNume");

        NewpasswordImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){

                    NewpasswordImg.setImageResource(R.drawable.ic_remove_red_eye_black_24dp);
                    //Show Password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    NewpasswordImg.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                    //Hide Password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

        Confirmpasswordimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(confirmpass.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){

                    Confirmpasswordimg.setImageResource(R.drawable.ic_remove_red_eye_black_24dp);
                    //Show Password
                    confirmpass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    Confirmpasswordimg.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                    //Hide Password
                    confirmpass.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });
        isInternet = InternetStatus.isInternetOn(this);
        ChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!password.getText().toString().equalsIgnoreCase("") ||!confirmpass.getText().toString().equalsIgnoreCase(""))
                {
                    if (password.getText().toString()==confirmpass.getText().toString())
                    {
                        Toast.makeText(getApplicationContext(), "Password does not matched", Toast.LENGTH_SHORT).show();
                    }else {

                        passwordST=password.getText().toString();
                        confirmpassST=confirmpass.getText().toString();

                        if (isInternet) {
                            try {
                                postChangePassword();
                            }catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            ToastUtil.showLongToastMessage(getApplicationContext(), getString(R.string.no_internet_connection_found));
                        }

                    }

                }else {
                    Toast.makeText(getApplicationContext(), "Please provide all all details", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }


    private void postChangePassword() {
        dialog=new ProgressDialog(SetPasswordActivity.this);
        dialog.show();


        NetworkRequest dishRequest = new NetworkRequest(this);
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.password_ID,passwordST));
        carData.add(new BasicNameValuePair(Constants.cpassword_ID,confirmpassST));
        carData.add(new BasicNameValuePair(Constants.user_ID,Userid));
        dishRequest.sendRequest(Constants.API_set_password_Sawr, carData, catCallback);
    }


    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {
            dialog.dismiss();
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    String response_message=jObject.getString("response_message");
                    if (status.equalsIgnoreCase("1")) {

                        ToastUtil.showLongToastMessage(getApplicationContext(),response_message);

                        launchHomeScreen();
                        finish();

                       /* prefManager = new PrefManager(getApplicationContext());
                        if (!prefManager.isFirstTimeLaunch()) {
                            launchHomeScreen();
                            finish();
                        }
*/
                    }else{
                        dialog.dismiss();
                        ToastUtil.showLongToastMessage(getApplicationContext(),response_message);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                dialog.dismiss();
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            dialog.dismiss();
        }
    };

    @Override
    public void onBackPressed() {
        postlogout();
        return;
    }


    private void postlogout() {
        dialog=new ProgressDialog(SetPasswordActivity.this);
        dialog.show();
        String mobile_IDst=mobilenum;

        NetworkRequest dishRequest = new NetworkRequest(this);
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.mobile_ID,mobile_IDst));
        dishRequest.sendRequest(Constants.API_Logout,
                carData, catCallback1);
    }

    private final NetworkRequest.NetworkRequestCallback catCallback1 = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            dialog.dismiss();
            try {
                if (response != null) {
                    Log.d("Logout", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    String response_message=jObject.getString("response_message");
                    if (status.equalsIgnoreCase("1")) {
                        launchHomeScreen();

                    }else{
                        dialog.dismiss();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                dialog.dismiss();
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            dialog.dismiss();

        }
    };
}
