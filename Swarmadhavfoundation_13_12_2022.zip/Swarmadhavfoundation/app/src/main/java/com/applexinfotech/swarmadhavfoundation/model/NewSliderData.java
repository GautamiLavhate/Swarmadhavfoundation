package com.applexinfotech.swarmadhavfoundation.model;

public class NewSliderData {
    private String imgUrl;

    public NewSliderData(String imgUrl){
        this.imgUrl=imgUrl;

    }
    public String getImgUrl(){
        return imgUrl;
    }

    public void setImgUrl(String imgUrl){
        this.imgUrl=imgUrl;
    }
}
