package com.applexinfotech.swarmadhavfoundation.vedio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Jaydeep Jikadra on 1/2/2018.
 */
public class HomeVedioAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    private LayoutInflater layoutInflater;
    private final ArrayList<Object> recyclerViewItems;
    public MainActivity mContext;
    private static final int MENU_ITEM_VIEW_TYPE = 0;
    RecyclerView mRecyclerView;
    int resource;
    private final View.OnClickListener mOnClickListener = new MyOnClickListener();

    public HomeVedioAdapter(MainActivity context, int resource, ArrayList<Object> list, RecyclerView recyclerView)
    {
        mContext = context;
        this.recyclerViewItems = list;
        Log.e("noOfItem", String.valueOf(recyclerViewItems.size()));
        this.resource = resource;
        mRecyclerView=recyclerView;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getItemViewType(int position) {
        return MENU_ITEM_VIEW_TYPE;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case MENU_ITEM_VIEW_TYPE:
            default:
                View menuItemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item, parent, false);
                menuItemLayoutView.setOnClickListener(mOnClickListener);
                return new MenuItemViewHolder(menuItemLayoutView);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case MENU_ITEM_VIEW_TYPE:
            default:
                MenuItemViewHolder menuItemHolder = (MenuItemViewHolder) holder;
                HomeModel content = (HomeModel) recyclerViewItems.get(position);
                String TypeHMSt = content.getTypeHm();
                if (TypeHMSt.equals("Video")) {
                    menuItemHolder.folderLinearLayout.setVisibility(View.VISIBLE);
                    menuItemHolder.text_cat_name.setTypeface(mContext.getTypeFace());
                    menuItemHolder.text_cat_name.setText(content.getCategory_name());

                    if (InternetStatus.isInternetOn(mContext)) {
                        Picasso.with(mContext).load(content.getCategory_image()).into(menuItemHolder.imageView_cat);
                    } else {
                        if (content.getCategory_image() != null) {
                            Bitmap bitmap = BitmapFactory.decodeFile(content.getCategory_image());
                            menuItemHolder.imageView_cat.setImageBitmap(bitmap);
                        }
                    }
                    break;
                }else {
                    menuItemHolder.folderLinearLayout.setVisibility(View.GONE);
                }
        }
    }

    @Override
    public int getItemCount() {
        return recyclerViewItems.size();
    }


    public class MenuItemViewHolder extends RecyclerView.ViewHolder {
        private final ImageView imageView_cat;
        private final TextView text_cat_name;
        private LinearLayout folderLinearLayout;

        public MenuItemViewHolder(View itemView) {
            super(itemView);
             imageView_cat = (ImageView) itemView.findViewById(R.id.imageView_cat);
             text_cat_name = (TextView) itemView.findViewById(R.id.text_cat_name);
            folderLinearLayout= itemView.findViewById(R.id.folderLinearLayout);
            
        }
    }

    private class MyOnClickListener implements View.OnClickListener {
        private HomeModel homeModel;

        @Override
        public void onClick(View v) {
            int itemPosition = mRecyclerView.getChildLayoutPosition(v);

            if(recyclerViewItems.get(itemPosition) instanceof HomeModel){
                 homeModel = (HomeModel) recyclerViewItems.get(itemPosition);

                mContext.bundle = new Bundle();
                if (InternetStatus.isInternetOn(mContext)) {

                    MasterActivity.songWithAd = new ArrayList<>();
                    String CategorySub=homeModel.getIsSubcategoryAvailable();
                    if(CategorySub.equals("0")){
                        Fragment categoryList = new CategoryFragmentVedio();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("CAT_ID", homeModel);
                        categoryList.setArguments(bundle);
                        mContext.ReplaceFragment(categoryList);
                    }else if(CategorySub.equals("1")){
                        Fragment categoryList = new SubCategoryFolderVideoFragment();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("CAT_ID", homeModel);
                        categoryList.setArguments(bundle);
                        mContext.ReplaceFragment(categoryList);
                    }

                } else {
                    Fragment investProgramDetail = new CategoryFragmentVedio();
                    Bundle bundle = new Bundle();
                    for(int i=0;i<HomeFragmentVedio.realmArray.size();i++){
                        if(HomeFragmentVedio.realmArray.get(i).getCategory_id().equalsIgnoreCase(homeModel.getCategory_id())){
                            bundle.putSerializable("CAT_ID", HomeFragmentVedio.realmArray.get(i));
                            break;
                        }
                    }
                    investProgramDetail.setArguments(bundle);
                    mContext.ReplaceFragment(investProgramDetail);
                }
            }

        }
    }

}
