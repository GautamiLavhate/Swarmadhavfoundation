package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.VideoPlayer;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.CATEGORY;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_ASSETS;
import static com.facebook.FacebookSdk.getApplicationContext;

public class SearchviedoAudioSongListAdapter extends RecyclerView.Adapter<SearchviedoAudioSongListAdapter.MyViewHolder> {

    private final RealmHelper realmHelper;
    final MainActivity mContext;
    final ArrayList<SubCategoryModel> recentlyPlayedList;
    final RecyclerView recentRecycler;
    public ArrayList<String> songsID = new ArrayList<>();
    private OnItemClickListener mListener;
    private SubCategoryModel selectedObject;
    private PopupMenu menu;
    boolean isFromAssets=false;

    public SearchviedoAudioSongListAdapter(MainActivity mContext, ArrayList<SubCategoryModel> recentlyPlayedList, RecyclerView recentRecycler) {
        this.mContext = mContext;
        this.recentlyPlayedList = recentlyPlayedList;
        this.recentRecycler = recentRecycler;
        realmHelper = new RealmHelper();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    @Override
    public SearchviedoAudioSongListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.search_song_video_adapter, parent, false);
        return new SearchviedoAudioSongListAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SearchviedoAudioSongListAdapter.MyViewHolder mViewHolder, final int position) {
        //Get path of song name
        songsID = new ArrayList<>();
        songsID = realmHelper.retrieveSongIdList();

        if (recentlyPlayedList.get(position) != null) {
            mViewHolder.tv_title.setTypeface(mContext.getTypeFace());
            mViewHolder.tv_title.setText(recentlyPlayedList.get(position).getItem_name());
            Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.play);
            arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            mViewHolder.play.setImageDrawable(arrowDrawable);


          //  Picasso.with(mContext).load(recentlyPlayedList.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);

            Glide.with(mContext).load(recentlyPlayedList.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);
/*
            if (InternetStatus.isInternetOn(mContext)) {

                Glide.with(mContext).load(recentlyPlayedList.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);
            } else {
                if (recentlyPlayedList.get(position).getItem_image() != null) {
                    Bitmap bitmap = BitmapFactory.decodeFile(recentlyPlayedList.get(position).getItem_image());
                    Glide.with(mContext).load(bitmap).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);
                }
            }*/


            mViewHolder.play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mViewHolder.layout_main.performClick();
                }
            });

            mViewHolder.layout_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //clear cached playlist
                    //Store Serializable audioList to SharedPreferences
                    SubCategoryModel selectedModel=recentlyPlayedList.get(position);
                    String videoUrl = selectedModel.getVideo_url();

                    if(videoUrl.equals("null")) {

                        StorageUtil storage = new StorageUtil(getApplicationContext());
                        if (storage.loadAudio() != null) {
                            storeGlobalSongInfo(storage, position);
                            if (MasterActivity.serviceBound && mContext.isPlaying()) {
                                Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                                mContext.sendBroadcast(broadcastIntent);
                            } else if (MasterActivity.serviceBound) {
                                mContext.playSong();
                            }

                        } else if (MasterActivity.serviceBound) {
                            storeGlobalSongInfo(storage, position);
                            mContext.playSong();
                        }


                        Fragment investProgramDetail = new Streaming();
                        MainActivity.AudioType="MainAudio";
                        Bundle bundle = new Bundle();
                        bundle.putString("isFrom", CATEGORY);
                        bundle.putInt("mode", isFromAssets ? 4 : 0);  // 4=Assets || 0=category
                        bundle.putSerializable("data", recentlyPlayedList);
                        bundle.putInt("position", position);
                        investProgramDetail.setArguments(bundle);
                        mContext.ReplaceFragment(investProgramDetail);
                    }else {
                        if (mContext.player != null) {
                            if (mContext.isPlaying()) {
                                mContext.pauseSong();
                                ((MainActivity) mContext).bottum_layout.setVisibility(View.GONE);
                            }
                        }
                        Utilities.hideKeyboard(mContext);
                        if (Utils.isYoutubeLink(videoUrl)) {
                           // mContext.no_image(selectedModel);
                        } else {
                            int audIndex = 0;
                            ArrayList<SubCategoryModel> filteredList = new ArrayList<>();
                            for (SubCategoryModel subCategoryModel : recentlyPlayedList) {
                                if (!Utils.isYoutubeLink(subCategoryModel.getVideo_url())) {
                                    filteredList.add(subCategoryModel);
                                }
                            }
                            for (int i = 0; i < filteredList.size(); i++) {
                                String id = filteredList.get(i).getItem_id();
                                if (selectedModel.getItem_id().equals(id)) {
                                    audIndex = i;
                                    break;
                                }
                            }
                            StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                            storage.clearCachedAudioPlaylist();
                            storage.storeAudio(filteredList);
                            storage.storeAudioIndex(audIndex);
                            storage.storeMode(0);
                            mContext.setMode(0);
                            storage.storeIsPlayingFrom("Category");
                            Intent intent = new Intent(mContext, VideoPlayer.class);
                            mContext.startActivity(intent);
                        }
                    }

                }
            });

        }
    }

    private void storeGlobalSongInfo(StorageUtil storage, int position) {
        storage.clearCachedAudioPlaylist();
        storage.storeAudio(recentlyPlayedList);
        storage.storeAudioIndex(position);
        storage.storeMode(isFromAssets?4:0);
        storage.storeIsPlayingFrom(isFromAssets?FROM_ASSETS:CATEGORY);
        mContext.setShuffleMode(false);
        mContext.setRepeatMode(false);
        mContext.setNoOfRepeats(0);
        mContext.setMode(isFromAssets?4:0);
        mContext.stopProgressHandler();
    }


    @Override
    public int getItemCount() {
        return recentlyPlayedList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final ImageView thumbnail;
        private final ImageButton play;
        private final TextView tv_title;
        private final LinearLayout layout_main;
        final CardView parentLayout;

        public MyViewHolder(View itemView) {
            super(itemView);
            thumbnail = itemView.findViewById(R.id.img_thumbnail);
            parentLayout = itemView.findViewById(R.id.card_view);

            play = itemView.findViewById(R.id.img_play);
            tv_title = itemView.findViewById(R.id.tv_title);
            layout_main = itemView.findViewById(R.id.layout_main);

        }
    }

}