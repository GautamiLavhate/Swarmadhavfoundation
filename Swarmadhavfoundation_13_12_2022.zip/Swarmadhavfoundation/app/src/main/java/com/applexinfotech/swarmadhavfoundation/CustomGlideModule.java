package com.applexinfotech.swarmadhavfoundation;

import com.bumptech.glide.module.AppGlideModule;

public class CustomGlideModule extends AppGlideModule {
    @Override

    public boolean isManifestParsingEnabled() {
        return false;
    }
}
