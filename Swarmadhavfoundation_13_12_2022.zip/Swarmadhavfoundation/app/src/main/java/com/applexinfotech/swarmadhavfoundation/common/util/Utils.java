package com.applexinfotech.swarmadhavfoundation.common.util;

import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;

import com.applexinfotech.swarmadhavfoundation.fragment.ExplorerFragment;
import com.github.mjdev.libaums.fs.UsbFile;

import java.io.File;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by JD(jikadrajaydeep@gmail.com) on 23/08/15.
 */
public class Utils {

    public final static File otgViewerPath = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/swarsageetmala");
    public final static File otgViewerCachePath = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/swarsageetmala/cache");
    private static String TAG = "Utils";
    private static boolean DEBUG = false;

    private static final String YOU_TUBE_URL_REGEX= "http(?:s)?://(?:www\\.)?youtu(?:\\.be/|be\\.com/(?:watch\\?v=|v/|embed/|user/(?:[\\w#]+/)+))([^&#?\\n]+)";

    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // The directory is now empty or this is a file so delete it
        return dir.delete();
    }

    public static long getDirSize(File dir) {
        long size = 0;
        for (File file : dir.listFiles()) {
            if (file != null && file.isDirectory()) {
                size += getDirSize(file);
            } else if (file != null && file.isFile()) {
                size += file.length();
            }
        }
        return size;
    }

    // We remove the app's cache folder if threshold is exceeded
    public static void deleteCache(File cachePath) {
        long cacheSize = getDirSize(cachePath);

        if (DEBUG)
            Log.d(TAG, "cacheSize: " + cacheSize);

        if (getDirSize(cachePath) > Constants.CACHE_THRESHOLD) {
            if (DEBUG)
                Log.d(TAG, "Erasing cache folder");

            deleteDir(cachePath);
        }

        deleteDir(otgViewerCachePath);
    }

    public static String getMimetype(File f) {
        if (DEBUG)
            Log.d(TAG, "extension from: " + Uri.fromFile(f).toString().toLowerCase());

        String extension = android.webkit.MimeTypeMap.getFileExtensionFromUrl(Uri
                .fromFile(f).toString().toLowerCase());

        return getMimetype(extension);
    }

    public static String getMimetype(String extension) {
        String mimetype = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                extension);

        if (DEBUG)
            Log.d(TAG, "mimetype is: " + mimetype);

        return mimetype;
    }

    public static Comparator<UsbFile> comparator = new Comparator<UsbFile>() {

        @Override
        public int compare(UsbFile lhs, UsbFile rhs) {

            if (DEBUG)
                Log.d(TAG, "comparator. Sorting by: " + ExplorerFragment.mSortByCurrent);

            switch (ExplorerFragment.mSortByCurrent) {
                case Constants.SORTBY_NAME:
                    return sortByName(lhs, rhs);
                case Constants.SORTBY_DATE:
                    return sortByDate(lhs, rhs);
                case Constants.SORTBY_SIZE:
                    return sortBySize(lhs, rhs);
                default:
                    break;
            }

            return 0;
        }

        int extractInt(String s) {
            int result = 0;
            // return 0 if no digits found
            try {
                String num = s.replaceAll("\\D", "");
                result = num.isEmpty() ? 0 : Integer.parseInt(num);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                return result;
            }
        }

        int checkIfDirectory(UsbFile lhs, UsbFile rhs) {
            if (lhs.isDirectory() && !rhs.isDirectory()) {
                return -1;
            }

            if (rhs.isDirectory() && !lhs.isDirectory()) {
                return 1;
            }

            return 0;
        }

        int sortByName(UsbFile lhs, UsbFile rhs) {
            int result = 0;
            int dir = checkIfDirectory(lhs, rhs);
            if (dir != 0)
                return dir;

            // Check if there is any number
            String lhsNum = lhs.getName().replaceAll("\\D", "");
            String rhsNum = rhs.getName().replaceAll("\\D", "");
            int lhsRes = 0;
            int rhsRes = 0;

            if (!lhsNum.isEmpty() && !rhsNum.isEmpty()) {
                lhsRes = extractInt(lhs.getName());
                rhsRes = extractInt(rhs.getName());
                return lhsRes - rhsRes;
            }

            result = lhs.getName().compareToIgnoreCase(rhs.getName());

            return result;
        }

        int sortByDate(UsbFile lhs, UsbFile rhs) {
            long result = 0;
            int dir = checkIfDirectory(lhs, rhs);
            if (dir != 0)
                return dir;

            result = lhs.lastModified() - rhs.lastModified();

            return (int) result;
        }

        int sortBySize(UsbFile lhs, UsbFile rhs) {
            long result = 0;
            int dir = checkIfDirectory(lhs, rhs);
            if (dir != 0)
                return dir;

            try {
                result = lhs.getLength() - rhs.getLength();
            } catch (Exception e) {
            }

            return (int) result;
        }
    };


    public static boolean isImage(UsbFile entry) {
        if (entry.isDirectory())
            return false;

        try {
            return isImageInner(entry.getName());
        } catch (StringIndexOutOfBoundsException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static boolean isImage(File entry) {
        return isImageInner(entry.getName());
    }
    public static boolean isAudio(File entry) {
        return isAudioInner(entry.getName());
    }
    public static boolean isAudio(UsbFile entry) {
        return isAudioInner(entry.getName());
    }
    private static boolean isAudioInner(String name) {
        boolean result = false;

        int index = name.lastIndexOf(".");

        if (index > 0) {
            String ext = name.substring(index);

            if (ext.equalsIgnoreCase(".mp3")) {
                result = true;
            }

            Log.d(TAG, "isAudioInner " + name + ": " + result);
        }

        return result;
    }
    private static boolean isImageInner(String name) {
        boolean result = false;

        int index = name.lastIndexOf(".");

        if (index > 0) {
            String ext = name.substring(index);

            if (ext.equalsIgnoreCase(".jpg") || ext.equalsIgnoreCase(".png")
                    || ext.equalsIgnoreCase(".jpeg")) {
                result = true;
            }

            Log.d(TAG, "isImageInner " + name + ": " + result);
        }

        return result;
    }

    public static boolean isConfirmButton(KeyEvent event) {
        switch (event.getKeyCode()) {
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                return true;
            default:
                return false;
        }
    }

    public static boolean isMassStorageDevice(UsbDevice device) {
        boolean result = false;

        int interfaceCount = device.getInterfaceCount();
        for (int i = 0; i < interfaceCount; i++) {
            UsbInterface usbInterface = device.getInterface(i);
            Log.i(TAG, "found usb interface: " + usbInterface);

            // we currently only support SCSI transparent command set with
            // bulk transfers only!
            if (usbInterface.getInterfaceClass() != UsbConstants.USB_CLASS_MASS_STORAGE
                    || usbInterface.getInterfaceSubclass() != Constants.INTERFACE_SUBCLASS
                    || usbInterface.getInterfaceProtocol() != Constants.INTERFACE_PROTOCOL) {
                Log.i(TAG, "device interface not suitable!");
                continue;
            }

            // Every mass storage device has exactly two endpoints
            // One IN and one OUT endpoint
            int endpointCount = usbInterface.getEndpointCount();
            if (endpointCount != 2) {
                Log.w(TAG, "inteface endpoint count != 2");
            }

            UsbEndpoint outEndpoint = null;
            UsbEndpoint inEndpoint = null;
            for (int j = 0; j < endpointCount; j++) {
                UsbEndpoint endpoint = usbInterface.getEndpoint(j);
                Log.i(TAG, "found usb endpoint: " + endpoint);
                if (endpoint.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (endpoint.getDirection() == UsbConstants.USB_DIR_OUT) {
                        outEndpoint = endpoint;
                    } else {
                        inEndpoint = endpoint;
                    }
                }
            }

            if (outEndpoint == null || inEndpoint == null) {
                Log.e(TAG, "Not all needed endpoints found!");
                continue;
            }

            result = true;
        }

        return result;
    }

    //vedio

    public static boolean isVideo(File entry) {
        return isVideoInner(entry.getName());
    }
    public static boolean isVideo(UsbFile entry) {
        return isVideoInner(entry.getName());
    }
    private static boolean isVideoInner(String name) {
        boolean result = false;

        int index = name.lastIndexOf(".");

        if (index > 0) {
            String ext = name.substring(index);

            if (ext.equalsIgnoreCase(".mp4") || ext.equalsIgnoreCase(".mov")
                    || ext.equalsIgnoreCase(".flv")) {
                result = true;
            }

            Log.d(TAG, "isVideoInner " + name + ": " + result);
        }

        return result;
    }

    public static boolean isYoutubeLink(String url){
        boolean isLink=false;
        if(url!=null && !url.isEmpty()){
            Pattern pattern = Pattern.compile(YOU_TUBE_URL_REGEX, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(url);
            if (matcher.matches()){
                isLink=true;
            }
        }
        return  isLink;
    }

    public static String extractYTId(String ytUrl) {
        String vId = null;
        Pattern pattern = Pattern.compile(YOU_TUBE_URL_REGEX, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(ytUrl);
        if (matcher.matches()){
            vId = matcher.group(1);
        }
        return vId;
    }
}
