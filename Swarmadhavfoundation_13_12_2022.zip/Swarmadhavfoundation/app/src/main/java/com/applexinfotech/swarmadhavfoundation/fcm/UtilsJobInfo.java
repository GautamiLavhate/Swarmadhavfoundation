package com.applexinfotech.swarmadhavfoundation.fcm;

import android.app.AlarmManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;


import static android.content.Context.JOB_SCHEDULER_SERVICE;

public class UtilsJobInfo {
    private static JobInfo jobInfo = null;

    private static final String TAG = UtilsJobInfo.class.getSimpleName();
    private static AlarmManager manager;

    public static void scheduleJob(Context context, Class<?> cls) {
/*
        Intent alarmIntent = new Intent(context, MyReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, alarmIntent, 0);
        manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Log.w("Tag", "Start Alarm");
        Calendar updateTime = Calendar.getInstance();
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, updateTime.getTimeInMillis(),1000, pendingIntent);*/

        ComponentName componentName = new ComponentName(context, NotificationService.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            jobInfo = new JobInfo.Builder(1, componentName)
                    .setMinimumLatency(14*60*1000) // wait at least
                    .setOverrideDeadline(15*60*1000) // maximum delay
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY) // require unmetered network
                    .setRequiresCharging(false) // we don't care if the device is charging or not
                    .setRequiresDeviceIdle(false)
                    .setPersisted(true)
                    .build();
        } else {
            jobInfo = new JobInfo.Builder(1, componentName)
                    .setPeriodic(15*60*1000)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY) // require unmetered network
                    .setRequiresCharging(false)
                    .setRequiresDeviceIdle(false)
                    .setPersisted(true).build();
        }

        JobScheduler jobScheduler = (JobScheduler) context.getApplicationContext().getSystemService(JOB_SCHEDULER_SERVICE);
            if (jobScheduler != null) {
            jobScheduler.schedule(jobInfo);
        }

    }
}
