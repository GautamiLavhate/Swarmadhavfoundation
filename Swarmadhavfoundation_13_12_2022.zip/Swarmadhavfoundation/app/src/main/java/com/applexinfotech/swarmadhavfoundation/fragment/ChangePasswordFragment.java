package com.applexinfotech.swarmadhavfoundation.fragment;

import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ChangePasswordFragment extends MasterFragment{
    private MainActivity mContext;
    private String mContent;
    private Button ChangePassword;
    private EditText Oladpass,password,confirmpass;
    private String textColor,backgroundColor,OladpassSt,passwordST,confirmpassST;
    private SessionManager sessionManager;
    private ImageView CurrentpasswordImg,NewpasswordImg,Confirmpasswordimg;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.changepassword_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

       // mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle("Change Password");
        mContext = (MainActivity) getMasterActivity();
        Oladpass=view.findViewById(R.id.Currentpassword);
        password=view.findViewById(R.id.Newpassword);
        confirmpass=view.findViewById(R.id.Confirmpassword);
        CurrentpasswordImg=view.findViewById(R.id.CurrentpasswordImg);
        NewpasswordImg=view.findViewById(R.id.NewpasswordImg);
        Confirmpasswordimg=view.findViewById(R.id.Confirmpasswordimg);

        CurrentpasswordImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(Oladpass.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){

                    CurrentpasswordImg.setImageResource(R.drawable.ic_remove_red_eye_black_24dp);
                    //Show Password
                    Oladpass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    CurrentpasswordImg.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                    //Hide Password
                    Oladpass.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

        NewpasswordImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){

                    NewpasswordImg.setImageResource(R.drawable.ic_remove_red_eye_black_24dp);
                    //Show Password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    NewpasswordImg.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                    //Hide Password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

        Confirmpasswordimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(confirmpass.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){

                    Confirmpasswordimg.setImageResource(R.drawable.ic_remove_red_eye_black_24dp);
                    //Show Password
                    confirmpass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    Confirmpasswordimg.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                    //Hide Password
                    confirmpass.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });


        ChangePassword=view.findViewById(R.id.Save);
        sessionManager=new SessionManager(getMasterActivity());
        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        ChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!password.getText().toString().equalsIgnoreCase("") || !Oladpass.getText().toString().equalsIgnoreCase("")||!confirmpass.getText().toString().equalsIgnoreCase(""))
                {
                    if (password.getText().toString()==confirmpass.getText().toString())
                    {
                        Toast.makeText(getMasterActivity(), "Password does not matched", Toast.LENGTH_SHORT).show();
                    }else {
                        OladpassSt=Oladpass.getText().toString();
                        passwordST=password.getText().toString();
                        confirmpassST=confirmpass.getText().toString();

                        if (mContext.isInternet) {
                            try {
                                postChangePassword();
                            }catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
                        }

                    }

                }else {
                    Toast.makeText(getMasterActivity(), "Please provide all all details", Toast.LENGTH_SHORT).show();

                }

            }
        });

        textColor=getResources().getString(R.color.primaryTextColor).substring(3);
        backgroundColor=getResources().getString(R.color.colorPrimary).substring(3);
        //Log.e("textColor",textColor +"& backgroundColor="+backgroundColor);
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

    }

    private void postChangePassword() {
        mContext.showWaitIndicator(true);
        String Userid=sessionManager.getKEY_Userid();

        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.oldpassword_ID, OladpassSt));
        carData.add(new BasicNameValuePair(
                Constants.password_ID,passwordST));
        carData.add(new BasicNameValuePair(
                Constants.cpassword_ID,confirmpassST));
        carData.add(new BasicNameValuePair(
                Constants.user_ID,Userid));
        dishRequest.sendRequest(Constants.API_Post_Change_password_URL,
                carData, catCallback);
    }


    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    String response_message=jObject.getString("response_message");
                    if (status.equalsIgnoreCase("1")) {

                        ToastUtil.showLongToastMessage(getMasterActivity(),response_message);
                        mContext.onBackPressed();


                    }else{
                        mContext.showWaitIndicator(false);
                        ToastUtil.showLongToastMessage(getMasterActivity(),response_message);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);

        }
    };
}
