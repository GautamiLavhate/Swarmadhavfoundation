package com.applexinfotech.swarmadhavfoundation;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.PlaylistVedioFragment;
import com.applexinfotech.swarmadhavfoundation.common.ui.CircularImageView;
import com.applexinfotech.swarmadhavfoundation.common.ui.DrawerArrowDrawable;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.downloadvedio.DownloadsMainVedioFragment;
import com.applexinfotech.swarmadhavfoundation.equalizer.AudioSessionChangedListener;
import com.applexinfotech.swarmadhavfoundation.equalizer.EqualizerFragment;
import com.applexinfotech.swarmadhavfoundation.fcm.DataBaseAdapter;
import com.applexinfotech.swarmadhavfoundation.fcm.Models;
import com.applexinfotech.swarmadhavfoundation.fcm.NotificationService;
import com.applexinfotech.swarmadhavfoundation.fcm.UtilsJobInfo;
import com.applexinfotech.swarmadhavfoundation.fragment.DashBoardFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.DownloadsMainFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.LyricsDialogFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.PlaylistFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.Settings;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.MusicStateListener;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.neavigation.NavigationDrawerFragment;
import com.applexinfotech.swarmadhavfoundation.service.DownloadService;
import com.applexinfotech.swarmadhavfoundation.service.MediaPlayerService;
import com.applexinfotech.swarmadhavfoundation.vedio.HomeFragmentVedio;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeStandalonePlayer;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import static android.view.Gravity.START;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.ASSET_IMAGE_FOLDER_PATH;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.CATEGORY_MINI_PLAYER;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.REQ_RESOLVE_SERVICE_MISSING;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.REQ_START_STANDALONE_PLAYER;
import static com.applexinfotech.swarmadhavfoundation.service.MediaPlayerService.SESSION_ID_NOT_SET;

public class MainActivity extends MasterActivity implements MusicStateListener, DownloadListener,AudioSessionChangedListener,NavigationDrawerFragment.NavigationDrawerCallbacks {

    private static Intent equilizerIntent;
    private DrawerArrowDrawable drawerArrowDrawable;
    private float offset;
    private boolean flipped;
    private ImageView imageView;
    private DrawerLayout drawer;
    private NavigationDrawerFragment mNavigationDrawerFragment;
    private CharSequence mTitleschar;
   // private DrawerLayout mDrawerLayout;
    private Resources resources;
    private Context mContext;
    private final FragmentManager fragmentManager = getSupportFragmentManager();
    private Typeface font;
    public ImageButton drawer_back, action_search,action_notification;
    public static final String Broadcast_PLAY_NEW_AUDIO = "com.applex.swarsageetmala.PlayNewAudio";
    private Intent playerIntent;
    private TextView title;
    private ImageView mPlayPause;
    private RelativeLayout topContainer;
    private ProgressBar mProgress;
    private SeekBar mSeekBar;
    private int overflowcounter = 0;
    private TextView mTitle, mArtist;
    private View rootView, playPauseWrapper;
    private CircularImageView mAlbumArt;
    private View nowPlayingCard;
    private AdView mAdView;
    public static final ArrayList<SubCategoryModel> downloadQueue = new ArrayList<>();
    //GCM registration start
    private String reg_id;
    Models mod;
    private DataBaseAdapter dba;
    private String register_id;
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private Intent downloadIntent;
    private Intent notificationIntent;
    public static final String Broadcast_STOP_DOWNLOADING = "com.applexinfotech.swarmadhavfoundation.StopDownload";
    private RewardedVideoAd mRewardedVideoAd;
    private static boolean isVideoAddShowing = false;
    private ImageButton lyricsIcon,equalizerIcon;
    public LinearLayout bottum_layout;
    private SessionManager sessionManager;
    public static String PACKAGE_NAME;
    public static String AudioType;

    TextView txtTermsAndCondition,txtPrivacyPolicy;
    BottomNavigationView bottomNavigationView;
    //Bottom Sheet Dialog
    BottomSheetDialog bottomSheetDialog,bottomSheetDialogVideo;
    //Linear Layout of bottomsheet
    LinearLayout linearLayoutAllCategories,linearLayoutPlaylist,linearLayoutDownloads,
            linearLayoutAllCategoriesVideo,linearLayoutPlaylistVideo,linearLayoutDownloadsVideo;

    private static final int REQUEST_CODE_EDIT = 1;
    //Rergistration end
    private final View.OnClickListener mPlayPauseListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (player != null) {
                if (isPlaying()) {
                    pauseSong();
                    setPlayPauseIcon(false);
                    // }
                } else {
                    // Resume song
                    startPlaying();
                    // Changing button image to pause button
                    setPlayPauseIcon(false);
                    // }
                }
            }

        }
    };


   private final View.OnClickListener playingCardClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

             //   if (isPlaying() || isPlayerPrepared()) {
            Fragment investProgramDetail = new Streaming();
            StorageUtil storage = new StorageUtil(getApplicationContext());
            if (storage.loadAudio() != null) {
                Bundle bundle = new Bundle();
                MainActivity.AudioType="MainAudio";
                bundle.putString("isFrom", CATEGORY_MINI_PLAYER);
                bundle.putInt("mode", storage.loadMode());
                bundle.putSerializable("data", storage.loadAudio());
                bundle.putInt("position", storage.loadAudioIndex());
                investProgramDetail.setArguments(bundle);

                ReplaceFragment(investProgramDetail);
            }
            //   }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        sessionManager=new SessionManager(this);
        UtilsJobInfo.scheduleJob(this, NotificationService.class);
        if (playerIntent == null && !serviceBound) { //mediaPlayerService
            playerIntent = new Intent(getApplicationContext(), MediaPlayerService.class);
            startService(playerIntent);
           serviceBound = bindService(playerIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        }

        if (downloadIntent == null && !downloadServiceBound) {  //downloadQueueService
            downloadIntent = new Intent(getApplicationContext(), DownloadService.class);
            startService(downloadIntent);
            downloadServiceBound= bindService(downloadIntent, downloadServiceConnection, Context.BIND_AUTO_CREATE);
        }

//        if (notificationIntent == null && !notificationBound){
//            notificationIntent=new Intent(getApplicationContext(),NotificationService.class);
//            startService(notificationIntent);
//            //notificationBound=bindService(notificationIntent,)
//        }

        mPlaybackStatus = new PlaybackStatus(this);
        drawer = findViewById(R.id.drawer_layout);
        drawer_back = findViewById(R.id.drawer_back);
        action_search = findViewById(R.id.action_search);
        action_notification=findViewById(R.id.action_notification);
        //imageView = findViewById(R.id.drawer_indicator);
        //mDrawerList = findViewById(R.id.drawer_content);
        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        mTitleschar = getTitle();
        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));


        resources = getResources();
        mContext = getApplicationContext();
        bottum_layout=findViewById(R.id.bottum_layout);

        if (isPlaying()) {
            bottum_layout.setVisibility(View.VISIBLE);
        } else {
            bottum_layout.setVisibility(View.GONE);
        }

        this.font = Typeface.createFromAsset(mContext.getAssets(), "ProximaNova-Light.otf");
       /* mAdView = findViewById(R.id.adView);*/

        mod = new Models();
        dba = new DataBaseAdapter(this);

        //mini player view
        nowPlayingCard = findViewById(R.id.now_playing_card);
        mPlayPause = findViewById(R.id.play_pause);
        playPauseWrapper = findViewById(R.id.play_pause_wrapper);
        playPauseWrapper.setOnClickListener(mPlayPauseListener);
        mProgress = findViewById(R.id.song_progress_normal);
        lyricsIcon = findViewById(R.id.lyrics);
        equalizerIcon = findViewById(R.id.equalizer);
        // mSeekBar = (SeekBar) findViewById(R.id.song_progress);
        mTitle = findViewById(R.id.title);
        mArtist = findViewById(R.id.artist);
        mAlbumArt = findViewById(R.id.album_art_nowplayingcard);
        topContainer = findViewById(R.id.topContainer);


        bottomSheetDialog=new BottomSheetDialog(MainActivity.this);
        View sheetView=getLayoutInflater().inflate(R.layout.bottom_sheet_audio,null);
        bottomSheetDialog.setContentView(sheetView);

        linearLayoutAllCategories=(LinearLayout)sheetView.findViewById(R.id.linearLayoutAllCategories);
        linearLayoutPlaylist=(LinearLayout)sheetView.findViewById(R.id.linearLayoutPlatlistAudio);
        linearLayoutDownloads=(LinearLayout)sheetView.findViewById(R.id.linearLayoutDownloadAudio);

        bottomSheetDialogVideo=new BottomSheetDialog(MainActivity.this);
        View sheetViewVideo=getLayoutInflater().inflate(R.layout.bottom_sheet_video,null);
        bottomSheetDialogVideo.setContentView(sheetViewVideo);

        linearLayoutAllCategoriesVideo=(LinearLayout)sheetViewVideo.findViewById(R.id.linearLayoutAllCategoriesVideo);
        linearLayoutPlaylistVideo=(LinearLayout)sheetViewVideo.findViewById(R.id.linearLayoutPlatlistVideo);
        linearLayoutDownloadsVideo=(LinearLayout)sheetViewVideo.findViewById(R.id.linearLayoutDownloadVideo);


        nowPlayingCard.setOnClickListener(playingCardClickListener);
        //mini player view
        drawerArrowDrawable = new DrawerArrowDrawable(resources);
        drawerArrowDrawable.setStrokeColor(ContextCompat.getColor(mContext, R.color.iconPrimaryColor));
        Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_search_white);
        mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
        action_search.setImageDrawable(mDrawable);
        Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_action_back);
        arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
        drawer_back.setImageDrawable(arrowDrawable);
        Drawable noticeDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_notification_swar);
        noticeDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
        action_notification.setImageDrawable(noticeDrawable);
        txtTermsAndCondition=(TextView)findViewById(R.id.txtTermscondition);
        txtPrivacyPolicy=(TextView)findViewById(R.id.txtPrivacyPolicy);
        bottomNavigationView=findViewById(R.id.bottom_navigation_view);
        txtTermsAndCondition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://docs.google.com/document/d/1BJRgBj0n4izel2YDQb_FtAqxItkUELz6FmrgEO3YVys/edit?usp=sharing";
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    Uri uri = Uri.parse(url);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }else{
                    Toast.makeText(mContext, "Invalid Url", Toast.LENGTH_SHORT).show();
                }
//                Intent intent=new Intent(MainActivity.this,TermsAndConditionActivity.class);
//                startActivity(intent);
                //Toast.makeText(MainActivity.this,"Terms",Toast.LENGTH_LONG).show();

            }
        });
        txtPrivacyPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://docs.google.com/document/d/1LRVaGIk_yIymqBeSV-Y4MYck9_Fshx7iiEC7-RL1wRg/edit?usp=sharing";
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    Uri uri = Uri.parse(url);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }else{
                    Toast.makeText(mContext, "Invalid Url", Toast.LENGTH_SHORT).show();
                }
//                Intent intent=new Intent(MainActivity.this,PrivacyPolicyActivity.class);
//                startActivity(intent);
                //Toast.makeText(MainActivity.this,"Privacy",Toast.LENGTH_LONG).show();
            }
        });
        linearLayoutAllCategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeFragment homeFragment=new HomeFragment();
                ReplaceFragment(homeFragment);
                bottomSheetDialog.dismiss();

            }
        });
        linearLayoutPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlaylistFragment playlistFragment=new PlaylistFragment();
                ReplaceFragment(playlistFragment);
                bottomSheetDialog.dismiss();
                //bottomNavigationView.setVisibility(View.VISIBLE);
            }
        });
        linearLayoutDownloads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadsMainFragment downloadsMainFragment=new DownloadsMainFragment();
                ReplaceFragment(downloadsMainFragment);
                bottomSheetDialog.dismiss();
            }
        });
        linearLayoutAllCategoriesVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeFragmentVedio homeFragmentVedio=new HomeFragmentVedio();
                ReplaceFragment(homeFragmentVedio);
                bottomSheetDialogVideo.dismiss();
            }
        });
        linearLayoutPlaylistVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlaylistVedioFragment playlistVedioFragment=new PlaylistVedioFragment();
                ReplaceFragment(playlistVedioFragment);
                bottomSheetDialogVideo.dismiss();
            }
        });
        linearLayoutDownloadsVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadsMainVedioFragment downloadsMainVedioFragment=new DownloadsMainVedioFragment();
                ReplaceFragment(downloadsMainVedioFragment);
                bottomSheetDialogVideo.dismiss();
            }
        });
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId()==R.id.bottom_home){
                    //Toast.makeText(mContext,"Hi",Toast.LENGTH_LONG).show();
                    Fragment homeFragment=new DashBoardFragment();
                    ReplaceFragment(homeFragment);
                }
                if (item.getItemId()==R.id.bottom_settings){
                    Fragment settingsFragment=new Settings();
                   ReplaceFragment(settingsFragment);
                }
                if (item.getItemId()==R.id.bottom_audio){
                    bottomSheetDialog.show();
                }
                if (item.getItemId()==R.id.bottom_video){
                   bottomSheetDialogVideo.show();
                }
                return false;
            }
        });

        lyricsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               ReplaceFragment(new LyricsDialogFragment());
            }
        });
        equalizerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // navigateToEqualizer(MainActivity.this);
                if(player!=null && isPlaying()){
                    if(player.getAudioSessionId()!=SESSION_ID_NOT_SET){
                        ReplaceFragment(EqualizerFragment.newInstance());
                    }
                }

            }
        });


        //imageView.setImageDrawable(drawerArrowDrawable);
        title = findViewById(R.id.title_text);
        title.setTypeface(font);
        title.setText(R.string.home_page);

        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);


        drawer.setDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                offset = slideOffset;

                // Sometimes slideOffset ends up so close to but not quite 1 or
                // 0.
                if (slideOffset >= .995) {
                    flipped = true;
                    drawerArrowDrawable.setFlip(flipped);
                } else if (slideOffset <= .005) {
                    flipped = false;
                    drawerArrowDrawable.setFlip(flipped);
                }

                drawerArrowDrawable.setParameter(offset);
            }
        });

//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (drawer.isDrawerVisible(START)) {
//                    drawer.closeDrawer(START);
//                } else {
//                    drawer.openDrawer(START);
//                }
//            }
//        });

        //FOR GCM REGISTRATION

        if (checkPlayServices()) {
            isInternet = InternetStatus.isInternetOn(this);
            if (isInternet) {
              //  createToken();
               // getGCMCallRequest();
            }

        }



        if (isInternet == true)
        {
            PACKAGE_NAME = getApplicationContext().getPackageName();
            //this.verifyPurchaseCode();
          //  this.showWaitIndicator(true);
        }
        else
        {
            this.setVerifyP(1);
        }
        if (savedInstanceState == null) {

            Fragment homeFragment = new DashBoardFragment();
            ReplaceFragment(homeFragment);
        }

    }


    private static boolean isNetConnected(Context paramContext) {
        ConnectivityManager localConnectivityManager = (ConnectivityManager) paramContext.getSystemService("connectivity");
        return (localConnectivityManager.getActiveNetworkInfo() != null) && (localConnectivityManager.getActiveNetworkInfo().isAvailable()) && (localConnectivityManager.getActiveNetworkInfo().isConnected());
    }

    private static void rate(Context paramContext) {
        if (isNetConnected(paramContext)) {
            paramContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + paramContext.getPackageName())).addFlags(268435456));
            return;
        }
        Toast.makeText(paramContext, R.string.plz_enable_wifi_or_data_from_settings, Toast.LENGTH_LONG).show();
    }


    public void ReplaceFragment(Fragment fragment) { //updated method by Deepal
        String backStateName = fragment.getClass().getName();

        FragmentManager manager = getSupportFragmentManager();
        boolean fragmentPopped = manager.popBackStackImmediate(backStateName, 0);

        if (!fragmentPopped && manager.findFragmentByTag(backStateName) == null) { //fragment not in back stack, create it.
            FragmentTransaction ft = manager.beginTransaction();
            ft.replace(R.id.fragment_container, fragment, backStateName);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.addToBackStack(backStateName);
            ft.commit();
        }
    }


    //GCM registration start
    private boolean checkPlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Toast.makeText(
                        this,
                        R.string.device_not_support_play_service,
                        Toast.LENGTH_LONG).show();
                finish();
            }
            return false;
        } else {
            // This device supports Play services, App will work normally.
        }
        return true;
    }


    private void savePrefs(String key, String value) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString(key, value);
        edit.commit();
    }


    @Override
    public void onBackPressed() {

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawers();
        } else {

            FragmentManager fragmentManager = getSupportFragmentManager();
            int backCount = fragmentManager.getBackStackEntryCount();
            Log.d("BackStackEntryCount", String.valueOf(backCount));
            if (backCount == 1) {
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
            if (backCount > 0) {
                if (isPlaying()) {
                    bottum_layout.setVisibility(View.VISIBLE);
                    fragmentManager.popBackStack();
                } else {
                    bottum_layout.setVisibility(View.GONE);
                    fragmentManager.popBackStack();
                }
                Log.e("BackStackEntryCount", "popBackStack");
            } else {

                if (isPlaying()) {
                    bottum_layout.setVisibility(View.VISIBLE);
                    super.onBackPressed();
                } else {
                    bottum_layout.setVisibility(View.GONE);
                    super.onBackPressed();
                }
                Log.e("BackStackEntryCount", "onBackPressed");
            }
        }
    }


    @Override
    public void onDestroy() {
        if (serviceBound && serviceConnection != null) {
            //service is active
            if(player!=null){
                serviceBound=false;
                unbindService(serviceConnection);
                player.stopSelf();
            }
        }
        if (downloadServiceBound && downloadServiceConnection != null) {
            Intent broadcastIntent = new Intent(Broadcast_STOP_DOWNLOADING);
            Log.e("ThreadPoolExecutor", "Broadcast_STOP_DOWNLOADING");
            mContext.sendBroadcast(broadcastIntent);
            downloadServiceBound=false;
            unbindService(downloadServiceConnection);
            //service is active
        }
        try { if(mPlaybackStatus!=null){
            unregisterReceiver(mPlaybackStatus);
        }
        } catch (final Throwable e) {
        }


       /* if (mRewardedVideoAd != null) {
            mRewardedVideoAd.destroy(this);
        }*/
        Utils.deleteCache(getCacheDir());
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        super.onStart();

        final IntentFilter filter = new IntentFilter();
        // Update song status
        filter.addAction(MediaPlayerService.UPDATE_SONG_STATUS);
        // Track changes Play and pause changes
        filter.addAction(MediaPlayerService.META_CHANGED);
        // Update progressbar
        filter.addAction(MediaPlayerService.REFRESH);
        // Stop progressbar callbacks
        filter.addAction(MediaPlayerService.STOP_PROGRESS);
        // If there is an error playing a track
        filter.addAction(MediaPlayerService.TRACK_ERROR);
        //for download service receiver
        filter.addAction(DownloadService.ACTION_DOWNLOAD_BROAD_CAST);
        //Audio session id changes
        filter.addAction(MediaPlayerService.REFRESH_AUDIO_SESSION_ID);
        //for download cancel
        filter.addAction(DownloadService.ACTION_STOP_DOWNLOAD);
        //for download pause
        filter.addAction(DownloadService.ACTION_PAUSE_DOWNLOAD);
        registerReceiver(mPlaybackStatus, filter);

    }

    public void setMusicStateListenerListener(final MusicStateListener status) {
        if (status == this) {
            throw new UnsupportedOperationException("Override the method, don't add a listener");
        }

        if (status != null) {
            mMusicStateListener.add(status);
        }
    }
    public void setAudioSessionListener(final AudioSessionChangedListener status) {
        if (status == this) {
            throw new UnsupportedOperationException("Override the method, don't add a listener");
        }

        if (status != null) {
            mAudioSessionChangeListener.add(status);
        }
    }
    public void removeMusicStateListenerListener(final MusicStateListener status) {
        if (status != null) {
            mAudioSessionChangeListener.remove(status);
        }
    }

    //Binding this Client to the AudioPlayer Service
    private static final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            MediaPlayerService.LocalBinder binder = (MediaPlayerService.LocalBinder) service;
            player = binder.getService();
           // serviceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            player=null;
            serviceBound = false;
        }
    };

    @Override
    public void restartLoader() {
        for (final MusicStateListener listener : mMusicStateListener) {
            if (listener != null) {
                listener.restartLoader();
            }
        }
    }

    @Override
    public void stopProgressHandler() {
        for (final MusicStateListener listener : mMusicStateListener) {
            if (listener != null) {
                listener.stopProgressHandler();
            }
        }
    }

    @Override
    public void onMetaChanged() {
        for (final MusicStateListener listener : mMusicStateListener) {
            if (listener != null) {
                updateBottomPlayer();
                listener.onMetaChanged();
               // Log.e("onMetaChanged", "UPDATE_VIEW");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateBottomPlayer();

    }


    private void updateBottomPlayer() {
        StorageUtil storage = new StorageUtil(getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        int audioIndex = storage.loadAudioIndex();
        int mode = storage.loadMode();
        if (audioList == null) {
            nowPlayingCard.setVisibility(View.GONE);
        } else {
            if ((audioList.size() > 0) && audioIndex < audioList.size()) {
                updateView(audioList.get(audioIndex), mode);
            } else {
                nowPlayingCard.setVisibility(View.GONE);
            }

        }

    }

    private void updateView(SubCategoryModel currentlyPlaying, int mode) {
        if (currentlyPlaying == null) {
            nowPlayingCard.setVisibility(View.GONE);
            return;
        }
        lyricsIcon.setVisibility(mode == 3 ? View.GONE : View.VISIBLE);

        nowPlayingCard.setVisibility(View.VISIBLE);
        Log.e("update view", "UPDATE");
        mArtist.setText(currentlyPlaying.getItem_description());
        mTitle.setText(currentlyPlaying.getItem_name());

        if (currentlyPlaying.getItem_image().startsWith("https")|| mode==3) {
            Glide.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).into(mAlbumArt);
           // Picasso.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fit().into(mAlbumArt);
        }else if(mode==4){
            Glide.with(mContext).load(ASSET_IMAGE_FOLDER_PATH+currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).into(mAlbumArt);
           // Picasso.with(mContext).load(ASSET_IMAGE_FOLDER_PATH+currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fit().into(mAlbumArt);
        } else {
            Glide.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).into(mAlbumArt);
          /*  if (currentlyPlaying.getItem_image() != null) {
                Bitmap bitmap = BitmapFactory.decodeFile(currentlyPlaying.getItem_image());
                if(bitmap!=null){
                    mAlbumArt.setImageBitmap(bitmap);
                }else {
                    Picasso.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fit().into(mAlbumArt);
                }
            }*/
        }
        if (isPlayerPrepared()) {
            // Changing button image to play button
            if (!isPlaying()) {
                mPlayPause.setImageResource(R.drawable.ic_play_arrow);

            } else {
                mPlayPause.setImageResource(R.drawable.ic_pause);
            }
        }
    }

    private void setPlayPauseIcon(boolean isPlaying) {

        if (isPlaying) {
            Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_pause);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            mPlayPause.setImageDrawable(mDrawable);
        } else {
            Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_arrow);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            mPlayPause.setImageDrawable(mDrawable);
        }


    }

    //Binding this Client to the Downloading Service
    private static final ServiceConnection downloadServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            DownloadService.LocalBinder binder = (DownloadService.LocalBinder) service;
            downloadService = binder.getService();
          //  downloadServiceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            downloadServiceBound = false;
        }
    };

    public void setDownloadStateListener(final DownloadListener status) {
        if (status == this) {
            throw new UnsupportedOperationException("Override the method, don't add a listener");
        }

        if (status != null) {
            mDownloadStateListener.add(status);
        }
    }


    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel subCategoryModel, int position) {
        for (final DownloadListener listener : mDownloadStateListener) {
            if (listener != null) {
                listener.onDownloadsBroadcastUpdate(subCategoryModel, position);
            }
        }
    }

    @Override
    public void sessionIdChanged(int audioSessionId) {
        for (final AudioSessionChangedListener listener : mAudioSessionChangeListener) {
            if (listener != null) {
                listener.sessionIdChanged(audioSessionId);
            }
        }
    }
    //Binding this Client to the Downloading Service ends

    private final class PlaybackStatus extends BroadcastReceiver {

        private final WeakReference<MainActivity> mReference;


        public PlaybackStatus(final MainActivity activity) {
            mReference = new WeakReference<>(activity);
        }

        @Override
        public void onReceive(final Context context, final Intent intent) {
            final String action = intent.getAction();
            MainActivity baseActivity = mReference.get();
            if (baseActivity != null) {
                if (action.equals(MediaPlayerService.META_CHANGED)) {
                    baseActivity.onMetaChanged();
                } else if (action.equals(MediaPlayerService.UPDATE_SONG_STATUS)) {
                    if (isSongCompleted()) {
                        requestSongStatusChange();
                    }
                } else if (action.equals(MediaPlayerService.REFRESH)) {
                    baseActivity.restartLoader();
                }else if (action.equals(MediaPlayerService.REFRESH_AUDIO_SESSION_ID)) {
                    if(player.getAudioSessionId()!=SESSION_ID_NOT_SET) {
                            baseActivity.sessionIdChanged(player.getAudioSessionId());
                               // navigateToEqualizer(MainActivity.this);
                    }
                } else if (action.equals(MediaPlayerService.STOP_PROGRESS)) {
                    baseActivity.stopProgressHandler();
                } else if (action.equals(MediaPlayerService.TRACK_ERROR)) {
                    final String errorMsg = context.getString(R.string.error_playing_track);
                    Toast.makeText(baseActivity, errorMsg, Toast.LENGTH_SHORT).show();
                } else if (action.equals(DownloadService.ACTION_DOWNLOAD_BROAD_CAST)) {
                    final int position = intent.getIntExtra(DownloadService.EXTRA_POSITION, -1);
                    final SubCategoryModel tmpInfo = (SubCategoryModel) intent.getSerializableExtra(DownloadService.EXTRA_APP_INFO);
                    if (tmpInfo == null || position == -1) {
                        return;
                    }
                    baseActivity.onDownloadsBroadcastUpdate(tmpInfo, position);
                }else if (action.equals(DownloadService.ACTION_PAUSE_DOWNLOAD)){
                    //baseActivity.stopProgressHandler();
                }
            }
        }

        private void requestSongStatusChange() {
            StorageUtil storage = new StorageUtil(getApplicationContext());
            ArrayList<SubCategoryModel> audioList = storage.loadAudio();
            int playedAudioIndex = storage.loadPlayedAudioIndex();
            Log.e("playedAudioIndex", String.valueOf(playedAudioIndex));
            if (audioList != null && !audioList.isEmpty() && playedAudioIndex != -1 && playedAudioIndex<audioList.size()) {

            }

        }
    }

    private boolean canResolveIntent(Intent intent) {
        List<ResolveInfo> resolveInfo = getPackageManager().queryIntentActivities(intent, 0);
        return resolveInfo != null && !resolveInfo.isEmpty();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_EDIT) {
            return;
        }

        else if (resultCode != RESULT_OK) {
            return;
        }

        setResult(RESULT_OK, data);
    }

    public void startRingdroidEditor(SubCategoryModel subCategoryModel) {
        if(subCategoryModel!=null) {
            if (MasterActivity.serviceBound && isPlaying()) {
                pauseSong();
                player.cancelNotification();
            }
            Intent intent1 = getIntent();
            boolean mWasGetContentIntent;
            if (intent1.getAction() != null) {
                mWasGetContentIntent = intent1.getAction().equals(
                        Intent.ACTION_GET_CONTENT);
            } else {
                mWasGetContentIntent = false;
            }
            assert subCategoryModel.getItem_file() != null;
            String filename = subCategoryModel.getItem_file();
            try {
                Intent intent = new Intent(Intent.ACTION_EDIT, Uri.parse(filename));
                intent.putExtra("was_get_content_intent", mWasGetContentIntent);
                intent.setClassName("com.applex.swarsageetmala", "com.applex.swarsageetmala.ringtone.RingEditorActivity");
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            } catch (Exception e) {
                Log.e("Ringdroid", "Couldn't start editor");
            }
        }
    }

    //vedio Fragment NotFragment = new Notification();
    //                        mContext.ReplaceFragment(NotFragment);

    public  void playYoutubeVideo(SubCategoryModel selectedObject){
        if(selectedObject!=null) {
            String videoUrl = selectedObject.getVideo_url();
            if (videoUrl != null && !videoUrl.isEmpty()) {
                String VIDEO_ID = Utils.extractYTId(videoUrl);
                Log.e("VIDEO_ID", "VIDEO_ID====" + VIDEO_ID);
                if (VIDEO_ID != null) {
                    Intent intent = YouTubeStandalonePlayer.createVideoIntent(
                            this, Constants.YOU_TUBE_DEVELOPER_KEY, VIDEO_ID, 0, true, false);
                    if (intent != null) {
                        if (canResolveIntent(intent)) {
                            startActivityForResult(intent, REQ_START_STANDALONE_PLAYER);
                            if (InternetStatus.isInternetOn(this)) {
                                storeToRecentlyPlayed(selectedObject);
                            }
                        } else {
                            // Could not resolve the intent - must need to install or update the YouTube API service.
                            YouTubeInitializationResult.SERVICE_MISSING
                                    .getErrorDialog(this, REQ_RESOLVE_SERVICE_MISSING).show();
                        }
                    } else {
                        Log.e("ERROR", "Intent is null in playYoutubeVideo");
                    }
                } else {
                    Log.e("ERROR", "Failed to extract VIDEO_ID");
                }
            } else {
                Log.e("ERROR", "VideoUrl is null in playYoutubeVideo");
            }
        }
    }

    @Override
    public void onNavigationDrawerItemSelected(int position) {
        // update the main content by replacing fragments

    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

}
