package com.applexinfotech.swarmadhavfoundation.common.util;




import com.applexinfotech.swarmadhavfoundation.R;

import java.util.HashMap;

public class IconUtils {

    private static HashMap<String, Integer> sMimeIcons = new HashMap();

    private static void add(String mimeType, int resId) {
        if (sMimeIcons.put(mimeType, resId) != null) {
            throw new RuntimeException(mimeType + " already registered!");
        }
    }

    static {
        int icon;


        // Audio
        icon = R.drawable.ic_doc_audio;
        add("application/ogg", icon);
        add("application/x-flac", icon);




        // Image
        icon = R.drawable.ic_doc_image;
        add("application/vnd.oasis.opendocument.graphics", icon);
        add("application/vnd.oasis.opendocument.graphics-template", icon);
        add("application/vnd.oasis.opendocument.image", icon);
        add("application/vnd.stardivision.draw", icon);
        add("application/vnd.sun.xml.draw", icon);
        add("application/vnd.sun.xml.draw.template", icon);




    }

    public static int loadMimeIcon(String mimeType) {

        // Look for exact match first
        Integer resId = sMimeIcons.get(mimeType);
        if (resId != null) {
            return resId;
        }

        if (mimeType == null) {
            // TODO: generic icon?
            return R.drawable.ic_doc_generic;
        }

        // Otherwise look for partial match
        final String typeOnly = mimeType.split("/")[0];
        if ("audio".equals(typeOnly)) {
            return R.drawable.ic_doc_audio;
        } else if ("image".equals(typeOnly)) {
            return R.drawable.ic_doc_image;
        }   else {
            return R.drawable.ic_doc_generic;
        }
    }

}
