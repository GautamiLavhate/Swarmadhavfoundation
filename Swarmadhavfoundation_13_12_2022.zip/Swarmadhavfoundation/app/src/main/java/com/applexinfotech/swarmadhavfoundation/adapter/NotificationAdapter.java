package com.applexinfotech.swarmadhavfoundation.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.model.NotificationRecord;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class NotificationAdapter extends ArrayAdapter<NotificationRecord>
{
	final int resource;
	private final LayoutInflater layoutInflater;
	public static List<NotificationRecord> mItems;
	public final Context mContext;
	static final int version_val = 1;

	public NotificationAdapter(Context context, int notificationItems,ArrayList<NotificationRecord> temp) 
	{
		// TODO Auto-generated constructor stub
		super(context, notificationItems, temp);
		mContext = context;
		mItems = temp;
		resource = notificationItems;
		layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public int getCount() 
	{
		return mItems.size();
	}

	public long getItemId(int position) 
	{
		return position;
	}

	@SuppressLint("ViewHolder")
	@Override
	public View getView(final int position, View convertView, ViewGroup parent)
	{
		View rootView = convertView;

		rootView = layoutInflater.inflate(R.layout.notification_list_item, null,true);

		TextView text_title = rootView.findViewById(R.id.titlename);
		TextView text_time = rootView.findViewById(R.id.description);
		ImageView imageView = rootView.findViewById(R.id.image);

		ImageButton clear = rootView.findViewById(R.id.imageButton_clear);

		text_title.setText(mItems.get(position).getTitle());
		text_time.setText(mItems.get(position).getDescription());
		Glide.with(mContext).load(mItems.get(position).getNotification_image()).placeholder(R.drawable.no_image).into(imageView);

		return rootView;
	}
}