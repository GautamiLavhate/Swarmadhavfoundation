package com.applexinfotech.swarmadhavfoundation.helpers;


import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;
import com.applexinfotech.swarmadhavfoundation.model.RecentlyPlayedModel;
import com.applexinfotech.swarmadhavfoundation.model.Song;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;
import io.realm.Sort;


/**
 * Created by JD Android on 02-May-18.
 */

public class RealmHelper {

    public final Realm realm;

    public RealmHelper() {
        this.realm = Realm.getDefaultInstance();
    }

    public void saveDownloadedData(final SongModel cartObject) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                SongModel s = realm.copyToRealmOrUpdate(cartObject);
            }
        });

    }

    //READ
    public ArrayList<SongModel> retrieveDownloadedList() {
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).findAll();
                cartObjectArrayList.addAll(observedDimData);

            }
        });
        return cartObjectArrayList;
    }

    public ArrayList<String> retrieveSongIdList() {
        final ArrayList<String> songIdList = new ArrayList<>();
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).distinct("item_id").findAll();
                cartObjectArrayList.addAll(observedDimData);
                for (int i = 0; i < cartObjectArrayList.size(); i++) {
                    songIdList.add(cartObjectArrayList.get(i).getItem_id());
                }
            }
        });
        return songIdList;
    }


    public ArrayList<SongModel> retrieveSongIdListDEmo() {
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).distinct("item_id").findAll();
                cartObjectArrayList.addAll(observedDimData);
            }
        });
        return cartObjectArrayList;
    }



    public ArrayList<SongModel> retrieveoAudioListDEmo() {
        final ArrayList<SongModel> songIdList = new ArrayList<>();
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).distinct("item_id").findAll();
                cartObjectArrayList.addAll(observedDimData);

                for (int i = 0; i < cartObjectArrayList.size(); i++) {

                    SongModel songModel = new SongModel();
                    String StVideo_url = cartObjectArrayList.get(i).getVideo_url();
                    if (StVideo_url.equals("null")) {
                        songModel.setItem_id(cartObjectArrayList.get(i).getItem_id());
                        songModel.setItem_name(cartObjectArrayList.get(i).getItem_name());
                        songModel.setItem_image(cartObjectArrayList.get(i).getItem_image());
                        songModel.setItem_file(cartObjectArrayList.get(i).getItem_file());
                        songModel.setItem_description(cartObjectArrayList.get(i).getItem_description());
                        songModel.setDownload_name(cartObjectArrayList.get(i).getDownload_name());
                        songModel.setCategory_id(cartObjectArrayList.get(i).getCategory_id());
                        songModel.setCategory_name(cartObjectArrayList.get(i).getCategory_name());
                        songModel.setCategory_image(cartObjectArrayList.get(i).getCategory_image());
                        songModel.setLyrics_file(cartObjectArrayList.get(i).getLyrics_file());
                        songModel.setLyrics_filePdf(cartObjectArrayList.get(i).getLyrics_filePdf());
                        songModel.setUpdate_count(cartObjectArrayList.get(i).getUpdate_count());
                        songModel.setTypeHm(cartObjectArrayList.get(i).getTypeHm());
                        songIdList.add(songModel);
                    }
                }
            }
        });
        return songIdList;
    }

    public ArrayList<SongModel> retrieveVideoIdListDEmo() {
        final ArrayList<SongModel> songIdList = new ArrayList<>();
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).distinct("item_id").findAll();
                cartObjectArrayList.addAll(observedDimData);
                for (int i = 0; i < cartObjectArrayList.size(); i++) {

                    SongModel songModel = new SongModel();
                    String StVideo_url=cartObjectArrayList.get(i).getVideo_url();
                    if(!StVideo_url.equals("null")){
                        songModel.setItem_id(cartObjectArrayList.get(i).getItem_id());
                        songModel.setItem_name(cartObjectArrayList.get(i).getItem_name());
                        songModel.setItem_image(cartObjectArrayList.get(i).getItem_image());
                        songModel.setItem_file(cartObjectArrayList.get(i).getItem_file());
                        songModel.setItem_description(cartObjectArrayList.get(i).getItem_description());
                        songModel.setDownload_name(cartObjectArrayList.get(i).getDownload_name());
                        songModel.setCategory_id(cartObjectArrayList.get(i).getCategory_id());
                        songModel.setCategory_name(cartObjectArrayList.get(i).getCategory_name());
                        songModel.setCategory_image(cartObjectArrayList.get(i).getCategory_image());
                        songModel.setVideo_url(cartObjectArrayList.get(i).getVideo_url());
                        songModel.setUpdate_count(cartObjectArrayList.get(i).getUpdate_count());
                        songModel.setTypeHm(cartObjectArrayList.get(i).getTypeHm());
                        songIdList.add(songModel);
                    }
                }
            }
        });
        return songIdList;
    }

    public ArrayList<SongModel> retrieveSongListByCategory(final String categoryId) {
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).equalTo("category_id", categoryId).findAll();
                cartObjectArrayList.addAll(observedDimData);

            }
        });
        return cartObjectArrayList;
    }

    public ArrayList<HomeModel> retrieveCategoryListVideo() {
        final ArrayList<HomeModel> categoryList = new ArrayList<>();
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).distinct("category_id").findAll().sort("category_id");
                cartObjectArrayList.addAll(observedDimData);
                for (int i = 0; i < cartObjectArrayList.size(); i++) {
                    HomeModel homeModel = new HomeModel();
                    String homevideost=cartObjectArrayList.get(i).getTypeHm();
                    if(homevideost.equals("Video")) {
                        homeModel.setCategory_id(cartObjectArrayList.get(i).getCategory_id());
                        homeModel.setCategory_name(cartObjectArrayList.get(i).getCategory_name());
                        homeModel.setCategory_image(cartObjectArrayList.get(i).getCategory_image());
                        homeModel.setTypeHm(cartObjectArrayList.get(i).getTypeHm());
                        categoryList.add(homeModel);
                    }
                }
            }
        });
        return categoryList;
    }


    public ArrayList<HomeModel> retrieveCategoryListAudio() {
        final ArrayList<HomeModel> categoryList = new ArrayList<>();
        final ArrayList<SongModel> cartObjectArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).distinct("category_id").findAll().sort("category_id");
                cartObjectArrayList.addAll(observedDimData);
                for (int i = 0; i < cartObjectArrayList.size(); i++) {
                    HomeModel homeModel = new HomeModel();
                    String homevideost=cartObjectArrayList.get(i).getTypeHm();
                    if(homevideost.equals("Audio")) {
                        homeModel.setCategory_id(cartObjectArrayList.get(i).getCategory_id());
                        homeModel.setCategory_name(cartObjectArrayList.get(i).getCategory_name());
                        homeModel.setCategory_image(cartObjectArrayList.get(i).getCategory_image());
                        homeModel.setTypeHm(cartObjectArrayList.get(i).getTypeHm());
                        categoryList.add(homeModel);
                    }
                }
            }
        });
        return categoryList;
    }

    //delete single data
    public void deleteSongData(final String id) {
        // Create an new array to avoid concurrency problem.
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                SongModel item = realm.where(SongModel.class).equalTo("item_id", id).findFirst();
                // Otherwise it has been deleted already.
                if (item != null && item.isValid()) {
                    item.deleteFromRealm();
                }

                RecentlyPlayedModel observedDimData = realm.where(RecentlyPlayedModel.class).equalTo("item_id", id).findFirst();
                if (observedDimData != null) {
                    if (observedDimData.isValid()) {
                        if (!observedDimData.getItem_file().startsWith("https")) {
                            observedDimData.deleteFromRealm();
                        }

                    }
                }

            }
        });
    }

/*

    public void updateNewCard(final String id) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                SongModel item = realm.where(SongModel.class).equalTo("item_id", id).findFirst();
                // Otherwise it has been deleted already.
                if (item != null && item.isValid()) {
                    realm.insertOrUpdate(item);
                }

                RecentlyPlayedModel observedDimData = realm.where(RecentlyPlayedModel.class).equalTo("item_id", id).findFirst();
                if (observedDimData != null) {
                    if (observedDimData.isValid()) {
                        if (!observedDimData.getItem_file().startsWith("http")) {
                            realm.insertOrUpdate(observedDimData);
                        }

                    }
                }

            }
        });
    }
*/

    //delete all data
    public static void deleteAllDataList(Realm realm) {
        // Create an new array to avoid concurrency problem.
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                RealmResults<SongModel> observedDimData = realm.where(SongModel.class).findAll();
                // Otherwise it has been deleted already.
                if (observedDimData != null) {
                    realm.deleteAll();
                }
            }

        });
    }

    public void saveRecentlyPlayed(final SubCategoryModel cartObject) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                RecentlyPlayedModel observedDimData = realm.where(RecentlyPlayedModel.class).equalTo("item_id", cartObject.getItem_id()).findFirst();
                if (observedDimData != null) {
                    if (observedDimData.isValid()) {
                        observedDimData.deleteFromRealm();
                    }
                }
                // increment index
                Number currentIdNum = realm.where(RecentlyPlayedModel.class).max("id");
                int nextId;
                if (currentIdNum == null) {
                    nextId = 1;
                } else {
                    nextId = currentIdNum.intValue() + 1;
                }

                RecentlyPlayedModel recentlyPlayedModel = new RecentlyPlayedModel();
                recentlyPlayedModel.setId(nextId);
                recentlyPlayedModel.setItem_id(cartObject.getItem_id());
                recentlyPlayedModel.setItem_name(cartObject.getItem_name());
                recentlyPlayedModel.setItem_image(cartObject.getItem_image());
                recentlyPlayedModel.setItem_file(cartObject.getItem_file());
                recentlyPlayedModel.setItem_description(cartObject.getItem_description());
                recentlyPlayedModel.setDownload_name(cartObject.getDownload_name());
                recentlyPlayedModel.setCategory_id(cartObject.getCategory_id());
                recentlyPlayedModel.setCategory_name(cartObject.getCategory_name());
                recentlyPlayedModel.setCategory_image(cartObject.getCategory_image());
                recentlyPlayedModel.setLyrics_file(cartObject.getLyrics_file());
                recentlyPlayedModel.setVideo_url(cartObject.getVideo_url());
                recentlyPlayedModel.setLyrics_filePdf(cartObject.getLyrics_filePdf());
                recentlyPlayedModel.setUpdate_count(cartObject.getUpdate_count());
                realm.copyToRealmOrUpdate(recentlyPlayedModel);
            }
        });

    }

    //READ
    public ArrayList<SubCategoryModel> retrieveRecentlyPlayedList(final int count) {
        final ArrayList<SubCategoryModel> recentlyPlayedArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                RealmResults<RecentlyPlayedModel> observedDimData = realm.where(RecentlyPlayedModel.class).sort("id", Sort.DESCENDING).findAll();
                List<RecentlyPlayedModel> recentlyPlayedModels = new ArrayList<>();
                // sort in descending order last 10 songs/videos
                if (observedDimData.size() > 0) {
                    if (observedDimData.size() > count && count == 10) {
                        recentlyPlayedModels = observedDimData.sort("id", Sort.DESCENDING).subList(0, 10);
                    } else {
                        recentlyPlayedModels = observedDimData.sort("id", Sort.DESCENDING);
                    }
                    if (observedDimData.size() > 30) {
                        List<RecentlyPlayedModel> data = observedDimData.subList(30, observedDimData.size());
                        for (RecentlyPlayedModel model : data) {
                            if (model != null) {
                                RecentlyPlayedModel item = realm.where(RecentlyPlayedModel.class).equalTo("id", model.getId()).findFirst();
                                if (item != null) {
                                    item.deleteFromRealm();
                                }
                            }
                        }

                    }
                    if (!recentlyPlayedModels.isEmpty()) {
                        for (RecentlyPlayedModel item : recentlyPlayedModels) {
                            SubCategoryModel subCategoryModel = new SubCategoryModel();
                            subCategoryModel.setItem_id(item.getItem_id());
                            subCategoryModel.setItem_name(item.getItem_name());
                            subCategoryModel.setItem_image(item.getItem_image());
                            subCategoryModel.setItem_file(item.getItem_file());
                            subCategoryModel.setItem_description(item.getItem_description());
                            subCategoryModel.setDownload_name(item.getDownload_name());
                            subCategoryModel.setCategory_id(item.getCategory_id());
                            subCategoryModel.setCategory_name(item.getCategory_name());
                            subCategoryModel.setCategory_image(item.getCategory_image());
                            subCategoryModel.setLyrics_file(item.getLyrics_file());
                            subCategoryModel.setVideo_url(item.getVideo_url());
                            subCategoryModel.setLyrics_filePdf(item.getLyrics_filePdf());
                            subCategoryModel.setUpdate_count(item.getUpdate_count());
                            recentlyPlayedArrayList.add(subCategoryModel);
                        }
                    }
                }

            }
        });
        return recentlyPlayedArrayList;
    }

    public void createNewPlaylist(final Playlist playlist) {
        final boolean success = true;
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                // increment index
                Number currentIdNum = realm.where(Playlist.class).max("id");
                int nextId;
                if (currentIdNum == null) {
                    nextId = 1;
                } else {
                    nextId = currentIdNum.intValue() + 1;
                }
                playlist.setId(nextId);
                realm.copyToRealmOrUpdate(playlist);

            }
        });
    }

    //delete all data
    public ArrayList<Playlist> getAllPlaylist() {
        final ArrayList<Playlist> playlists = new ArrayList<>();
        // Create an new array to avoid concurrency problem.
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                RealmResults<Playlist> playlistRealmResults = realm.where(Playlist.class).findAll();
                playlists.addAll(playlistRealmResults);
            }

        });
        return playlists;
    }

    public void addSongToPlaylist(final Playlist playlist, final SubCategoryModel subCategoryModel) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                // increment index
                Song existingSong = realm.where(Song.class).equalTo("item_id", subCategoryModel.getItem_id()).findFirst();
                if (existingSong == null) {
                    Song song = new Song(subCategoryModel);
                    existingSong = realm.copyToRealmOrUpdate(song);
                }

                Playlist list = realm.where(Playlist.class).equalTo("id", playlist.getId()) .equalTo("name", playlist.getName()).findFirst();
                if(list==null){
                    // increment index
                    Number currentIdNum = realm.where(Playlist.class).max("id");
                    int nextId;
                    if (currentIdNum == null) {
                        nextId = 1;
                    } else {
                        nextId = currentIdNum.intValue() + 1;
                    }
                    playlist.setId(nextId);
                    list = realm.copyToRealmOrUpdate(playlist);
                }
                list.getSongs().add(existingSong);

            }
        });

    }

    public ArrayList<SubCategoryModel> retrievePlayListSongs(final int id) {
        final ArrayList<SubCategoryModel> recentlyPlayedArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                Playlist list = realm.where(Playlist.class).equalTo("id", id).findFirst();

                RealmList<Song> songList = list.getSongs();
                if (songList != null && !songList.isEmpty()) {
                    for (Song item : songList) {
                        SubCategoryModel subCategoryModel = new SubCategoryModel();
                        String itemvedosong=item.getVideo_url();
                            subCategoryModel.setItem_id(item.getItem_id());
                            subCategoryModel.setItem_name(item.getItem_name());
                            subCategoryModel.setItem_image(item.getItem_image());
                            subCategoryModel.setItem_file(item.getItem_file());
                            subCategoryModel.setItem_description(item.getItem_description());
                            subCategoryModel.setDownload_name(item.getDownload_name());
                            subCategoryModel.setCategory_id(item.getCategory_id());
                            subCategoryModel.setCategory_name(item.getCategory_name());
                            subCategoryModel.setCategory_image(item.getCategory_image());
                            subCategoryModel.setLyrics_file(item.getLyrics_file());
                            subCategoryModel.setLyrics_filePdf(item.getLyrics_filePdf());
                            subCategoryModel.setVideo_url(item.getVideo_url());
                            subCategoryModel.setUpdate_count(item.getUpdate_count());
                            recentlyPlayedArrayList.add(subCategoryModel);

                    }
                }

            }
        });
        return recentlyPlayedArrayList;
    }


    public ArrayList<SubCategoryModel> retrievePlayListVideo(final int id) {
        final ArrayList<SubCategoryModel> recentlyPlayedArrayList = new ArrayList<>();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {

                Playlist list = realm.where(Playlist.class).equalTo("id", id).findFirst();

                RealmList<Song> songList = list.getSongs();
                if (songList != null && !songList.isEmpty()) {
                    for (Song item : songList) {
                        SubCategoryModel subCategoryModel = new SubCategoryModel();
                        String itemvedosong=item.getVideo_url();
                        if (!itemvedosong.equals("null")) {
                            subCategoryModel.setItem_id(item.getItem_id());
                            subCategoryModel.setItem_name(item.getItem_name());
                            subCategoryModel.setItem_image(item.getItem_image());
                            subCategoryModel.setItem_file(item.getItem_file());
                            subCategoryModel.setItem_description(item.getItem_description());
                            subCategoryModel.setDownload_name(item.getDownload_name());
                            subCategoryModel.setCategory_id(item.getCategory_id());
                            subCategoryModel.setCategory_name(item.getCategory_name());
                            subCategoryModel.setCategory_image(item.getCategory_image());
                            subCategoryModel.setVideo_url(item.getVideo_url());
                            subCategoryModel.setUpdate_count(item.getUpdate_count());
                            recentlyPlayedArrayList.add(subCategoryModel);
                        }
                    }
                }

            }
        });
        return recentlyPlayedArrayList;
    }

    public void removeSongFromPlaylist(final Playlist playlist, final SubCategoryModel subCategoryModel) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Playlist list = realm.where(Playlist.class).equalTo("id", playlist.getId()).findFirst();
                assert list != null;
                RealmList<Song> l = list.getSongs();
                for (Song s : l) {
                    if (s.getItem_id().equals(subCategoryModel.getItem_id())) {
                        l.remove(s);
                        break;
                    }
                }

            }
        });

    }

    public void deletePlaylist(final Playlist playlist) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Playlist list = realm.where(Playlist.class).equalTo("id", playlist.getId()).findFirst();
                assert list != null;
                list.deleteFromRealm();
            }
        });

    }

    public Playlist getCurrentPlaylist(final int id) {
        final Playlist[] list = new Playlist[1];
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                list[0] = realm.where(Playlist.class).equalTo("id", id).findFirst();
            }
        });
        return list[0];
    }


    public Playlist retrievePlaylist(final int playlistId,final String playlistType) {
        final Playlist[] playlist = new Playlist[1];
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                playlist[0] = realm.where(Playlist.class).equalTo("id",playlistId).equalTo("Type",playlistType).findFirst();
            }
        });
        return playlist[0];
    }

   /* //get all songs
    public ArrayList<Song> getAllSongs(final RealmList<String> idList) {
        final ArrayList<Song> playlists = new ArrayList<>();
        // Create an new array to avoid concurrency problem.
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                for (String id:idList) {
                    Song song = realm.where(Song.class).equalTo("item_id",id).findFirst();
                    playlists.add(song);
                }
            }
        });
        return playlists;
    }*/

}
