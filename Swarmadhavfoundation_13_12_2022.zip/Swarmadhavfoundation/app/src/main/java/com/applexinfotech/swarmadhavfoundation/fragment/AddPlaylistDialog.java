package com.applexinfotech.swarmadhavfoundation.fragment;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.PlayListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;
import com.applexinfotech.swarmadhavfoundation.model.Song;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;

import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;

public class AddPlaylistDialog extends DialogFragment implements OnItemClickListener<SubCategoryModel> {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String CURRENT_SONG = "CurrentSong";
    private ArrayList<Playlist> playList;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private  RealmHelper realmHelper;
    private MainActivity mContext;
    private SubCategoryModel categoryModel;
    private AlertDialog playlistDialog;

    public AddPlaylistDialog() {
        // Required empty public constructor
    }

    public static AddPlaylistDialog newInstance(String param1, SubCategoryModel param2,String param3) {
        AddPlaylistDialog fragment = new AddPlaylistDialog();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param3);
        args.putSerializable(CURRENT_SONG, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View formElementsView = layoutInflater.inflate(R.layout.add_to_playlist_dialog,
                null, false);

        // You have to list down your form elements
        Button newPlaylist = formElementsView.findViewById(R.id.new_playlist);
        RecyclerView playlistRecycler = formElementsView.findViewById(R.id.playlist_recycler);
        LinearLayout noPlaylist = formElementsView.findViewById(R.id.noItemFound);
        Button close=formElementsView.findViewById(R.id.close);
        playList = new ArrayList<>();
        playList = realmHelper.getAllPlaylist();
        if (playList != null && !playList.isEmpty()) {
            noPlaylist.setVisibility(View.GONE);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            playlistRecycler.setLayoutManager(linearLayoutManager);
            PlayListAdapter playListAdapter = new PlayListAdapter(mContext, playList, this, categoryModel, true);
            playlistRecycler.setAdapter(playListAdapter);
        } else {
            noPlaylist.setVisibility(View.VISIBLE);
            playlistRecycler.setVisibility(View.GONE);
        }
        // the alert dialog
        playlistDialog = new AlertDialog.Builder(mContext).setView(formElementsView)
                .setTitle(R.string.add_to_playlist).show();
        newPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playlistDialog.dismiss();
                showCreatePlaylistDialog();
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        return playlistDialog;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            categoryModel = (SubCategoryModel) getArguments().getSerializable(CURRENT_SONG);
        }
        mContext= (MainActivity) getActivity();
        realmHelper = new RealmHelper();
    }

    private void showCreatePlaylistDialog() {
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View view = layoutInflater.inflate(R.layout.create_playlist_dialog, null);
        final AlertDialog alertDialog = new AlertDialog.Builder(mContext).create();
        alertDialog.setCancelable(false);
        alertDialog.setView(view);
        Button createBtn = view.findViewById(R.id.create_button);
        Button cancelBtn = view.findViewById(R.id.cancel_button);
        final EditText playlistName = view.findViewById(R.id.playlist_et);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                dismiss();
            }
        });
        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (playlistName.getText().toString().trim().length() == 0) {
                    ToastUtil.showShortToastMessage(getApplicationContext(), "Enter playlist name.");
                    return;
                } else if (playlistExist(playlistName.getText().toString().trim())) {
                    ToastUtil.showShortToastMessage(getApplicationContext(), "You already have a playlist with this name.Please enter a different name");
                    return;
                } else {
                    Playlist play = new Playlist();
                    play.setName(playlistName.getText().toString().trim());
                    play.setType(mParam2);
                    realmHelper.addSongToPlaylist(play, categoryModel);
                    ToastUtil.showShortToastMessage(getApplicationContext(), "Playlist "+play.getName()+" created successfully.");
                    alertDialog.dismiss();
                    dismiss();
                }

            }
        });

        alertDialog.show();
    }

    private boolean playlistExist(String trim) {
        boolean bool = false;
        if (playList != null && !playList.isEmpty()) {
            for (Playlist item : playList) {
                if (item.getName().equals(trim)) {
                    bool = true;
                    break;
                }
            }
        }
        return bool;
    }


    @Override
    public void onItemClick(View v, int position, SubCategoryModel subCategoryModel) {
        dismiss();
        if (playList != null && !playList.isEmpty() && playList.size() > position) {
            Playlist playlist = playList.get(position);
            boolean isPresent = false;
            for (Song s : playlist.getSongs()) {
                if (s.getItem_id().equals(subCategoryModel.getItem_id())) {
                    isPresent = true;
                    ToastUtil.showShortToastMessage(getApplicationContext(), "Song is already present in " + playList.get(position).getName());
                    break;
                } else {
                    isPresent = false;
                }
            }

            if (!isPresent) {
                realmHelper.addSongToPlaylist(playList.get(position), subCategoryModel);
                ToastUtil.showShortToastMessage(getApplicationContext(), subCategoryModel.getDownload_name() + " added to " + playList.get(position).getName());
                StorageUtil storage = new StorageUtil(getApplicationContext());
                int currentId = storage.loadCurrentPlaylistId();
                if (storage.loadMode() == 2 &&  currentId!= -1) {
                    int selectedId = playList.get(position).getId();
                    if (currentId == selectedId) {
                        ArrayList<SubCategoryModel> nowPlayingList = storage.loadAudio();
                        nowPlayingList.add(subCategoryModel);
                        storage.storeAudio(nowPlayingList);
                    }
                }

            }
        } else {
            ToastUtil.showShortToastMessage(getApplicationContext(), "Something went wrong.");
        }

    }
}
