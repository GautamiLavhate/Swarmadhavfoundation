package com.applexinfotech.swarmadhavfoundation.model;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 02-01-2016.
 */
public class SubCategoryModel extends MasterModel
{
    private static final long serialVersionUID = 6104048947898684570L;
    public static final int STATUS_DOWNLOADING = 3;
    public static final int STATUS_COMPLETE = 6;
    public static final int STATUS_PAUSE=1;

    private String item_id;
    private String item_name;
    private String item_description;
    private String download_name;
    private String item_file;
    private String item_image;
    private String lyrics_file;
    private String lyrics_filePdf;

    private String is_accesible;
    private String category_id;
    private String category_name;
    private String category_image;
    private String TypeHm;
    private int progress;
    private int status;
    public boolean isDownloaded;
    private String video_url;
    private String update_count;

    public String getIs_accesible(){
        return is_accesible;
    }
    public void  setIs_accesible(String is_accesible){
        this.is_accesible=is_accesible;
    }
    public String getUpdate_count() {
        return update_count;
    }

    public void setUpdate_count(String update_count) {
        this.update_count = update_count;
    }

    public String getTypeHm() {
        return TypeHm;
    }

    public void setTypeHm(String typeHm) {
        TypeHm = typeHm;
    }

    public String getLyrics_filePdf() {
        return lyrics_filePdf;
    }

    public void setLyrics_filePdf(String lyrics_filePdf) {
        this.lyrics_filePdf = lyrics_filePdf;
    }

    public String getVideo_url() {
        return video_url;
    }

    public void setVideo_url(String video_url) {
        this.video_url = video_url;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getItem_description() {
        return item_description;
    }

    public void setItem_description(String item_description) {
        this.item_description = item_description;
    }

    public String getItem_file() {
        return item_file;
    }

    public void setItem_file(String item_file) {
        this.item_file = item_file;
    }

    public String getItem_image() {
        return item_image;
    }

    public void setItem_image(String item_image) {
        this.item_image = item_image;
    }

    public String getDownload_name() {
        return download_name;
    }

    public void setDownload_name(String download_name) {
        this.download_name = download_name;
    }


    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_image() {
        return category_image;
    }

    public void setCategory_image(String category_image) {
        this.category_image = category_image;
    }

    public boolean isDownloaded() {
        return isDownloaded;
    }

    public void setDownloaded(boolean downloaded) {
        isDownloaded = downloaded;
    }

    public SubCategoryModel getCategoryFromRealm(SongModel songModel){
        SubCategoryModel subCategoryModel=new SubCategoryModel();
        subCategoryModel.setItem_id(songModel.getItem_id());
        subCategoryModel.setItem_name(songModel.getItem_name());
        subCategoryModel.setItem_image(songModel.getItem_image());
        subCategoryModel.setItem_file(songModel.getItem_file());
        subCategoryModel.setItem_description(songModel.getItem_description());
        subCategoryModel.setDownload_name(songModel.getDownload_name());
        subCategoryModel.setCategory_id(songModel.getCategory_id());
        subCategoryModel.setCategory_name(songModel.getCategory_name());
        subCategoryModel.setCategory_image(songModel.getCategory_image());
        subCategoryModel.setLyrics_file(songModel.getLyrics_file());
        subCategoryModel.setVideo_url(songModel.getVideo_url());
        subCategoryModel.setLyrics_filePdf(songModel.getLyrics_filePdf());
        return subCategoryModel;
    }
    public String getLyrics_file() {
        return lyrics_file;
    }

    public void setLyrics_file(String lyrics_file) {
        this.lyrics_file = lyrics_file;
    }
}
