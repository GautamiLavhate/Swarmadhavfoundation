package com.applexinfotech.swarmadhavfoundation.fragment;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;

import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;

public class LyricsDialogFragment extends MasterFragment {
    private static final String TAG = "LyricsDialogFragment";
    private TextView lyricsView;
    private MainActivity mContext;
    private final Handler handler2 = new Handler();
    private final static String TARGET_BASE_PATH = Constants.DIRECTORY_PATH + Constants.LYRICS_FOLDER_PATH;
    private String isPlayingFrom,LyriesTextview;
    private Bundle bundle;



    public static LyricsDialogFragment newInstance() {
        return new LyricsDialogFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = (MainActivity) getMasterActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //((MainActivity) getActivity()).setMusicStateListenerListener(this);
        return inflater.inflate(R.layout.dialog_lyrics_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.lyrics));
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });
        lyricsView = view.findViewById(R.id.custom_lyric_view);

        bundle = getArguments();
        if (bundle != null) {
            LyriesTextview = bundle.getString("Lyries");
        }


        String textColor=getResources().getString(R.color.primaryTextColor).substring(3);
        String backgroundColor=getResources().getString(R.color.colorPrimary).substring(3);

        if(LyriesTextview==null || LyriesTextview.equals(" ")){
            lyricsView.setText("No Data");
        }else {

            String text = "<html><body style=\"color:"+textColor+";font-family:file:///android_asset//ProximaNova-Light.otf;font-size:16px;\"'background-color:"+backgroundColor+"' >"
                    + "<p align=\"justify\">"
                    + LyriesTextview
                    + "</p>"
                    + "</body></html>";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                lyricsView.setText(Html.fromHtml("<font>" + text + "</font>", Html.FROM_HTML_MODE_COMPACT));
            }
        }

        updateLyricsView();

    }

    private void updateLyricsView() {
        StorageUtil storage = new StorageUtil(getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        int audioIndex = storage.loadAudioIndex();
        isPlayingFrom = storage.loadIsPlayingFrom();
        if (audioList != null) {
            if ((audioList.size() > 0) && audioIndex < audioList.size()) {
                String lyries=audioList.get(audioIndex).getLyrics_file();

                if(lyries==null || lyries.equals(" ")){
                    lyricsView.setText("No Data");
                }else {
                    String textColor=getResources().getString(R.color.primaryTextColor).substring(3);
                    String backgroundColor=getResources().getString(R.color.colorPrimary).substring(3);

                    String text = "<html><body style=\"color:"+textColor+";font-family:file:///android_asset//ProximaNova-Light.otf;font-size:16px;\"'background-color:"+backgroundColor+"' >"
                            + "<p align=\"justify\">"
                            + lyries
                            + "</p>"
                            + "</body></html>";

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        lyricsView.setText(Html.fromHtml("<font>" + text + "</font>", Html.FROM_HTML_MODE_COMPACT));
                    }
                }
            } else {

            }
        }

    }
}
