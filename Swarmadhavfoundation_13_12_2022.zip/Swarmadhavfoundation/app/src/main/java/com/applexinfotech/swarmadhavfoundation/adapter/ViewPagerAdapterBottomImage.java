package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.toolbox.ImageLoader;
import com.applexinfotech.swarmadhavfoundation.CustomVolleyRequeat;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.model.FooterSliderUtils;
import com.applexinfotech.swarmadhavfoundation.model.SliderUtils;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ViewPagerAdapterBottomImage extends PagerAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<FooterSliderUtils> footerSliderImg;
    private ImageLoader imageLoader;

    // Viewpager Constructor
    public ViewPagerAdapterBottomImage(ArrayList footerSliderImg,Context context) {
        this.footerSliderImg=footerSliderImg;
        this.context = context;

    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return super.getItemPosition(object);
    }

    @Override
    public int getCount() {
        return footerSliderImg.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container,final int position) {
        layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view=layoutInflater.inflate(R.layout.layout_footer_image_view,null);
        FooterSliderUtils utils=footerSliderImg.get(position);
        ImageView imageView = (ImageView) view.findViewById(R.id.img_view_footer_slider);
        imageLoader= CustomVolleyRequeat.getInstance(context).getImageLoader();
        //imageLoader.get(utils.getFootersliderImageUrl(),imageLoader.getImageListener(imageView,R.drawable.new_launching_logo, android.R.drawable.ic_dialog_alert));
        Glide.with(view.getContext())
                .load(utils.getFootersliderImageUrl())
                .into(imageView);

        ViewPager vp=(ViewPager) container;
        vp.addView(view,0);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        ViewPager vp = (ViewPager) container;
        View view = (View) object;
        vp.removeView(view);
    }
}
