package com.applexinfotech.swarmadhavfoundation.helpers;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 16-07-29.
 */
public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
