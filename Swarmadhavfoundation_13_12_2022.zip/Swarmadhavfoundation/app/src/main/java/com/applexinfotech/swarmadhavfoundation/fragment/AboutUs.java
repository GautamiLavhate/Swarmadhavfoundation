package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import org.json.JSONArray;
import org.json.JSONObject;

import me.biubiubiu.justifytext.library.JustifyTextView;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2018.
 */
public class AboutUs extends MasterFragment {
    private MainActivity mContext;
    private String mContent;
    private TextView textView1,email,mobile,address,websidearth;
    private JustifyTextView appinno;
    private TextView textView2;
    private String textColor,backgroundColor;
    LinearLayout linearLayoutAboutUsemail,linearLayoutAboutUsContactNo,linearLayoutAboutUsWeb,linearLayoutAboutUsAddress;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.aboutus_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.about_us));

        textView1 = view.findViewById(R.id.textView1_about_us);
        textView2 = view.findViewById(R.id.textView2_about_us);
        appinno = view.findViewById(R.id.appinno);
        email = view.findViewById(R.id.email);
        mobile = view.findViewById(R.id.mobile);
        address = view.findViewById(R.id.address);
        textView1.setTypeface(getMasterActivity().getTypeFace());
        textView2.setTypeface(getMasterActivity().getTypeFace());
        websidearth=view.findViewById(R.id.websidearth);

        linearLayoutAboutUsemail=view.findViewById(R.id.linearLayoutAboutUsEmail);
        linearLayoutAboutUsContactNo=view.findViewById(R.id.linearLayoutAboutUsContactUs);
        linearLayoutAboutUsWeb=view.findViewById(R.id.linearLayoutAboutUsWeb);
        linearLayoutAboutUsAddress=view.findViewById(R.id.linearLayoutAboutUsLocation);

        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        if (mContext.isInternet) {
            getAboutUs();
        } else {
            ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
        }

        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        linearLayoutAboutUsemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_SEND);
                String[] recipients={"swarmadhavfoundationpune@gmail.com"};
                intent.putExtra(Intent.EXTRA_EMAIL, recipients);
//                intent.putExtra(Intent.EXTRA_SUBJECT,"Subject text here...");
//                intent.putExtra(Intent.EXTRA_TEXT,"Body of the content here...");
                intent.putExtra(Intent.EXTRA_CC,"mailcc@gmail.com");
                intent.setType("text/html");
                intent.setPackage("com.google.android.gm");
                startActivity(Intent.createChooser(intent, "Send mail"));
            }
        });
        linearLayoutAboutUsContactNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number=mobile.getText().toString();
                Intent callIntent=new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:"+number));
                startActivity(callIntent);
            }
        });
        linearLayoutAboutUsWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.google.com/search?q=swarmadhavfounation+pune&rlz=1C1SQJL_enIN937IN937&oq=swarmadhavfounation+pune&aqs=chrome..69i57.12753j1j7&sourceid=chrome&ie=UTF-8";
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    Uri uri = Uri.parse(url);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }else{
                    Toast.makeText(mContext, "Invalid Url", Toast.LENGTH_SHORT).show();
                }
            }
        });
        linearLayoutAboutUsAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Uri gmmIntentUri = Uri.parse("geo:0,0?q=");
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                    }
                }, 1000);
            }
        });

    }


    private void getAboutUs() {
        mContext.showWaitIndicator(true);
        String url = Constants.API_Get_AboutUs_swar;

        StringRequest strReq = new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                try {
                    if (response != null) {
                        Log.d("ABOUTUS_API", "" + response.toString());
                        //Toast.makeText(getContext(), url, Toast.LENGTH_SHORT).show();
                        JSONObject jObject = new JSONObject(response.toString());
                        String status = jObject.getString("response_status");

                        if (status.equalsIgnoreCase("1")) {
                            JSONArray data = jObject.getJSONArray("data");
                            String addressst= data.getJSONObject(0).getString("address");
                            String AppInfo= data.getJSONObject(0).getString("app_info");
                            String emailst= data.getJSONObject(0).getString("email");
                            String mobilest= data.getJSONObject(0).getString("mobile");
                            final String website= data.getJSONObject(0).getString("website");

                            appinno.setText(AppInfo);
                            email.setText(emailst);
                            mobile.setText(mobilest);
                            address.setText(addressst);
                            websidearth.setText(website);


                            textView2.setText(website);
                            textView2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(website));
                                    startActivity(browserIntent);
                                }
                            });



                        } else {
                            mContext.showWaitIndicator(false);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mContext.showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });

        Volley.newRequestQueue(getMasterActivity()).add(strReq);
    }

}
