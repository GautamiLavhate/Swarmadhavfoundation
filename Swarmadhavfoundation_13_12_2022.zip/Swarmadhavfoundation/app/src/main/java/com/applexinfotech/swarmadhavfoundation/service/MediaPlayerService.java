package com.applexinfotech.swarmadhavfoundation.service;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.MediaStore;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.media.app.NotificationCompat;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.PlaybackStatus;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.audio.AudioRendererEventListener;
import com.google.android.exoplayer2.decoder.DecoderCounters;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.FileDataSource;
import com.google.android.exoplayer2.util.Util;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.ASSET_SONG_FOLDER_PATH;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.DOWNLOADS;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_ASSETS;

public class MediaPlayerService extends Service implements AudioManager.OnAudioFocusChangeListener {
    private static final String BHAKTISANGRAH_PACKAGE_NAME = "com.applex.swarsageetmala";
    private static final String MUSIC_PACKAGE_NAME = "com.android.music";
    public static final String CHANNEL_ID = "com.applex.swarsageetmala";
    public static final String UPDATE_SONG_STATUS = "com.applex.swarsageetmala.UPDATE_SONG_STATUS";
    public static final String REFRESH = "com.applex.swarsageetmala.REFRESH";
    public static final String REFRESH_AUDIO_SESSION_ID = "com.applex.swarsageetmala.REFRESH_AUDIO_SESSION_ID";
    public static final String STOP_PROGRESS = "com.applex.swarsageetmala.STOP_PROGRESS";
    public static final String ACTION_PLAY = "com.applex.swarsageetmala.ACTION_PLAY";
    public static final String ACTION_PAUSE = "com.applex.swarsageetmala.ACTION_PAUSE";
    public static final String ACTION_PREVIOUS = "com.applex.swarsageetmala.ACTION_PREVIOUS";
    public static final String ACTION_NEXT = "com.applex.swarsageetmala.ACTION_NEXT";
    public static final String ACTION_STOP = "com.applex.swarsageetmala.ACTION_STOP";
    public static final String META_CHANGED = "com.applex.swarsageetmala.META_CHANGED";
    public static final String TRACK_ERROR = "com.applex.swarsageetmala.trackerror";
    private static final String SHUTDOWN = "com.applex.swarsageetmala.shutdown";
    private static final int IDLE_DELAY = 5 * 60 * 1000;
    private SimpleExoPlayer mediaPlayer;
    private static final int NOTIFY_MODE_NONE = 0;
    boolean isPlaying = false;
    public static int SESSION_ID_NOT_SET = 0;

    //MediaSession
    private MediaSessionManager mediaSessionManager;
    private MediaSessionCompat mediaSession;
    private MediaControllerCompat.TransportControls transportControls;

    //AudioPlayer notification ID
    public static final int NOTIFICATION_ID = 101;

    //Used to pause/resume MediaPlayer
    private long resumePosition;

    //AudioFocus
    private AudioManager audioManager;

    // Binder given to clients
    private final IBinder iBinder = new LocalBinder();

    //List of available Audio files
    private ArrayList<SubCategoryModel> audioList = new ArrayList<>();
    private int audioIndex;
    private SubCategoryModel activeAudio; //an object on the currently playing audio


    //Handle incoming phone calls
    private boolean ongoingCall = false;
    public boolean isPlayerPrepared = false;
    public boolean isRepeat = false;
    private boolean isShuffle = false;
    private PhoneStateListener phoneStateListener;
    private TelephonyManager telephonyManager;
    private Bitmap albumArt;
    private Bitmap largeIcon;
    public int noOfRepeats, repeatCount;

    private NotificationManager mNotificationManager;
    private int nextAudioIndex = -1;
    private int userMode;
    private int playedIndex;
    private AlarmManager mAlarmManager;
    private PendingIntent mShutdownIntent;
    private boolean mShutdownScheduled;
    private int mNotifyMode = NOTIFY_MODE_NONE;
    private int mNotificationPostTime;
    private long mLastPlayedTime;
    private boolean isSongCompleted = false;
    public String isFrom;
    private boolean mIsDucked;
    private boolean mLostAudioFocus;
    private String isPlayingFrom;
    private static final String TAG = "MediaPlayerService";
    boolean isFromUSB=false;
    private int audioSessionId;

    private AudioRendererEventListener debugListener = new AudioRendererEventListener() {
        @Override
        public void onAudioEnabled(DecoderCounters counters) {

        }

        @Override
        public void onAudioSessionId(int asessionId) {
            audioSessionId = asessionId;
            Log.e("audioSessionId","======"+asessionId);
            notifyChange(REFRESH_AUDIO_SESSION_ID);
        }

        @Override
        public void onAudioDecoderInitialized(String decoderName, long initializedTimestampMs, long initializationDurationMs) {

        }

        @Override
        public void onAudioInputFormatChanged(Format format) {

        }

        @Override
        public void onAudioTrackUnderrun(int bufferSize, long bufferSizeMs, long elapsedSinceLastFeedMs) {

        }

        @Override
        public void onAudioDisabled(DecoderCounters counters) {
           audioSessionId = SESSION_ID_NOT_SET;
        }
    };

    public boolean isPlayerPrepared() {
        return isPlayerPrepared;
    }

    private final ExoPlayer.EventListener eventListener = new ExoPlayer.EventListener() {
        @Override
        public void onTimelineChanged(Timeline timeline, Object manifest) {
            Log.e(TAG, "onTimelineChanged");
        }

        @Override
        public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
            Log.e(TAG, "onTracksChanged");
        }

        @Override
        public void onLoadingChanged(boolean isLoading) {
           // Log.e(TAG, "onLoadingChanged");
        }

        @Override
        public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
            Log.e(TAG, "onPlayerStateChanged: playWhenReady = " + String.valueOf(playWhenReady)
                    + " playbackState = " + playbackState);
            switch (playbackState) {
                case ExoPlayer.STATE_ENDED:
                    StorageUtil storage = new StorageUtil(getApplicationContext());
                    audioIndex = storage.loadAudioIndex();
                    Log.e(TAG, "Playback ended!" + "audio index=" + String.valueOf(audioIndex));
                    //Stop playback and return to start position
                    if (playWhenReady) {
                        isSongCompleted = true;
                        notifyChange(STOP_PROGRESS);
                        playedIndex = audioIndex;
                        new StorageUtil(getApplicationContext()).storePlayedAudioIndex(playedIndex);
                        notifyChange(UPDATE_SONG_STATUS);
                        isPlayerPrepared = false;
                        if (isRepeat()) {
                            Log.e("before", String.valueOf(noOfRepeats));
                            if (noOfRepeats != 1) {
                                noOfRepeats = noOfRepeats - 1;
                                Log.e("after", String.valueOf(noOfRepeats));
                                initMediaPlayer();
                            } else {
                                noOfRepeats = repeatCount;
                                Log.e("updated", String.valueOf(noOfRepeats));
                                playNextTrack();
                            }

                        } else if (isShuffle()) {
                            playShuffledTracks();
                        } else if (playWhenReady) {
                            playNextTrack();
                        }
                    }

                    break;
                case ExoPlayer.STATE_READY:
                    Log.e(TAG, "ExoPlayer ready! pos: " + mediaPlayer.getCurrentPosition()
                            + " max: " + Utilities.stringForTime((int) mediaPlayer.getDuration()));
                    // setProgress();
                    break;
                case ExoPlayer.STATE_BUFFERING:
                    Log.e(TAG, "Playback buffering!");
                    break;
                case ExoPlayer.STATE_IDLE:
                    Log.e(TAG, "ExoPlayer idle!");
                    break;
            }
        }

        @Override
        public void onPlayerError(ExoPlaybackException error) {
            Log.e(TAG, "onPlaybackError: " + error.getMessage());
        }

        @Override
        public void onPositionDiscontinuity() {
            Log.e(TAG, "onPositionDiscontinuity");
        }
    };

    /**
     * Service lifecycle methods
     */
    @Override
    public IBinder onBind(Intent intent) {
        return iBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // Perform one-time setup procedures

        // Manage incoming phone calls during playback.
        // Pause MediaPlayer on incoming call,
        // Resume on hangup.
        callStateListener();
        //ACTION_AUDIO_BECOMING_NOISY -- change in audio outputs -- BroadcastReceiver
        registerBecomingNoisyReceiver();

        //Listen for new Audio to play -- BroadcastReceiver
        register_playNewAudio();
        //Notification channel for android O
        createNotificationChannel();
        final Intent shutdownIntent = new Intent(this, MediaPlayerService.class);
        shutdownIntent.setAction(SHUTDOWN);

        mAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        mShutdownIntent = PendingIntent.getService(this, 0, shutdownIntent, 0);

        //scheduleDelayedShutdown();
    }

    //The system calls this method when an activity, requests the service be started
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //Handle Intent action from MediaSession.TransportControls
        handleIncomingActions(intent);
        return super.onStartCommand(intent, flags, startId);
    }


    private void releaseServiceUiAndStop() {
        if (isMediaPlaying()) {
            pauseMedia();
            stopMedia();
        }
        if (!isMediaPlaying()) {
            Log.e(TAG, "Nothing is playing anymore, releasing notification");
            cancelNotification();
            removeAudioFocus();
            stopSelf();
        }
    }

    public void playSong() {
        try {
            //Load data from SharedPreferences
            StorageUtil storage = new StorageUtil(getApplicationContext());
            audioList = storage.loadAudio();
            audioIndex = storage.loadAudioIndex();
            userMode = storage.loadMode();


            if (audioIndex != -1 && audioIndex < audioList.size()) {
                //index is in a valid range
                activeAudio = audioList.get(audioIndex);
                // nextAudioIndex=audioIndex;
            } else {
                stopSelf();
            }
        } catch (NullPointerException e) {
            stopSelf();
        }

        //Request audio focus
        if (!requestAudioFocus()) {
            //Could not gain focus
            stopSelf();
        }

        if (mediaSessionManager == null) {
            try {
                initMediaSession();

            } catch (RemoteException e) {
                e.printStackTrace();
                stopSelf();
            }

        }
        initMediaPlayer();

    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (mediaSession != null) {
            mediaSession.release();
        }
        removeNotification();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            stopMedia();
        }
        removeAudioFocus();
        //Disable the PhoneStateListener
        if (phoneStateListener != null) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        }
        mAlarmManager.cancel(mShutdownIntent);
        removeNotification();

        //unregister BroadcastReceivers
        unregisterReceiver(becomingNoisyReceiver);
        unregisterReceiver(playNewAudio);

        //clear cached playlist
        audioList = null;
        audioIndex = -1;
        new StorageUtil(getApplicationContext()).storePlayedAudioIndex(-1);
        stopSelf();
        //clear cached playlist
        // new StorageUtil(getApplicationContext()).clearCachedAudioPlaylist();

    }

    private void notifyChange(final String what) {
        Log.e(TAG, "notifyChange: what = " + what);

        final Intent intent = new Intent(what);
        intent.putExtra("id", activeAudio.getItem_id());
        intent.putExtra("artist", activeAudio.getItem_name());
        intent.putExtra("album", activeAudio.getItem_name());
        intent.putExtra("albumid", activeAudio.getItem_id());
        intent.putExtra("track", activeAudio.getItem_file());
        intent.putExtra("playing", isMediaPlaying());

        sendBroadcast(intent);
        final Intent musicIntent = new Intent(intent);
        musicIntent.setAction(what.replace(BHAKTISANGRAH_PACKAGE_NAME, MUSIC_PACKAGE_NAME));
        sendBroadcast(musicIntent);
    }

    public void playNextTrack() {
        skipToNext();
    }

    public void playPreviousTrack() {
        skipToPrevious();
    }

    public void resumeMediaPlay() {
        resumeMedia();
    }

    public void pauseMediaPlay() {
        pauseMedia();
    }

    public long getDuration() {
        long duration = 0;
        if (mediaPlayer != null || isPlayerPrepared) {
            assert mediaPlayer != null;
            duration = mediaPlayer.getDuration();
            // Log.e("in milliseconds: " , String.valueOf(duration));
        }

        return duration;
    }

    public long getCurrentPosition() {
        long position = 0;
        if (mediaPlayer != null || isPlayerPrepared) {
            assert mediaPlayer != null;
            position = mediaPlayer.getCurrentPosition();
            //   Log.e("currentPosition",String.valueOf(position));
        }
        return position;
    }

    public void seekTo(long currentPosition) {
        if (mediaPlayer != null || isPlayerPrepared) {
            Log.e("seek to", String.valueOf(currentPosition));
            mediaPlayer.seekTo(currentPosition);
        }
    }

    public boolean isMediaPlaying() {
        if (mediaPlayer == null) {
            return false;
        }
        if (mediaPlayer != null || isPlayerPrepared) {
            isPlaying = mediaPlayer.getPlayWhenReady();
        }
        return isPlaying;
    }

    public void setMode(int mode) {
        userMode = mode;
    }


    /**
     * Service Binder
     */
    public class LocalBinder extends Binder {
        public MediaPlayerService getService() {
            // Return this instance of LocalService so clients can call public methods
            return MediaPlayerService.this;
        }
    }

    public void playShuffledTracks() {
        // shuffle is on - play a random song
        Random random = new Random();
        audioIndex = random.nextInt((audioList.size() - 1) - 0 + 1);
        //Update stored index
        new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);
        initMediaPlayer();
    }


    @Override
    public void onAudioFocusChange(int focusState) {

        //Invoked when the audio focus of the system is updated.
        switch (focusState) {
            case AudioManager.AUDIOFOCUS_GAIN:
                // resume playback
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_GAIN");
                if (mIsDucked) {
                    mIsDucked = false;
                    if (mediaPlayer != null && mediaPlayer.getPlayWhenReady())
                        mediaPlayer.setVolume(1.0f);
                } else if (mLostAudioFocus) {
                    mLostAudioFocus = false;
                    if (mediaPlayer != null && !mediaPlayer.getPlayWhenReady()) resumeMedia();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_LOSS");
                // Lost focus for an unbounded amount of time: stop playback and release media player
                if (mediaPlayer != null && mediaPlayer.getPlayWhenReady()) {
                    pauseMedia();
                    //  if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_LOSS_TRANSIENT");
                // Lost focus for a short time, but we have to stop
                // playback. We don't release the media player because playback
                // is likely to resume
                if (mediaPlayer != null && mediaPlayer.getPlayWhenReady()) {
                    mLostAudioFocus = true;
                    pauseMedia();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK");
                // Lost focus for a short time, but it's ok to keep playing
                // at an attenuated level
                if (mediaPlayer != null && mediaPlayer.getPlayWhenReady()) {
                    mIsDucked = true;
                    mediaPlayer.setVolume(0.5f);
                }
                break;

        }
    }


    /**
     * AudioFocus
     */
    private boolean requestAudioFocus() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        //Focus gained
        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        //Could not gain focus
    }

    private boolean removeAudioFocus() {
        if (audioManager != null) {
            return AudioManager.AUDIOFOCUS_REQUEST_GRANTED ==
                    audioManager.abandonAudioFocus(this);
        }
        return false;
    }

    private void initMediaPlayer() {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.setPlayWhenReady(false);
                mediaPlayer.stop();
                mediaPlayer.seekTo(0);
                mediaPlayer.release();
            }
            //initialize Exo player
            TrackSelector trackSelector = new DefaultTrackSelector();
            LoadControl loadControl = new DefaultLoadControl();
            mediaPlayer = ExoPlayerFactory.newSimpleInstance(this, trackSelector, loadControl);
            mediaPlayer.addListener(eventListener);
            mediaPlayer.setAudioDebugListener(debugListener);

            StorageUtil storage = new StorageUtil(getApplicationContext());
            audioList = storage.loadAudio();
            audioIndex = storage.loadAudioIndex();
            Log.e(TAG, "initMediaPlayer!" + "audioIndex=" + String.valueOf(audioIndex));

            userMode = storage.loadMode();
            if (audioIndex != -1 && audioIndex < audioList.size()) {
                //index is in a valid range
                activeAudio = audioList.get(audioIndex);
                // nextAudioIndex=audioIndex;
            } else {
                stopSelf();
            }

            // Set the data source to the mediaFile location
            isPlayingFrom = storage.loadIsPlayingFrom();
            if (!isPlayingFrom.equalsIgnoreCase(DOWNLOADS) && MasterActivity.fileAlreadyExist(activeAudio.getDownload_name() + ".mp3")) {
                Log.e("FromDownload", "playing from download");
                String path = Constants.DIRECTORY_PATH + Constants.SONG_FOLDER_PATH + activeAudio.getDownload_name() + ".mp3";
                Log.e("file : ", "==" + path);
                prepareExoPlayerFromFileUri(Uri.fromFile(new File(path)));
            } else if(isPlayingFrom.equalsIgnoreCase(FROM_ASSETS) || userMode==4 ){
                prepareExoPlayerFromURL(Uri.parse(ASSET_SONG_FOLDER_PATH+activeAudio.getItem_file()));
            }else {
                Log.e("FromURL", "playing from getItem_file");
                Log.e("file : ", "==" + activeAudio.getItem_file());
                // mediaPlayer.setDataSource(activeAudio.getItem_file());
                if (activeAudio.getItem_file().startsWith("https")) {
                    prepareExoPlayerFromURL(Uri.parse(activeAudio.getItem_file()));
                } else {
                    prepareExoPlayerFromFileUri(Uri.fromFile(new File(activeAudio.getItem_file())));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            stopSelf();
        }

    }

    /**
     * Prepares exoplayer for audio playback from a remote URL audiofile. Should work with most
     * popular audiofile types (.mp3, .m4a,...)
     *
     * @param uri Provide a Uri in a form of Uri.parse("http://blabla.bleble.com/blublu.mp3)
     */
    private void prepareExoPlayerFromURL(Uri uri) {
        DefaultDataSourceFactory dataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, "exoplayer2example"), null);
        ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
        MediaSource audioSource = new ExtractorMediaSource(uri, dataSourceFactory, extractorsFactory, null, null);

     /*   MediaSource[] mediaSources = new MediaSource[audioList.size()];
        for (int i = 0; i < mediaSources.length; i++) {
            String songUri = audioList.get(i).getItem_file();
            mediaSources[i] = new ExtractorMediaSource(Uri.parse(songUri), dataSourceFactory, extractorsFactory, null, null);
        }
        MediaSource mediaSource = mediaSources.length == 1 ? mediaSources[0]
                : new ConcatenatingMediaSource(mediaSources);
*/
        mediaPlayer.prepare(audioSource);

        isPlayerPrepared = true;
        if(isPlayingFrom.equalsIgnoreCase(FROM_ASSETS) || userMode==4){
            playMedia();
        }
        else{
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Do something after 5s = 5000ms
                    playMedia();
                }
            }, 1500);

        }

    }

    /**
     * Prepares exoplayer for audio playback from a local file
     *
     * @param uri
     */
    private void prepareExoPlayerFromFileUri(Uri uri) {
        DataSpec dataSpec = new DataSpec(uri);
        final FileDataSource fileDataSource = new FileDataSource();
        try {
            fileDataSource.open(dataSpec);
        } catch (FileDataSource.FileDataSourceException e) {
            e.printStackTrace();
        }

        DataSource.Factory factory = new DataSource.Factory() {
            @Override
            public DataSource createDataSource() {
                return fileDataSource;
            }
        };
        MediaSource audioSource = new ExtractorMediaSource(fileDataSource.getUri(),
                factory, new DefaultExtractorsFactory(), null, null);

        mediaPlayer.prepare(audioSource);
        isPlayerPrepared = true;
        playMedia();


    }

    private void playMedia() {
        isSongCompleted = false;
        if (mediaPlayer == null) return;
        if (!mediaPlayer.getPlayWhenReady() && audioList != null) {
            if(userMode == 3 || userMode==4){
                //do nothing
                Log.e(TAG, "storeToRecentlyPlayed not called coz userMode =" + String.valueOf(userMode));
            }else {
                storeToRecentlyPlayed(audioList.get(audioIndex));
            }
            //mediaPlayer.start();
            mediaPlayer.setPlayWhenReady(true);
            // isPlaying=true;

            updateMetaData();
            buildNotification(PlaybackStatus.PLAYING);
            notifyChange(META_CHANGED);
            notifyChange(REFRESH);
        }
    }

    private void stopMedia() {
        if (mediaPlayer == null) return;
        if (mediaPlayer.getPlayWhenReady()) {
            notifyChange(STOP_PROGRESS);
            notifyChange(META_CHANGED);
            isPlayerPrepared = false;
            // isPlaying=false;
            mediaPlayer.stop();
            // mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;

        }
    }

    public void pauseMedia() {
        if (mediaPlayer == null) return;
        if (mediaPlayer.getPlayWhenReady()) {
            // mediaPlayer.pause();
            mediaPlayer.setPlayWhenReady(false);
            //  isPlaying=false;

            resumePosition = mediaPlayer.getCurrentPosition();
            updateMetaData();
            notifyChange(META_CHANGED);
            if(!isFromUSB()){
                buildNotification(PlaybackStatus.PAUSED);
            }


        }
    }

    public void resumeMedia() {
        if (mediaPlayer == null) {
            playSong();
            return;
        }
        if (!mediaPlayer.getPlayWhenReady()) {
            // mediaPlayer.seekTo(resumePosition);
            //mediaPlayer.start();
            mediaPlayer.setPlayWhenReady(true);
            // isPlaying=true;
            updateMetaData();
            buildNotification(PlaybackStatus.PLAYING);
            notifyChange(META_CHANGED);
        }
    }

    public void skipToNext() {
        noOfRepeats = repeatCount;
        StorageUtil storage = new StorageUtil(getApplicationContext());
        audioList = storage.loadAudio();
        audioIndex = storage.loadAudioIndex();
        userMode = storage.loadMode();
        Log.e(TAG, "skipToNext!" + "previous index=" + String.valueOf(audioIndex));
        if (audioIndex == audioList.size() - 1) {
            //if last in playlist
            audioIndex = 0;
            activeAudio = audioList.get(audioIndex);
        } else {
            //get next in playlist
            activeAudio = audioList.get(++audioIndex);
        }

        //Update stored index
        Log.e(TAG, "skipToNext!" + "audio index=" + String.valueOf(audioIndex));
        new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);
        if (mediaSessionManager == null) {
            try {
                initMediaSession();

            } catch (RemoteException e) {
                e.printStackTrace();
                stopSelf();
            }
        }
        initMediaPlayer();
    }

    public void skipToPrevious() {
        noOfRepeats = repeatCount;
        StorageUtil storage = new StorageUtil(getApplicationContext());
        audioList = storage.loadAudio();
        audioIndex = storage.loadAudioIndex();
        userMode = storage.loadMode();

        if (audioIndex == 0) {
            //if first in playlist
            //set index to the last of audioList
            audioIndex = audioList.size() - 1;
            activeAudio = audioList.get(audioIndex);
        } else {
            //get previous in playlist
            activeAudio = audioList.get(--audioIndex);
        }

        //Update stored index
        new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);

        if (mediaSessionManager == null) {
            try {
                initMediaSession();

            } catch (RemoteException e) {
                e.printStackTrace();
                stopSelf();
            }
        }
        initMediaPlayer();
    }


    /**
     * ACTION_AUDIO_BECOMING_NOISY -- change in audio outputs
     */
    private final BroadcastReceiver becomingNoisyReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            //pause audio on ACTION_AUDIO_BECOMING_NOISY
            Log.e("becomingNoisyReceiver:", "ACTION_AUDIO_BECOMING_NOISY");
            pauseMedia();
            buildNotification(PlaybackStatus.PAUSED);
        }
    };

    private void registerBecomingNoisyReceiver() {
        //register after getting audio focus
        IntentFilter intentFilter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        registerReceiver(becomingNoisyReceiver, intentFilter);
       /* IntentFilter intentFilter2 = new IntentFilter(AudioManager.ACTION_HDMI_AUDIO_PLUG);
        registerReceiver(becomingNoisyReceiver, intentFilter2);*/
    }

    /**
     * Handle PhoneState changes
     */
    private void callStateListener() {
        // Get the telephony manager
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        //Starting listening for PhoneState changes
        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                switch (state) {
                    //if at least one call exists or the phone is ringing
                    //pause the MediaPlayer
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                    case TelephonyManager.CALL_STATE_RINGING:
                        if (mediaPlayer != null && mediaPlayer.getPlayWhenReady()) {
                            pauseMedia();
                            ongoingCall = true;
                        }
                        break;
                    case TelephonyManager.CALL_STATE_IDLE:
                        // Phone idle. Start playing.
                        Log.e("Tele:", "ACTION_AUDIO_BECOMING_NOISY");
                        if (mediaPlayer != null) {
                            if (ongoingCall) {
                                ongoingCall = false;
                                resumeMedia();
                            }
                        }
                        break;

                }
            }
        };
        // Register the listener with the telephony manager
        // Listen for changes to the device call state.
        telephonyManager.listen(phoneStateListener,
                PhoneStateListener.LISTEN_CALL_STATE);
    }

    /**
     * MediaSession and Notification actions
     */
    private void initMediaSession() throws RemoteException {
        if (mediaSessionManager != null) return; //mediaSessionManager exists

        mediaSessionManager = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
        // Create a new MediaSession
        mediaSession = new MediaSessionCompat(getApplicationContext(), "AudioPlayer");
        //Get MediaSessions transport controls
        transportControls = mediaSession.getController().getTransportControls();
        //set MediaSession -> ready to receive media commands
        mediaSession.setActive(true);
        //indicate that the MediaSession handles transport control commands
        // through its MediaSessionCompat.Callback.
        mediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);

        //Set mediaSession's MetaData
        updateMetaData();
        // notifyChange(META_CHANGED);

        // Attach Callback to receive MediaSession updates
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            // Implement callbacks
            @Override
            public void onPlay() {
                super.onPlay();
                resumeMedia();

            }

            @Override
            public void onPause() {
                super.onPause();
                pauseMedia();
            }

            @Override
            public void onSkipToNext() {
                super.onSkipToNext();
                notifyChange(STOP_PROGRESS);
                skipToNext();
            }

            @Override
            public void onSkipToPrevious() {
                super.onSkipToPrevious();
                notifyChange(STOP_PROGRESS);
                skipToPrevious();
            }

            @Override
            public void onStop() {
                super.onStop();
                removeNotification();
                updateMetaData();
                notifyChange(STOP_PROGRESS);
                notifyChange(META_CHANGED);
                //Stop the service
                stopSelf();
            }

            @Override
            public void onSeekTo(long position) {
                super.onSeekTo(position);
            }
        });
    }

    private void updateMetaData() {
       /* if (activeAudio == null) {
            return;
        }*/
        if (activeAudio != null && activeAudio.getItem_image() != null) {
            URL url = null;
            try {
                {
                    if (activeAudio.getItem_image().startsWith("https")) {
                        url = new URL(activeAudio.getItem_image());
                        Log.e("build notification", activeAudio.getItem_image());
                       /* Picasso.with(this)
                                .load(String.valueOf(url))
                                .into(new Target() {
                                    @Override
                                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                        albumArt=bitmap;
                                    }

                                    @Override
                                    public void onBitmapFailed(Drawable errorDrawable) {
                                        albumArt = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                                R.drawable.no_image);
                                    }

                                    @Override
                                    public void onPrepareLoad(Drawable placeHolderDrawable) {
                                        albumArt = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                                R.drawable.no_image);
                                    }
                                });*/


                        Glide.with(this)
                                .asBitmap()
                                .load(String.valueOf(url))
                                .into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                        albumArt=resource;
                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {
                                        albumArt = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                                R.drawable.no_image);
                                    }
                                });
                    }else if (userMode == 3) {
                        try {
                            Log.e("build notification", activeAudio.getItem_image());
                            Uri sArtworkUri = Uri
                                    .parse("content://media/external/audio/albumart");
                            Uri albumArtUri = ContentUris.withAppendedId(sArtworkUri, Long.parseLong(activeAudio.getCategory_id()));
                            albumArt = MediaStore.Images.Media.getBitmap(
                                    getApplicationContext().getContentResolver(),albumArtUri);
                        } catch (FileNotFoundException exception) {
                            exception.printStackTrace();
                            Log.e("Exception",exception.toString());
                            albumArt = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                    R.drawable.no_image);
                        } catch (IOException e) {
                            e.printStackTrace();
                            Log.e("Exception",e.toString());
                        }
                    }else if(userMode==4){
                        albumArt=  getBitmapFromAsset(getApplicationContext(),activeAudio.getItem_image());
                    }
                    else { //from downloads
                        Log.e("build notification", activeAudio.getItem_image());
                        albumArt = ShrinkBitmap(activeAudio.getItem_image(),125,125);
                    }
                    if (albumArt == null) {
                        albumArt = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                R.drawable.no_image);
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        } else {

            albumArt = BitmapFactory.decodeResource(getResources(),
                    R.drawable.no_image); //replace with medias albumArt
        }
        // Update the current metadata
        if (activeAudio != null) {
            mediaSession.setMetadata(new MediaMetadataCompat.Builder()
                    .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, albumArt)
                    .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, activeAudio.getItem_id() != null ? activeAudio.getItem_id() : "Unknown Artist")
                    .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, activeAudio.getItem_name() != null ? activeAudio.getItem_name() : "Unknown Album")
                    .putString(MediaMetadataCompat.METADATA_KEY_TITLE, activeAudio.getItem_description() != null ? activeAudio.getItem_description() : "Unknown TITLE")
                    .build());
        }

    }
    public static Bitmap getBitmapFromAsset(Context context, String filePath) {
        AssetManager assetManager = context.getAssets();

        InputStream istr;
        Bitmap bitmap = null;
        try {
            istr = assetManager.open("thumbnail/"+filePath);
            bitmap = BitmapFactory.decodeStream(istr);

        } catch (IOException e) {
            // handle exception
            Log.e("Exception",e.toString());
        }

        return bitmap;
    }

    private void sendErrorMessage(final String trackName) {
        final Intent i = new Intent(TRACK_ERROR);
        i.putExtra(TrackErrorExtra.TRACK_NAME, trackName);
        sendBroadcast(i);
    }

    public interface TrackErrorExtra {

        String TRACK_NAME = "trackname";
    }

    private void buildNotification(PlaybackStatus playbackStatus) {

        /**
         * Notification actions -> playbackAction()
         *  0 -> Play
         *  1 -> Pause
         *  2 -> Next track
         *  3 -> Previous track
         */
        if (activeAudio != null && activeAudio.getItem_image() != null) {
            URL url = null;
            try {
                {
                    if (activeAudio.getItem_image().startsWith("https")) {
                        url = new URL(activeAudio.getItem_image());
                        Log.e("build notification", activeAudio.getItem_image());
                        /*Picasso.with(this)
                                .load(String.valueOf(url))
                                .into(new Target() {
                                    @Override
                                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                        largeIcon=bitmap;
                                    }

                                    @Override
                                    public void onBitmapFailed(Drawable errorDrawable) {
                                        largeIcon = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                                R.drawable.no_image);
                                    }

                                    @Override
                                    public void onPrepareLoad(Drawable placeHolderDrawable) {
                                        largeIcon = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                                R.drawable.no_image);
                                    }
                                });*/


                        Glide.with(this)
                                .asBitmap()
                                .load(String.valueOf(url))
                                .into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                        largeIcon=resource;
                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {
                                        largeIcon = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                                R.drawable.no_image);
                                    }
                                });
                    }else if (userMode == 3) {
                        try {
                            Log.e("build notification", activeAudio.getItem_image());
                            Uri sArtworkUri = Uri
                                    .parse("content://media/external/audio/albumart");
                            Uri albumArtUri = ContentUris.withAppendedId(sArtworkUri, Long.parseLong(activeAudio.getCategory_id()));
                            largeIcon = MediaStore.Images.Media.getBitmap(
                                    getApplicationContext().getContentResolver(),albumArtUri);

                        } catch (FileNotFoundException exception) {
                            exception.printStackTrace();
                            Log.e("Exception",exception.toString());
                            largeIcon = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                    R.drawable.no_image);
                        } catch (IOException e) {
                            e.printStackTrace();
                            Log.e("Exception",e.toString());
                        }
                    }else if(userMode==4){
                        largeIcon=  getBitmapFromAsset(getApplicationContext(),activeAudio.getItem_image());

                    } else { //from downloads  or offline
                        Log.e("build notification", activeAudio.getItem_image());
                       // largeIcon = BitmapFactory.decodeFile(activeAudio.getItem_image());
                        largeIcon = ShrinkBitmap(activeAudio.getItem_image(),125,125);
                    }
                    if (largeIcon == null) {
                        largeIcon = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                                R.drawable.no_image);
                    }
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        } else {
            largeIcon = BitmapFactory.decodeResource(getResources(),
                    R.drawable.no_image); //replace with your own image

        }

        int notificationAction = android.R.drawable.ic_media_pause;//needs to be initialized
        PendingIntent play_pauseAction = null;

        //Build a new notification according to the current state of the MediaPlayer
        if (playbackStatus == PlaybackStatus.PLAYING) {
            notificationAction = android.R.drawable.ic_media_pause;
            //create the pause action
            play_pauseAction = playbackAction(1);
        } else if (playbackStatus == PlaybackStatus.PAUSED) {
            notificationAction = android.R.drawable.ic_media_play;
            //create the play action
            play_pauseAction = playbackAction(0);
        }

        // Create a new Notification

        Intent nowPlayingIntent = getNowPlayingIntent(this);
        PendingIntent clickIntent = PendingIntent.getActivity(this, 0, nowPlayingIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        final Intent shutdownIntent = new Intent(this, MediaPlayerService.class);
        shutdownIntent.setAction(SHUTDOWN);
        mShutdownIntent = PendingIntent.getService(this, 0, shutdownIntent, 0);

        androidx.core.app.NotificationCompat.Builder notificationBuilder =
                new androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID);
        notificationBuilder
                .setStyle(
                        new NotificationCompat.MediaStyle()
                                .setMediaSession(mediaSession.getSessionToken())
                                .setShowCancelButton(true)
                                .setShowActionsInCompactView(0, 1, 2, 3))
                .setColor(ContextCompat.getColor(this, R.color.ActionBar))
                .setSmallIcon(R.drawable.logo_swar)
                .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                /* .setOnlyAlertOnce(true)*/
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(clickIntent)
                .setSubText("")
                .setLargeIcon(largeIcon)
                .setContentText(activeAudio.getItem_description())
                .setContentTitle(activeAudio.getItem_name())
                /*.setContentInfo(activeAudio.getItem_description())*/
                .setDeleteIntent(mShutdownIntent)
                .addAction(android.R.drawable.ic_media_previous, "previous", playbackAction(3))
                .addAction(notificationAction, "pause", play_pauseAction)
                .addAction(android.R.drawable.ic_media_next, "next", playbackAction(2))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "cancel", playbackAction(44));

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            notificationBuilder.setSmallIcon(R.drawable.ic_notification_transperent);
            notificationBuilder.setColor(getResources().getColor(R.color.ActionBar));
        } else {
            notificationBuilder.setSmallIcon(R.drawable.logo_swar);
        }
        startForeground(NOTIFICATION_ID, notificationBuilder.build());
        // ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID, notificationBuilder.build());
    }


    public void cancelNotification() {
        stopForeground(true);
        mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancel(NOTIFICATION_ID); // Notification ID to cancel
    }

    public static Intent getNowPlayingIntent(Context context) {

        final Intent intent = new Intent(context, MainActivity.class);
        intent.setAction(ACTION_PLAY);
        return intent;
    }

    private PendingIntent playbackAction(int actionNumber) {
        Intent playbackAction = new Intent(this, MediaPlayerService.class);
        switch (actionNumber) {
            case 0:
                // Play
                playbackAction.setAction(ACTION_PLAY);
                return PendingIntent.getService(this, actionNumber, playbackAction, 0);
            case 1:
                // Pause
                playbackAction.setAction(ACTION_PAUSE);
                return PendingIntent.getService(this, actionNumber, playbackAction, 0);
            case 2:
                // Next track
                playbackAction.setAction(ACTION_NEXT);
                return PendingIntent.getService(this, actionNumber, playbackAction, 0);
            case 3:
                // Previous track
                playbackAction.setAction(ACTION_PREVIOUS);
                return PendingIntent.getService(this, actionNumber, playbackAction, 0);
            case 44:
                // Previous track
                playbackAction.setAction(SHUTDOWN);
                return PendingIntent.getService(this, actionNumber, playbackAction, 0);
            default:
                break;
        }
        return null;
    }

    private void removeNotification() {
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(NOTIFICATION_ID);
    }

    private void handleIncomingActions(Intent playbackAction) {
        if (playbackAction == null || playbackAction.getAction() == null) return;
        if (transportControls == null) return;
        String actionString = playbackAction.getAction();
        if (actionString.equalsIgnoreCase(ACTION_PLAY)) {
            transportControls.play();
        } else if (actionString.equalsIgnoreCase(ACTION_PAUSE)) {
            transportControls.pause();
        } else if (actionString.equalsIgnoreCase(ACTION_NEXT)) {
            transportControls.skipToNext();
        } else if (actionString.equalsIgnoreCase(ACTION_PREVIOUS)) {
            transportControls.skipToPrevious();
        } else if (actionString.equalsIgnoreCase(ACTION_STOP)) {
            transportControls.stop();
        } else if (actionString.equalsIgnoreCase(SHUTDOWN)) {
            mShutdownScheduled = false;
            releaseServiceUiAndStop();
        }
    }

    /**
     * Play new Audio
     */
    private final BroadcastReceiver playNewAudio = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            //Get the new media index form SharedPreferences
            StorageUtil storage = new StorageUtil(getApplicationContext());
            audioList = storage.loadAudio();
            audioIndex = storage.loadAudioIndex();
            userMode = storage.loadMode();

            if (audioIndex != -1 && audioIndex < audioList.size()) {
                //index is in a valid range
                activeAudio = audioList.get(audioIndex);
            } else {
                stopSelf();
            }

            //A PLAY_NEW_AUDIO action received
            //reset mediaPlayer to play the new Audio
            //Request audio focus
            if (!requestAudioFocus()) {
                //Could not gain focus
                stopSelf();
            }

            stopMedia();
            // mediaPlayer.reset();
            if (mediaSessionManager == null) {

                try {
                    initMediaSession();
                } catch (RemoteException e) {
                    e.printStackTrace();
                }

            }
            initMediaPlayer();
        }
    };

    private void register_playNewAudio() {
        //Register playNewMedia receiver
        IntentFilter filter = new IntentFilter(MainActivity.Broadcast_PLAY_NEW_AUDIO);
        registerReceiver(playNewAudio, filter);
    }

    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            CharSequence name = "swarsageetmala";
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel mChannel = null;
            mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            manager.createNotificationChannel(mChannel);
        }
    }


    public ArrayList<SubCategoryModel> getAudioList() {
        return audioList;
    }

    public void setAudioList(ArrayList<SubCategoryModel> audioList) {
        if (audioList != null) {
            Log.e("songs", audioList.toString());
            this.audioList.clear();
        }
        this.audioList = audioList;
    }

    public int getAudioIndex() {
        return audioIndex;
    }

    public void setAudioIndex(int audioIndex) {
        this.audioIndex = audioIndex;
    }

    public void setShuffleMode(Boolean bool) {
        isShuffle = bool;
    }

    public boolean isShuffle() {
        return isShuffle;
    }

    public boolean isRepeat() {
        return isRepeat;
    }

    public void setRepeat(boolean repeat) {
        isRepeat = repeat;
    }

    public SubCategoryModel getActiveAudio() {
        return activeAudio;
    }

    public void setActiveAudio(SubCategoryModel activeAudio) {
        this.activeAudio = activeAudio;
    }

    public boolean isSongCompleted() {
        return isSongCompleted;
    }

    public int getNoOfRepeats() {
        return repeatCount;
    }

    public void setNoOfRepeats(int noOfRepeats) {
        repeatCount = noOfRepeats;
        this.noOfRepeats = noOfRepeats;
    }

    public boolean isFromUSB() {
        return isFromUSB;
    }

    public void setFromUSB(boolean fromUSB) {
        isFromUSB = fromUSB;
    }

    private void storeToRecentlyPlayed(SubCategoryModel activeAudio) {
        Log.e("storeToRecentlyPlayed", new Gson().toJson(activeAudio));
        RealmHelper realmHelper = new RealmHelper();
        realmHelper.saveRecentlyPlayed(activeAudio);
    }

    public int getAudioSessionId() {
        return audioSessionId;
    }


    private Bitmap ShrinkBitmap(String file, int width, int height){

        BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
        bmpFactoryOptions.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeFile(file, bmpFactoryOptions);

        int heightRatio = (int)Math.ceil(bmpFactoryOptions.outHeight/(float)height);
        int widthRatio = (int)Math.ceil(bmpFactoryOptions.outWidth/(float)width);

        if (heightRatio > 1 || widthRatio > 1)
        {
            if (heightRatio > widthRatio)
            {
                bmpFactoryOptions.inSampleSize = heightRatio;
            } else {
                bmpFactoryOptions.inSampleSize = widthRatio;
            }
        }

        bmpFactoryOptions.inJustDecodeBounds = false;
        bitmap = BitmapFactory.decodeFile(file, bmpFactoryOptions);
        return bitmap;
    }
}

