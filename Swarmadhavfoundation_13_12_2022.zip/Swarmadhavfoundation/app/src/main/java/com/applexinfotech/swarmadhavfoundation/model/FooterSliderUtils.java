package com.applexinfotech.swarmadhavfoundation.model;

public class FooterSliderUtils {
    String footersliderImageUrl;

    public String getFootersliderImageUrl(){
        return footersliderImageUrl;
    }
    public void setFootersliderImageUrl(String footersliderImageUrl){
        this.footersliderImageUrl = footersliderImageUrl;
    }
}
