package com.applexinfotech.swarmadhavfoundation.fragment;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.CategoryFragmentAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment.hideKeyboard;


public class CategoryFragment extends MasterFragment implements DownloadListener, OnItemClickListener<SubCategoryModel> {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private static int ITEMS_PER_AD = 6;
    private static final int LIST_NO_AD_DELTA = 0; //when no internet
    private MainActivity mContext;
    private ArrayList<SubCategoryModel> CatListItem = new ArrayList<>();
    private ArrayList<Object> categoryListWIthAd = new ArrayList<>();
    private HomeModel homeModel = new HomeModel();
    private RecyclerView mCategoryList;
    private String category_id;
    private Bundle bundle;
    private CategoryFragmentAdapter Adapter;
    private InterstitialAd interstitial;
    private int overflowcounter = 0;
    private LinearLayout noSongFoundView;

    public ArrayList<SubCategoryModel> mItem = new ArrayList<>();
    public String lastSearchedString = "";
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    private LinearLayout Linerlayourserach;

    private ArrayList<Integer> addPositionList = new ArrayList<>();
    // The AdLoader used to load ads.
    private AdLoader adLoader;
    // List of native ads that have been successfully loaded.
    private List<UnifiedNativeAd> mNativeAds = new ArrayList<>();
    private EditText search;


    public CategoryFragment() {
        // Required empty public constructor
    }

    public static CategoryFragment newInstance(String param1, String param2) {
        CategoryFragment fragment = new CategoryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_category, container, false);
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext.showWaitIndicator(false);
       // mContext.hideDrawer();
        mContext.showDrawerBack();

        mContext.setTitle(getString(R.string.set_title));
        mCategoryList = view.findViewById(R.id.listView_cat_list);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        Linerlayourserach= view.findViewById(R.id.Linerlayourserach);
        Linerlayourserach.setVisibility(View.VISIBLE);
        search=(EditText) view.findViewById(R.id.search);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    Log.e("server request data", "setRefreshing=");
                    getCategory();

                } else {
                    getDataFromRealm();
                }

                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        bundle = getArguments();

        if (bundle != null) {
            homeModel = (HomeModel) bundle.getSerializable("CAT_ID");
            category_id = homeModel.getCategory_id();
        }

        isInternet = InternetStatus.isInternetOn(mContext);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        hideKeyboard(mContext);
                        getCategory();
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        hideKeyboard(mContext);
                        getCategory();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.length()>0){
                        mCategoryList.setAdapter(null);
                        getAudioSearch(s.toString());
                    }else if(s.length() == 0){
                        hideKeyboard(mContext);
                        mCategoryList.setAdapter(null);
                        getCategory();
                    }
                }
            }

        });


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        /*if (mContext.getVerifyP() == 0)
        {
            ToastUtil.showLongToastMessage(mContext, getString(R.string.verifyPurchase));

        }
        else
        {

        }*/

        loadCategoryData();
    }


    private void getDataFromRealm() {
        categoryListWIthAd = new ArrayList<>();
        RealmHelper realmHelper = new RealmHelper();
        ArrayList<SongModel> songList = realmHelper.retrieveSongListByCategory(category_id);
        if (songList != null) {
            Collections.sort(songList, new Comparator<SongModel>() {
                public int compare(SongModel v1, SongModel v2) {
                    return v1.getItem_name().toLowerCase().compareTo(v2.getItem_name().toLowerCase());
                }
            });
            if (songList.size() > 0) {
                for (int i = 0; i < songList.size(); i++) {
                    SubCategoryModel subCategoryModel = new SubCategoryModel();
                    subCategoryModel.setItem_id(songList.get(i).getItem_id());
                    subCategoryModel.setItem_name(songList.get(i).getItem_name());
                    subCategoryModel.setItem_image(songList.get(i).getItem_image());
                    subCategoryModel.setItem_file(songList.get(i).getItem_file());
                    subCategoryModel.setItem_description(songList.get(i).getItem_description());
                    subCategoryModel.setDownload_name(songList.get(i).getDownload_name());
                    subCategoryModel.setCategory_id(songList.get(i).getCategory_id());
                    subCategoryModel.setCategory_name(songList.get(i).getCategory_name());
                    subCategoryModel.setCategory_image(songList.get(i).getCategory_image());
                    subCategoryModel.setLyrics_file(songList.get(i).getLyrics_file());
                    subCategoryModel.setLyrics_filePdf(songList.get(i).getLyrics_filePdf());
                    subCategoryModel.setTypeHm(songList.get(i).getTypeHm());
                    subCategoryModel.setUpdate_count(songList.get(i).getUpdate_count());
                    categoryListWIthAd.add(subCategoryModel);
                }

                setAdapterData(LIST_NO_AD_DELTA);
            }
        }
    }

    private void getCategory() {
        mContext.showWaitIndicator(true);

        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.category, category_id));
        dishRequest.sendRequest(Constants.API_Audio_category_songs_list,
                carData, catCallback);
    }


    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        CatListItem = new ArrayList<>();
                        categoryListWIthAd = new ArrayList<>();
                        JSONObject data = jObject.getJSONObject("data");
                        JSONArray audio_list= data.getJSONArray("audio_list");
                        Log.d("data.length()", "" + audio_list.length());

                        for (int i = 0; i < audio_list.length(); i++) {
                            SubCategoryModel categoryModel = new SubCategoryModel();
                            categoryModel.setItem_id(audio_list.getJSONObject(i).getString("audio_id")+"audio_id");
                            categoryModel.setItem_name(audio_list.getJSONObject(i).getString("audio_title"));
                            categoryModel.setItem_description(audio_list.getJSONObject(i).getString("audio_description"));
                            categoryModel.setItem_file(audio_list.getJSONObject(i).getString("audio_file"));
                            categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                            categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("audio_title"));
                            categoryModel.setLyrics_file(audio_list.getJSONObject(i).getString("audio_lyrics"));
                            categoryModel.setLyrics_filePdf(audio_list.getJSONObject(i).getString("pdf_file"));
                            categoryModel.setUpdate_count(audio_list.getJSONObject(i).getString("update_count"));
                            categoryModel.setVideo_url("null");
                            CatListItem.add(categoryModel);
                            categoryListWIthAd.add(categoryModel);
                        }

                        showListView(true);
                        MasterActivity.songWithAd = new ArrayList<>();
                        MasterActivity.songWithAd.addAll(categoryListWIthAd);
                        setAdapterData(0);

                    } else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };



    private void getAudioSearch(String catergor) {
        mContext.showWaitIndicator(false);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.title, catergor));
        carData.add(new BasicNameValuePair(Constants.CATEGORY_ID, category_id));
        carData.add(new BasicNameValuePair(Constants.subcategory_id, ""));
        dishRequest.sendRequest(Constants.API_Audio_search,
                carData, catCallbackSearch);
    }

    private final NetworkRequest.NetworkRequestCallback catCallbackSearch = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.optString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        CatListItem = new ArrayList<>();
                        categoryListWIthAd = new ArrayList<>();
                        JSONArray audio_list= jObject.getJSONArray("data");
                        Log.d("data.length()", "" + audio_list.length());

                        for (int i = 0; i < audio_list.length(); i++) {
                            SubCategoryModel categoryModel = new SubCategoryModel();
                            categoryModel.setItem_id(audio_list.getJSONObject(i).getString("audio_id")+"audio_id");
                            categoryModel.setItem_name(audio_list.getJSONObject(i).getString("audio_title"));
                            categoryModel.setItem_description(audio_list.getJSONObject(i).getString("audio_description"));
                            categoryModel.setItem_file(audio_list.getJSONObject(i).getString("audio_file"));
                            categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                            categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("audio_title"));
                            categoryModel.setLyrics_file(audio_list.getJSONObject(i).getString("audio_lyrics"));
                            categoryModel.setLyrics_filePdf(audio_list.getJSONObject(i).getString("pdf_file"));
                            categoryModel.setUpdate_count(audio_list.getJSONObject(i).getString("update_count"));
                            categoryModel.setVideo_url("null");
                            CatListItem.add(categoryModel);
                            categoryListWIthAd.add(categoryModel);
                        }

                        showListView(true);
                        MasterActivity.songWithAd = new ArrayList<>();
                        MasterActivity.songWithAd.addAll(categoryListWIthAd);
                        setAdapterData(0);


                    } else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };


    private void loadCategoryData() {
        if (InternetStatus.isInternetOn(getMasterActivity())) {
                if (!MasterActivity.songWithAd.isEmpty()) {
                    Log.e("existing data", "=");
                    categoryListWIthAd = new ArrayList<>();
                    categoryListWIthAd.addAll(MasterActivity.songWithAd);
                    Log.e(" existing ARRAY =", String.valueOf(categoryListWIthAd.size()));
                    setAdapterData(ITEMS_PER_AD);
                }else {
                    Log.e("server request data", "=");
                    getCategory();
                }
            }
         else {
            getDataFromRealm();
        }
    }

    /**
     * Sets up and loads the Native Ads .
     */

    private void insertAdsInMenuItems() {
        if (mNativeAds.size() <= 0) {
            return;
        }
        int index = 0;
        int adListSize=addPositionList.size();
        for (UnifiedNativeAd ad : mNativeAds) {
            if (addPositionList != null && index < adListSize) {
                categoryListWIthAd.add(addPositionList.get(index), ad);
                index = index + 1;
            }

        }
        MasterActivity.songWithAd = new ArrayList<>();
        MasterActivity.songWithAd.addAll(categoryListWIthAd);
    }

    private void showListView(boolean flag) {
        if (flag) {
            mCategoryList.setVisibility(View.VISIBLE);
            noSongFoundView.setVisibility(View.GONE);

        } else {
            mCategoryList.setVisibility(View.GONE);
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }


    @Override
    public void onStop() {
        super.onStop();
        Utilities.hideKeyboard(getMasterActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Utilities.hideKeyboard(getMasterActivity());
    }

    // Do Search...
    private void setAdapterData(int listNoAdDelta) {
        mContext.showWaitIndicator(false);
        // Notify the List that the DataSet has changed...
        if (categoryListWIthAd.isEmpty()) {
            showListView(false);
        } else {
            showListView(true);
            Log.e(" ARRAY =", String.valueOf(categoryListWIthAd.size()));
            Adapter = new CategoryFragmentAdapter(mContext, categoryListWIthAd, homeModel, CategoryFragment.this.getClass().getCanonicalName(), listNoAdDelta);
            mCategoryList.setAdapter(Adapter);
            mCategoryList.setLayoutManager(linearLayoutManager);
            Adapter.setOnItemClickListener(CategoryFragment.this);
            Adapter.notifyDataSetChanged();
        }
    }

    //Downloading Service calls and receiver methods
    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                downloadQueue(selectedObject, position);
               // mContext.loadRewardedVideoAd();
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    private void downloadQueue(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.startDownloading(subCategoryModel, position);
            }
        }
    }


    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (CategoryFragment.this.isVisible()) {
            if (tmpInfo == null || position == -1) {
                return;
            }
            final int status = tmpInfo.getStatus();
            switch (status) {
                case SubCategoryModel.STATUS_COMPLETE:
                    if (Adapter != null) {
                        Log.e("CategoryFragment", "notified");
                        Adapter.notifyDataSetChanged();
                    }
                    break;
            }
        }
        //Downloading Service calls and receiver methods ends
    }

    private void addBannerAds() {
        // Loop through the items array and place a new banner ad in every ith position in
        // the items List.
        // Loop through the items array and place a new banner ad in every ith position in
        // the items List.
        addPositionList = new ArrayList<>();
        int listSize= categoryListWIthAd.size();
        if (ITEMS_PER_AD <listSize) {
            for (int i = 0; i <= listSize; i += ITEMS_PER_AD) {
                if (i != 0) {
                    addPositionList.add(i);
                }
            }
        }
       Log.e("addPositionList.size=",String.valueOf(addPositionList.size()));
    }


    @Override
    public void onPause() {
        super.onPause();
    }



}
