package com.applexinfotech.swarmadhavfoundation.common.util;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SessionManager {
    // UsersList name (make variable public to access from outside)
    public static final String KEY_user_id ="user_id";
    public static final String KEY_name = "name";
    public static final String KEY_mobile = "mobile";
    public static final String KEY_email= "email";
    public static final String KEY_address ="address";
    public static final String KEY_dob ="dob";
    public static final String KEY_image ="image";


    // Sharedpref file name
    private static final String PREF_NAME = "SawrSangeetMala";
    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";
    // Shared Preferences
    SharedPreferences pref;
    // Editor for Shared preferences
    Editor editor;
    // Context
    Context _context;
    // Shared pref mode
    int PRIVATE_MODE = 0;
    // Constructor


    public SessionManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }
    /**
     * Create login session
     */
    public void createLoginSession(String user_id,String name, String mobile,String address,String dob,String image,String email) {
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true);
        // Storing name in pref
        editor.putString(KEY_user_id, user_id);
        editor.putString(KEY_name, name);
        editor.putString(KEY_mobile, mobile);
        editor.putString(KEY_email, email);
        editor.putString(KEY_address, address);
        editor.putString(KEY_dob, dob);
        editor.putString(KEY_image, image);
        editor.commit();
    }
    public void UpdateKEY_name(String Pass) {
        editor.putString(KEY_name, Pass);
        editor.commit();
    }

    public boolean checkLogin() {
        // Check login status
        if (!this.isLoggedIn()) {

            return false;
        }
        return true;
    }
    /**
     * Quick check for login
     **/
    // Get Login State
    public boolean isLoggedIn() {
        return pref.getBoolean(IS_LOGIN, false);
    }
    private void startActivity(Intent startMain) {
        // TODO Auto-generated method stub
    }
    /**
     * Get stored session data
     */
    public String getKEY_Userid(){

        String id = pref.getString(KEY_user_id, "");
        return id;
    }
    public String getKEY_name(){

        String id = pref.getString(KEY_name, "");
        return id;
    }
    public String getKEY_mobile(){

        String shop_id = pref.getString(KEY_mobile, "");
        return shop_id;
    }
    public String getKEY_email() {
        String group_id = pref.getString(KEY_email, "");
        return group_id;
    }
    public String getKEY_address() {
        // user name
        String usetname = pref.getString(KEY_address, "");
        // String pass = pref.getString(KEY_PASSWORD, null);
        // return user
        return usetname;
    }

    public String getKEY_dob() {
        // user name
        String password = pref.getString(KEY_dob, "");
        // String pass = pref.getString(KEY_PASSWORD, null);
        // return user
        return password;
    }
    public String getKEY_image() {
        // user name
        String email = pref.getString(KEY_image, "");
        // String pass = pref.getString(KEY_PASSWORD, null);
        // return user
        return email;
    }


    /**
     * Clear session details
     */
    public void logoutUser() {
        // Clearing all data from Shared Preferences
        editor.clear();
        editor.commit();
    }
}
