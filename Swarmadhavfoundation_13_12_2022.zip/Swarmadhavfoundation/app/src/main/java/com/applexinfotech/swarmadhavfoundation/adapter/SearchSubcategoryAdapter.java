package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.fragment.SubCategoryAudioSongFragment;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SearchSubcategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final LayoutInflater layoutInflater;
    private final ArrayList<Object> recyclerViewItems;
    private final MainActivity mContext;
    private static final int MENU_ITEM_VIEW_TYPE = 0;
    private final RecyclerView mRecyclerView;
    private final int resource;
    private final View.OnClickListener mOnClickListener = new SearchSubcategoryAdapter.MyOnClickListener();

    public SearchSubcategoryAdapter(MainActivity context, int resource, ArrayList<Object> list, RecyclerView recyclerView) {
        mContext = context;
        this.recyclerViewItems = list;
        Log.e("noOfItem", String.valueOf(recyclerViewItems.size()));
        this.resource = resource;
        mRecyclerView = recyclerView;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getItemViewType(int position) {
        int viewType = MENU_ITEM_VIEW_TYPE;
       /* if (LIST_AD_DELTA != 0) {   // LIST_AD_DELTA will be 0  when showListBannerAd=false in constants OR noInternet
            Object recyclerViewItem = recyclerViewItems.get(position);
            if (recyclerViewItem instanceof UnifiedNativeAd) {
                viewType = UNIFIED_NATIVE_AD_VIEW_TYPE;
            }
        }*/
        return viewType;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                View menuItemLayoutView = LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.search_adapter_layout, parent, false);
                menuItemLayoutView.setOnClickListener(mOnClickListener);
                return new SearchSubcategoryAdapter.MenuItemViewHolder(menuItemLayoutView);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                SearchSubcategoryAdapter.MenuItemViewHolder menuItemHolder = (SearchSubcategoryAdapter.MenuItemViewHolder) holder;
                SubHomeCategory content = (SubHomeCategory) recyclerViewItems.get(position);
                String TypeHMSt = content.getTypeHm();
                if (TypeHMSt.equals("Audio")) {
                    menuItemHolder.folderFrameLayout.setVisibility(View.VISIBLE);
                    menuItemHolder.folderLinearLayout.setVisibility(View.VISIBLE);

                    menuItemHolder.text_cat_name.setTypeface(mContext.getTypeFace());
                    menuItemHolder.text_cat_name.setText(content.getAudio_subcategory_name());

                    if (InternetStatus.isInternetOn(mContext)) {
                        Picasso.with(mContext).load(content.getAudio_subcategory_image()).into(menuItemHolder.imageView_cat);
                    } else {
                        if (content.getAudio_subcategory_image() != null) {
                            Bitmap bitmap = BitmapFactory.decodeFile(content.getAudio_subcategory_image());
                            if (bitmap != null) {
                                menuItemHolder.imageView_cat.setImageBitmap(bitmap);
                            } else {
                                Picasso.with(mContext).load(content.getAudio_subcategory_image()).placeholder(R.drawable.no_image).fit().into(menuItemHolder.imageView_cat);
                            }
                        }
                    }
                    break;

                } else {
                    menuItemHolder.folderLinearLayout.setVisibility(View.GONE);
                    menuItemHolder.folderFrameLayout.setVisibility(View.GONE);
                }
        }
    }

    @Override
    public int getItemCount() {
        return recyclerViewItems.size();
    }


    class MenuItemViewHolder extends RecyclerView.ViewHolder {
        private final ImageView imageView_cat;
        private final TextView text_cat_name;
        private LinearLayout folderLinearLayout;
        private FrameLayout folderFrameLayout;

        MenuItemViewHolder(View itemView) {
            super(itemView);
            imageView_cat = itemView.findViewById(R.id.imageView_cat);
            text_cat_name = itemView.findViewById(R.id.text_cat_name);
            folderLinearLayout = itemView.findViewById(R.id.folderLinearLayout);
            folderFrameLayout = itemView.findViewById(R.id.folderFrameLayout);

        }
    }


    private class MyOnClickListener implements View.OnClickListener {
        private SubHomeCategory homeModel;

        @Override
        public void onClick(View v) {
            int itemPosition = mRecyclerView.getChildLayoutPosition(v);
            if (recyclerViewItems.get(itemPosition) instanceof SubHomeCategory) {
                homeModel = (SubHomeCategory) recyclerViewItems.get(itemPosition);
                mContext.bundle = new Bundle();
                if (InternetStatus.isInternetOn(mContext)) {
                    Fragment investProgramDetail = new SubCategoryAudioSongFragment();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("SubCAT_ID", homeModel);
                    investProgramDetail.setArguments(bundle);
                    mContext.ReplaceFragment(investProgramDetail);
                }
            }

        }
    }
}
