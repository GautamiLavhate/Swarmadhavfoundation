package com.applexinfotech.swarmadhavfoundation.neavigation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class ExpandableListDataPump {

    public static HashMap<String, List<String>> getData() {
        LinkedHashMap<String, List<String>> expandableListDetail = new LinkedHashMap<String, List<String>>();

        List<String> list4 = new ArrayList<String>();
        List<String> list5 = new ArrayList<String>();
        List<String> list6 = new ArrayList<String>();
        List<String> list7 = new ArrayList<String>();
        List<String> list1 = new ArrayList<String>();




        List<String> list2 = new ArrayList<String>();
        list2.add("All Categories");
        list2.add("Playlist");
        list2.add("Downloads");

        List<String> list3 = new ArrayList<String>();
        list3.add("All Categories");
        list3.add("Playlist");
        list3.add("Downloads");

        expandableListDetail.put("HOME", list1);
        expandableListDetail.put("Audio", list2);
        expandableListDetail.put("Video", list3);
        expandableListDetail.put("NOTIFICATION", list4);
        expandableListDetail.put("Profile", list5);
        expandableListDetail.put("ABOUT", list6);
        expandableListDetail.put("Logout", list7);


        return expandableListDetail;
    }
}
