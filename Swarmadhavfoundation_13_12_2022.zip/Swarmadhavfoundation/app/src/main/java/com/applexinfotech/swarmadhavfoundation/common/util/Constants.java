package com.applexinfotech.swarmadhavfoundation.common.util;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2018.
 */
public class Constants {

    // string constants
    public static final String item_id = "item_id";
    public static final String item_name = "item_name";
    public static final String item_description = "item_description";
    public static final String item_file = "item_file";
    public static final String item_image = "item_image";
    public static final String download_name = "download_name";
    public static final String duration = "duration";
    public static final String lyrics_file ="lyrics_file";


    public static final String video_url = "video_url";

    public static final String GCM_ID = "gcm_id";
    public static final String DEVICE_ID = "device_id";
    public static final String Key_user_fcm_id = "Key_user_fcm_id";
    public static final String IS_FROM = "IS_FROM";
    public static final String FROM_MOST_PLAYED = "FROM_MOST_PLAYED";
    public static final String FROM_MOST_DOWNLOADED = "FROM_MOST_DOWNLOADED";
    public static final String FROM_RECENTLY_PLAYED = "FROM_RECENTLY_PLAYED";
    public static final String FROM_PLAYLIST = "FROM_PLAYLIST";
    public static final String PLAYLIST_ID="PLAYLIST_ID";
    public static final String FROM_ASSETS = "FROM_ASSETS";


    public static final String DOWNLOADS = "DOWNLOADS";
    public static final String CATEGORY = "CATEGORY";
    public static final String CATEGORY_MINI_PLAYER = "CATEGORY_MINI_PLAYER";
    public static final String HOME = "HOME";
    public static final String LOCAL_SONGS = "LOCAL_SONGS";

    // Message Key
    public static final String MSG_KEY = "message";
    /**
     * subclass 6 means that the usb mass storage device implements the SCSI
     * transparent command set
     */
    public static final int INTERFACE_SUBCLASS = 6;

    /**
     * protocol 80 means the communication happens only via bulk transfers
     */
    public static final int INTERFACE_PROTOCOL = 80;

    public final static String SORT_FILTER_PREF = "SORT_FILTER_PREF";
    public final static String SORT_ASC_KEY = "SORT_ASC_KEY";
    public final static String SORT_FILTER_KEY = "SORT_FILTER_KEY";

    public final static int SORTBY_NAME = 0;
    public final static int SORTBY_DATE = 1;
    public final static int SORTBY_SIZE = 2;

    public final static int CACHE_THRESHOLD = 20 * 1024 * 1024; // 20 MB
    //Ad flags
    public static final boolean showBottomBannerAd = true;        //google bottom banner ad
    public static final boolean showListBannerAd = false;         //google ad between categories
    public static final boolean showSongListBannerAd = false;    //google ad between songs
    public static final boolean showBigAd = true;              //google big ad
    public static final boolean showVideoAd = true;           //google reward video ad on download
    public static final boolean enableAssetSongs = false;     //to provide songs from assets


    public static final String IMAGE_FOLDER_PATH = "/Bhakti sagar/images/";
    public static final String SONG_FOLDER_PATH = "/Bhakti sagar/mp3/";
    public static final String CATEGORY_IMG_FOLDER_PATH = "/Bhakti sagar/category_images/";
    public static String DIRECTORY_PATH = "/data/data/";
    public static final String LYRICS_FOLDER_PATH = "/Bhakti sagar/lyrics/";

    public static final String PDF_FOLDER_PATH = "/Bhakti sagar/Pdf/";

    public static final String ASSET_FOLDER_PATH = "file:///android_asset/";
    public static final String ASSET_IMAGE_FOLDER_PATH = ASSET_FOLDER_PATH + "thumbnail/";
    public static final String ASSET_SONG_FOLDER_PATH = ASSET_FOLDER_PATH + "mp3/";
    public static final String ASSET_LYRICS_FOLDER_PATH = ASSET_FOLDER_PATH + "lyrics/";


    public static final String VIDEO_FOLDER_PATH="/Bhakti sagar/videos/";

    public static final String YOU_TUBE_DEVELOPER_KEY = "AIzaSyBO9J9Z2TzYhqgaexRiF0iEWXXjWQF7FI4";
    public static final int REQ_START_STANDALONE_PLAYER = 1;
    public static final int REQ_RESOLVE_SERVICE_MISSING = 2;


    //new Api

    //private final static String API_DOMAIN_CONSUMERSawrSagget = "https://applexgroup.com/swarmadhav/";
    private final static String API_DOMAIN_CONSUMERSawrSagget = "https://swarmadhavfoundation.org/admin/";


    //Api Name
    private final static String API_Post_Login_user = "Login_user";
    private final static String API_Post_Change_password= "Change_password";
    private final static String API_AboutUs="app_info";
    private final static String update_user="update_user";
    public static final String user_details = "user_details";
    public static final String set_password = "set_password";
    public static final String audio_category_list ="audio_category_list";
    public static final String videio_category_list ="video_category_list";
    public static final String Audio_category_songs ="Audio_category_songs";
    public static final String Video_category_songs ="Video_category_songs";
    public static final String audio_subcategory_list ="audio_subcategory_list";
    public static final String Subcategories_audio_list ="Subcategories_audio_list";
    public static final String video_subcategory_list ="video_subcategory_list";
    public static final String Subcategories_video_list ="Subcategories_video_list";
    public static final String SEARCH_SONGVideo_STATUS ="Dashboard_search";
    public static final String get_notification_STATUS ="get_notification";
    public static final String Audio_category_search="Audio_category_search";
    public static final String Video_category_search="Video_category_search";
    public static final String audio_subcat_search="audio_subcat_search";
    public static final String video_subcat_search="video_subcat_search";
    public static final String Logout="Logout";
    public static final String Audio_search="audio_search";
    public static final String Video_search="video_search";
    public static final String Appversion="Appversion";
    public static final String Terms_and_condition="App_termconditions";
    public static final String Privacy_Poilicy="App_privacypolicy";
    public static final String Image_Slider="Sl_list";
    public static final String Footer_Image_Slier="Footer_slider_list";



    //constants
    public static final String mobile_ID = "mobile";
    public static final String password_ID = "password";
    public static final String cpassword_ID = "cpassword";
    public static final String oldpassword_ID = "oldpassword";
    public static final String user_ID = "user_id";
    public static final String category = "category";
    public static final String subcategory_id = "subcategory_id";
    public static final String title = "title";
    public static final String subcategory_name ="subcategory_name";
    public static final String version_no="version_no";



    public static final String CATEGORY_ID = "category_id";
    public static final String CATEGORY_NAME = "category_name";
    public static final String CATEGORY_IMAGE = "category_image";
    public static final String CatisSubcategoryAva = "isSubcategoryAvailable";


    //Whole url
    public final static String API_Post_Login_user_URL = API_DOMAIN_CONSUMERSawrSagget + API_Post_Login_user;
    public final static String API_Post_Change_password_URL = API_DOMAIN_CONSUMERSawrSagget + API_Post_Change_password;
    public final static String API_Get_AboutUs_swar = API_DOMAIN_CONSUMERSawrSagget + API_AboutUs;
    public final static String API_update_user = API_DOMAIN_CONSUMERSawrSagget + update_user;
    public final static String API_user_deatil = API_DOMAIN_CONSUMERSawrSagget + user_details;
    public final static String API_set_password_Sawr = API_DOMAIN_CONSUMERSawrSagget + set_password;
    public final static String API_audio_category_list = API_DOMAIN_CONSUMERSawrSagget + audio_category_list;
    public final static String API_GET_HOME_URLvedio = API_DOMAIN_CONSUMERSawrSagget + videio_category_list;
    public final static String API_Audio_category_songs_list = API_DOMAIN_CONSUMERSawrSagget + Audio_category_songs;
    public final static String API_Video_category_songs_list = API_DOMAIN_CONSUMERSawrSagget + Video_category_songs;
    public final static String API_audio_subcategory_list = API_DOMAIN_CONSUMERSawrSagget + audio_subcategory_list;
    public final static String API_Subcategories_audio_list = API_DOMAIN_CONSUMERSawrSagget + Subcategories_audio_list;
    public final static String API_video_subcategory_list = API_DOMAIN_CONSUMERSawrSagget + video_subcategory_list;
    public final static String API_Subcategories_Vidio_Song_list = API_DOMAIN_CONSUMERSawrSagget + Subcategories_video_list;
    public final static String API_SEARCH_SONG_STATUS_URL = API_DOMAIN_CONSUMERSawrSagget + SEARCH_SONGVideo_STATUS;
    public final static String API_get_notification_URL = API_DOMAIN_CONSUMERSawrSagget + get_notification_STATUS;
    public final static String API_Audio_category_search_list = API_DOMAIN_CONSUMERSawrSagget + Audio_category_search;
    public final static String API_Video_category_search_list = API_DOMAIN_CONSUMERSawrSagget + Video_category_search;
    public final static String API_audio_subcat_search_list = API_DOMAIN_CONSUMERSawrSagget + audio_subcat_search;
    public final static String API_video_subcat_search = API_DOMAIN_CONSUMERSawrSagget + video_subcat_search;
    public final static String API_Logout = API_DOMAIN_CONSUMERSawrSagget + Logout;
    public final static String API_Audio_search = API_DOMAIN_CONSUMERSawrSagget + Audio_search;
    public final static String API_Video_search = API_DOMAIN_CONSUMERSawrSagget + Video_search;
    public final static String API_Version = API_DOMAIN_CONSUMERSawrSagget + Appversion;
    public final static String API_Terms_And_Condition=API_DOMAIN_CONSUMERSawrSagget + Terms_and_condition;
    public final static String API_Privacy_Policy=API_DOMAIN_CONSUMERSawrSagget + Privacy_Poilicy;
    public final static String API_Image_Slider=API_DOMAIN_CONSUMERSawrSagget + Image_Slider;
    public final static String API_Footer_Image_Slider=API_DOMAIN_CONSUMERSawrSagget + Footer_Image_Slier;
    public final static String API_Footer_Image_Slider_demo="https://swarmadhavfoundation.org/admin/Footer_slider_list";


}
