package com.applexinfotech.swarmadhavfoundation.equalizer;

public interface AudioSessionChangedListener {

    void sessionIdChanged(int audioSessionId);
}
