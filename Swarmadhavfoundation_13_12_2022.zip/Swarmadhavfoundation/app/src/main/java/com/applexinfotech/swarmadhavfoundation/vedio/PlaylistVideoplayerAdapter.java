package com.applexinfotech.swarmadhavfoundation.vedio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.LOCAL_SONGS;

public class PlaylistVideoplayerAdapter extends RecyclerView.Adapter<PlaylistVideoplayerAdapter.MyViewHolder> {

    private ArrayList<SubCategoryModel> playList;
    private OnItemClickListener mListener;
    Context mContext;
    private int audioIndex;
    private String isPlayingFrom;


    public PlaylistVideoplayerAdapter(VideoPlayer videoPlayer) {
        mContext = videoPlayer;
    }

    public void setPlayList(ArrayList<SubCategoryModel> playList) {
        this.playList = playList;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.playlist_itemvedio, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final SubCategoryModel video = playList.get(position);
        Log.e("Resyclepos", String.valueOf(position));
        holder.videoTitle.setText(video.getDownload_name());
        holder.videoDescription.setText(video.getItem_description());
        StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
        isPlayingFrom=storage.loadIsPlayingFrom();
        if(isPlayingFrom.equalsIgnoreCase(LOCAL_SONGS)){
            if(playList.get(position).getItem_image()!=null){
                String image=playList.get(position).getItem_image();

                Glide.with(mContext).load(image).placeholder(R.drawable.no_image).into(holder.thumbnailImage);
               /* BitmapFactory.Options bmOptions = new BitmapFactory.Options();
                Bitmap bitmap = BitmapFactory.decodeFile(image,bmOptions);
                holder.thumbnailImage.setImageBitmap(bitmap);*/
            }
        }else{

            Glide.with(mContext).load(video.getItem_image()).placeholder(R.drawable.no_image).into(holder.thumbnailImage);
           /* if (video.getItem_image().startsWith("https")) {
                Picasso.with(mContext).load(video.getItem_image()).placeholder(R.drawable.no_image).into(holder.thumbnailImage);
            } else if (video.getItem_image() != null) {
                holder.thumbnailImage.setImageBitmap(getImgBitmap(video.getItem_image()));
            }*/
        }

        audioIndex = storage.loadAudioIndex();

        if (audioIndex == position) {
            Drawable mDrawable = ContextCompat.getDrawable(mContext,R.drawable.card_selector);
            holder.selectorLayout.setBackground(mDrawable);
        } else {
            Drawable mDrawable = ContextCompat.getDrawable(mContext,R.drawable.card_selector);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.transparent), PorterDuff.Mode.MULTIPLY));
            holder.selectorLayout.setBackground(mDrawable);
        }
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onItemClick(v, position, video);
            }
        });

    }

    private Bitmap getImgBitmap(String item_image) {
        return BitmapFactory.decodeFile(item_image);
    }

    @Override
    public int getItemCount() {
        return playList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView videoTitle, videoDescription;
        public ImageView thumbnailImage, playImage;
        public CardView cardView;
        RelativeLayout selectorLayout;

        public MyViewHolder(View itemView) {
            super(itemView);
            videoTitle = itemView.findViewById(R.id.video_title);
            videoDescription = itemView.findViewById(R.id.video_discription);
            thumbnailImage = itemView.findViewById(R.id.thumbnail);
            playImage = itemView.findViewById(R.id.img_play);
            cardView = itemView.findViewById(R.id.video_card_view);
            selectorLayout = itemView.findViewById(R.id.card_selector);
        }
    }

}
