package com.applexinfotech.swarmadhavfoundation.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.AddPlaylistVedioDialog;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.CircularImageView;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.fragment.AddPlaylistDialog;
import com.applexinfotech.swarmadhavfoundation.fragment.Downloads;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.DOWNLOADS;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 03-01-2016.
 */
public class DownloadAdapter extends ArrayAdapter<String> {
    private final LayoutInflater layoutInflater;

    private final MainActivity mContext;

    private final int resource;
    private PopupMenu menu;
    private ProgressDialog pDialog;
    private ArrayList<SubCategoryModel> songList = new ArrayList<>();
    private String fileName, imageName,lyricsFileName,lyricsPdf;
    private final Downloads classContext;

    public DownloadAdapter(MainActivity context, int resource, ArrayList<SubCategoryModel> downloadedList, Downloads downloads) {
        super(context, resource);
        mContext = context;
        this.resource = resource;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        songList = downloadedList;
        Log.d("Adapter Call", "Size: " + songList.size());
        classContext = downloads;
    }

    public int getCount() {
        return songList.size();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View rootView = convertView;

        rootView = layoutInflater.inflate(R.layout.downloads_list_item, null, true);

        CircularImageView cat_image = rootView.findViewById(R.id.image_download);

        ImageButton play = rootView.findViewById(R.id.play_download);
        final ImageButton delete = rootView.findViewById(R.id.delete_download);
        final ImageButton share = rootView.findViewById(R.id.share_download);
        final ImageButton popupMenu = rootView.findViewById(R.id.popup_menu);


            Drawable mDrawable=ContextCompat.getDrawable(mContext,R.drawable.ic_delete_new);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            delete.setImageDrawable(mDrawable);
            Drawable arrowDrawable=ContextCompat.getDrawable(mContext,R.drawable.ic_play_new);
            arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.iconPrimaryColor),PorterDuff.Mode.MULTIPLY));
            play.setImageDrawable(arrowDrawable);
            Drawable shareDrawable=ContextCompat.getDrawable(mContext,R.drawable.ic_share_new);
            shareDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.iconPrimaryColor),PorterDuff.Mode.MULTIPLY));
            share.setImageDrawable(shareDrawable);
            Drawable popupMenuDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_more_new);
            popupMenuDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            popupMenu.setImageDrawable(popupMenuDrawable);
            


        TextView tv_title = rootView.findViewById(R.id.tv_title_download);
        TextView tv_desc = rootView.findViewById(R.id.tv_desc);
        final LinearLayout layout_main = rootView.findViewById(R.id.layout_main);

        //tv_title.setTypeface(mContext.getTypeFace());
        tv_desc.setTypeface(mContext.getTypeFace());

        tv_title.setText(songList.get(position).getItem_name());
        tv_desc.setText(songList.get(position).getItem_description());

        Log.d("TITLE", "" + songList.get(position).getItem_name());
        Log.d("IMAGE", "" + songList.get(position).getItem_image());

        Glide.with(mContext).load(songList.get(position).getItem_image()).placeholder(R.drawable.no_image).into(cat_image);

        /*Picasso.with(mContext).load(songList.get(position).getItem_image()).placeholder(R.drawable.no_image).fit().into(cat_image);*/
        popupMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                if (menu != null) {
                    menu.dismiss();
                }
                menu = new PopupMenu(mContext, v);
                menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.popup_song_play:
                                layout_main.performClick();
                                break;
                            case R.id.popup_song_addto_playlist:
                                if (songList != null && !songList.isEmpty() && songList.size() > position) {
                                        SubCategoryModel selectedObject = songList.get(position);
                                        String videoSt=selectedObject.getVideo_url();
                                        if(videoSt.equals("null")) {
                                            FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                            AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("SongList", selectedObject,"Audio");
                                            infoDialog.setCancelable(false);
                                            infoDialog.show(fragmentManager, "Dialog");
                                        }else {
                                            FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                            AddPlaylistVedioDialog infoDialog = AddPlaylistVedioDialog.newInstance("SongList", selectedObject,"Vedio");
                                            infoDialog.setCancelable(false);
                                            infoDialog.show(fragmentManager, "Dialog");
                                        }
                                }
                                break;
                            case R.id.popup_song_delete:
                                delete.performClick();
                                break;
                            case R.id.popup_song_set_default_ringtone:
                                if (songList != null && !songList.isEmpty() && songList.size() > position) {
                                    mContext.startRingdroidEditor(songList.get(position));
                                }
                                break;
                        }
                        return false;
                    }
                });
                menu.inflate(R.menu.popup_song);
                menu.show();
                    menu.getMenu().findItem(R.id.popup_song_play).setVisible(true);
                    menu.getMenu().findItem(R.id.popup_song_delete).setVisible(true);
                    menu.getMenu().findItem(R.id.popup_song_set_default_ringtone).setVisible(false);
                    menu.getMenu().findItem(R.id.popup_song_addto_playlist).setVisible(false);
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout_main.performClick();
            }
        });
        layout_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("SONG_PATH", "" + songList.get(position).getItem_file());
                StorageUtil storage = new StorageUtil(getApplicationContext());
                if (storage.loadAudio() != null) {
                    storeGlobalSongInfo(storage, position);
                    if (MasterActivity.serviceBound && mContext.isPlaying()) {
                        Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                        mContext.sendBroadcast(broadcastIntent);
                    } else if (MasterActivity.serviceBound) {
                        mContext.playSong();
                    }

                } else if (MasterActivity.serviceBound) {
                    storeGlobalSongInfo(storage, position);
                    mContext.playSong();
                }


                Fragment streaming = new Streaming();
                MainActivity.AudioType="MainAudio";
                Bundle bundle = new Bundle();
                bundle.putInt("mode", 1);
                bundle.putString("isFrom", DOWNLOADS);
                bundle.putInt("position", position);
                bundle.putSerializable("data", songList);
                streaming.setArguments(bundle);
                mContext.ReplaceFragment(streaming);
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StorageUtil storage = new StorageUtil(getApplicationContext());
                if (storage.loadAudio() != null) {
                    ArrayList<SubCategoryModel> nowPlayingList = storage.loadAudio();
                    if (nowPlayingList.get(0).getItem_file().startsWith("https")) { //means not playing from download
                        showDeleteAlert(position);
                    } else {
                        String currentlyPlayingId = nowPlayingList.get(storage.loadAudioIndex()).getItem_id();
                        String currentSongId = songList.get(position).getItem_id();
                        if (currentlyPlayingId.equalsIgnoreCase(currentSongId)) {
                            Toast.makeText(mContext, R.string.you_can_not_remove_current_song, Toast.LENGTH_SHORT).show();
                        } else {
                            showDeleteAlert(position);
                        }
                    }
                } else {
                    showDeleteAlert(position);
                }
            }
        });

      /*  share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //shareSong(position);
            }
        });*/

        return rootView;
    }

    private void storeGlobalSongInfo(StorageUtil storage, int position) {
        storage.clearCachedAudioPlaylist();
        storage.storeAudio(songList);
        storage.storeAudioIndex(position);
        storage.storeMode(1);
        storage.storeIsPlayingFrom(DOWNLOADS);
        mContext.setShuffleMode(false);
        mContext.setRepeatMode(false);
        mContext.setNoOfRepeats(0);
        mContext.setMode(1);
    }

    private void shareSong(int position) {

        String  fileName = songList.get(position).getDownload_name() + ".mp3";

        File songDir = new File(Constants.DIRECTORY_PATH + Constants.SONG_FOLDER_PATH);
        if (!songDir.exists()) {
            return;
        }

        // Output stream to write file
        File outputFile = new File(songDir, fileName);
        String path = outputFile.getAbsolutePath();
        Uri photoURI = FileProvider.getUriForFile(mContext,mContext.getString(R.string.file_provider_authority),outputFile);
        String EXTRA_TEXT="I'm listening to '"+ songList.get(position).getDownload_name()+"' by "+ mContext.getString(R.string.app_name)+"..!";
        String EXTRA_SUBJECT= "'"+ songList.get(position).getDownload_name()+"' from "+mContext.getString(R.string.app_name)+"...";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.putExtra(Intent.EXTRA_TEXT,EXTRA_TEXT);
        //share.setType("text/plain");
        share.putExtra(Intent.EXTRA_STREAM, photoURI);
        share.setType("audio/*");
       // share.setPackage("com.whatsapp");
        share.putExtra(Intent.EXTRA_SUBJECT,EXTRA_SUBJECT);

        mContext.startActivity(Intent.createChooser(share, "Share with"));

    }

    private void showDeleteAlert(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

        builder.setTitle(R.string.confirm);
        builder.setMessage(R.string.do_you_want_to_remove_this_song);

        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog
                deleteSong(position);
                dialog.dismiss();
            }
        });

        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    private void deleteSong(int position) {
        fileName = songList.get(position).getDownload_name() + ".mp3";
        imageName = songList.get(position).getDownload_name() + ".jpg";
        lyricsPdf= songList.get(position).getDownload_name() + ".pdf";
        lyricsFileName= songList.get(position).getDownload_name();
        Log.d("SONG_PATH", "" + songList.get(position).getItem_file());
        Log.e("DIRECTORY_PATH", Constants.DIRECTORY_PATH);
       File songDir = new File(Constants.DIRECTORY_PATH
                +  Constants.SONG_FOLDER_PATH);
        if (!songDir.exists()) {
            return;
        }

        // Output stream to write file
        File outputFile = new File(songDir, fileName);
        if (outputFile.exists()) {
            boolean deleted = outputFile.delete();
            Log.e("songDeleted", "==" + deleted);
        }



        //delete image file
        File imgDir = new File(Constants.DIRECTORY_PATH +  Constants.IMAGE_FOLDER_PATH);
        if (!imgDir.exists()) {
            return;
        }

        // Output stream to write file
        File file = new File(imgDir, imageName);
        if (file.exists()) {
            boolean deleted = file.delete();
            Log.e("imageDeleted", "==" + deleted);
        }


        //delete image file
        File Lyricespdf = new File(Constants.DIRECTORY_PATH +  Constants.PDF_FOLDER_PATH);
        if (!Lyricespdf.exists()) {
            return;
        }

        // Output stream to write file
        File file2 = new File(Lyricespdf,lyricsPdf);
        if (file2.exists()) {
            boolean deleted = file.delete();
            Log.e("lyricsPdfDeleted", "==" + deleted);
        }


        RealmHelper realmHelper = new RealmHelper();
        Log.e("itemId", songList.get(position).getItem_id());
        realmHelper.deleteSongData(songList.get(position).getItem_id());

        StorageUtil storage = new StorageUtil(getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        int audioIndex = storage.loadAudioIndex();
        if (audioList != null && audioIndex!=-1) {
            String currentlyPlayingId = audioList.get(audioIndex).getItem_id();
            if (!audioList.get(0).getItem_file().startsWith("https")) { //means not playing from download
                for (SubCategoryModel model:audioList) {
                    String currentSongId = songList.get(position).getItem_id();
                    if (model.getItem_id().equalsIgnoreCase(currentSongId)) {
                        audioList.remove(model);
                        storage.storeAudio(audioList);
                        break;
                    }
                }

                ArrayList<SubCategoryModel> currentQueue = storage.loadAudio();
                for (int i = 0; i < currentQueue.size(); i++) {
                    if (currentQueue.get(i).getItem_id().equals(currentlyPlayingId)) {
                        storage.storeAudioIndex(i);
                        Log.e("New Index == ",String.valueOf(i));
                        break;
                    }
                }
            }
        }
        songList.remove(position);
        Toast.makeText(mContext, R.string.song_removed_successfully, Toast.LENGTH_SHORT).show();
        if (songList.isEmpty()) {
            classContext.error_layout_downloads.setVisibility(View.VISIBLE);
        }
        notifyDataSetChanged();

    }
}