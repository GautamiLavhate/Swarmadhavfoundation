package com.applexinfotech.swarmadhavfoundation.fcm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Sync {
    Models mod;
    SessionManager session;
    private DataBaseAdapter dba;
    String strDate;


    public void syncdata(Context context) {
        JSONArray jobj;
        mod = new Models();
        ContentValues cv = new ContentValues();
        dba = new DataBaseAdapter(context);

        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        strDate = sdf.format(c.getTime());

        getGCMCallRequest(context);
    }

    private void getGCMCallRequest(Context contex) {
        session = new SessionManager(contex);
        NetworkRequest deliveryLocationRequest = new NetworkRequest(contex);
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.mobile_ID, session.getKEY_mobile()));
        deliveryLocationRequest.sendRequest(Constants.API_get_notification_URL,
                carData, GCMCallback);
    }


    private final NetworkRequest.NetworkRequestCallback GCMCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {
            try {
                JSONObject jGCMResult = new JSONObject(response.toString());
                String status = jGCMResult.getString("response_status");
                if (status.equalsIgnoreCase("1")) {
                    JSONArray data = jGCMResult.getJSONArray("data");
                    Log.d("data.length()", "" + data.length());

                    ContentValues contentValues = new ContentValues();

                    for (int i = 0; i < data.length(); i++) {

                        JSONObject jsonObject = data.getJSONObject(i);
                        if (!jsonObject.getString("title").trim().equalsIgnoreCase("null")) {
                            contentValues.put(Notifictable.KEY_title, jsonObject.getString("title").trim());
                        } else {
                            contentValues.put(Notifictable.KEY_title, "");
                        }
                        if (!jsonObject.getString("description").trim().equalsIgnoreCase("null")) {
                            contentValues.put(Notifictable.KEY_description, jsonObject.getString("description").trim());
                        } else {
                            contentValues.put(Notifictable.KEY_description, "");
                        }

                        if (!jsonObject.getString("notification_image").trim().equalsIgnoreCase("null")) {
                            contentValues.put(Notifictable.KEY_notification_image, jsonObject.getString("notification_image").trim());
                        } else {
                            contentValues.put(Notifictable.KEY_notification_image, "");
                        }

                        if (!jsonObject.getString("notification_id").trim().equalsIgnoreCase("null")) {
                            contentValues.put(Notifictable.KEY_id, jsonObject.getString("notification_id").trim());
                        } else {
                            contentValues.put(Notifictable.KEY_id, "");
                        }
                        contentValues.put(Notifictable.KEY_alert, "0");
                        contentValues.put(Notifictable.KEY_new_alert, "0");

                        dba.open();
                        Cursor cursor1 = DataBaseAdapter.ourDatabase.rawQuery("select * from Notifictable" + " where id=" + jsonObject.getString("notification_id").trim(), null);
                        if (cursor1.getCount() == 0) {

                                mod.insertdata(Notifictable.DATABASE_TABLE, contentValues);

                        }
                        cursor1.close();
                        dba.close();


                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            // showWaitIndicator(false);
        }
    };

}



