package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.model.SliderUtils;
import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;

public class SliderPagerAdapter extends SliderViewAdapter<SliderPagerAdapter.SliderAdapterViewHolder> {

    private ArrayList<SliderUtils> SliderItems;
    private Context context;
    private LayoutInflater layoutInflater;

    public SliderPagerAdapter(Context context, ArrayList<SliderUtils> sliderDataArrayList){
        this.context=context;
        this.SliderItems =sliderDataArrayList;

    }

    @Override
    public int getItemPosition(Object object) {
        return super.getItemPosition(object);
    }


    @Override
    public SliderAdapterViewHolder onCreateViewHolder(ViewGroup parent) {
        View inflate= LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_layout,null);
        return new SliderAdapterViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterViewHolder viewHolder,final int position) {
        final SliderUtils sliderItem= SliderItems.get(position);

        Glide.with(viewHolder.itemView)
                .load(sliderItem.getSliderImageUrl())

                .error(R.drawable.new_launching_logo)
                //.fitCenter()
                .into(viewHolder.imageViewBackground);
    }

    @Override
    public int getCount() {
        return SliderItems.size();
    }

    static class SliderAdapterViewHolder extends SliderViewAdapter.ViewHolder {
        View itemView;

        ImageView imageViewBackground;

        public SliderAdapterViewHolder(View itemView) {
            super(itemView);
            imageViewBackground=itemView.findViewById(R.id.myimage);
            this.itemView=itemView;
        }
    }
}
