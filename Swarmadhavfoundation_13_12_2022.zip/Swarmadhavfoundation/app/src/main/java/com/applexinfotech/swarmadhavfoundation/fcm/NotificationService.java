package com.applexinfotech.swarmadhavfoundation.fcm;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;


@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class NotificationService extends JobService {
    private static final String TAG = NotificationService.class.getSimpleName();
    JobParameters params;
    public static int time =1000;
    private DataBaseAdapter dba = new DataBaseAdapter(NotificationService.this);

    public NotificationService() {

    }

    @Override
    public boolean onStartJob(JobParameters params) {
        UtilsJobInfo.scheduleJob(getApplicationContext(), NotificationService.class);
        Log.d(TAG, "Job Started");
        this.params = params;
        doTask();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Log.d(TAG, "Job Force Stopped");
        // reschedule job return true else return false
        jobFinished(params, true);
        return true;
    }

    private void doTask() {
        try {
            if (InternetStatus.isInternetOn(NotificationService.this)) {
                AsyncCallsublist task = new AsyncCallsublist();
                task.execute();
            } else {

            }
        } catch (Exception e) {
        }

    }

    public void showNotification() {
        try {
            dba.open();
            Cursor cursor1 = DataBaseAdapter.ourDatabase.rawQuery("select * from Notifictable where alert= 0", null);
            if (cursor1.getCount() > 0) {
                while (cursor1.moveToNext()) {
                    String id = cursor1.getString(cursor1.getColumnIndex("id"));
                    String title = cursor1.getString(cursor1.getColumnIndex("title"));
                    String desc = cursor1.getString(cursor1.getColumnIndex("description"));

                    dba.open();
                    String sql = "Update " + Notifictable.DATABASE_TABLE + " set alert= 1" + " where id=" + id;
                    DataBaseAdapter.ourDatabase.execSQL(sql);
                    Log.e("set1","update Key1");
                    dba.close();

                    String CHANNEL_ID = "default_channnel_id";
                    CharSequence name = "my_channel";
                    String Description = "This is my channel";
                    int NOTIFICATION_ID = 234;

                    Uri soundUri = Uri.parse("android.resource://"
                            + getApplication().getPackageName() + "/" + RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI);
                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                        AudioAttributes attributes = new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                .build();
                        NotificationChannel mChannel = notificationManager.getNotificationChannel(CHANNEL_ID);
                        if (mChannel == null) {
                            int importance = NotificationManager.IMPORTANCE_HIGH;
                            mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
                            mChannel.setDescription(Description);
                            mChannel.enableLights(true);
                            mChannel.setSound(soundUri, attributes);
                            mChannel.enableVibration(true);
                            mChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
                            mChannel.setShowBadge(true);
                            notificationManager.createNotificationChannel(mChannel);
                        }
                    }
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);


                    final int requestCode = (int) System.currentTimeMillis() / 1000;
                    PendingIntent pIntent = PendingIntent.getActivity(getApplicationContext(), requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT);

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                            .setContentTitle("Alert for " + "logo_swar")
                            .setContentText(cursor1.getString(cursor1.getColumnIndex("title")))
                            .setSmallIcon(R.drawable.logo_swar)
                            .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.logo_swar))
                            .setContentIntent(pIntent)
                            .setAutoCancel(true)
                            .setSound(soundUri)
                            .setColor(getResources().getColor(R.color.colorPrimaryDark));

                    if (notificationManager != null) {
                        notificationManager.notify(requestCode, builder.build());
                    }

                    Thread.sleep(5000);
                }
            }
            cursor1.close();
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }finally {
            dba.close();
            jobFinished(params, true);
        }
    }
    private class AsyncCallsublist extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            // Call Web Method
            try {
                new Sync().syncdata(NotificationService.this);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @SuppressLint({"ResourceAsColor", "ApplySharedPref"})
        @Override
        // Once WebService returns response
        protected void onPostExecute(Void result) {
            try {
                new Shownotificationasyc().execute();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        // Make Progress Bar visible
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }







    private class Shownotificationasyc extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            // Call Web Method
            try {
                showNotification();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @SuppressLint({"ResourceAsColor", "ApplySharedPref"})
        @Override
        // Once WebService returns response
        protected void onPostExecute(Void result) {

        }

        @Override
        // Make Progress Bar visible
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

}