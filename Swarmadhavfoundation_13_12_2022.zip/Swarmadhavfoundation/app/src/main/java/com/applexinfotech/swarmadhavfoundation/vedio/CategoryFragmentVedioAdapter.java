package com.applexinfotech.swarmadhavfoundation.vedio;

import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.AddPlaylistVedioDialog;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.ClickGuard;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_PLAYLIST;


/**
 * Created by Jaydeep Jikadra on 1/2/2018.
 */
public class CategoryFragmentVedioAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final RealmHelper realmHelper;
    private LayoutInflater layoutInflater;

    // The list of banner ads and menu items.
    private final ArrayList<Object> categoryListWIthAd;
    public MainActivity mContext;
    //private static int LIST_AD_DELTA = 0;
    private static final int CONTENT = 0;
    private static final int AD = 1;
    private String fragmentTag;
    private HomeModel homeModel;
    private String fileName, imageName,videoName,lyricsPdf;
    // A menu item view type.
    private static final int MENU_ITEM_VIEW_TYPE = 0;
    private PopupMenu menu;
    // The banner ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;
    public static ArrayList<SongModel> songsID = new ArrayList<>();
    private OnItemClickListener mListener;
    private Playlist selectedPlaylist;
    private ArrayList<SubCategoryModel> mItem = new ArrayList<>();

    public void setSelectedPlaylist(Playlist selectedPlaylist) {
        this.selectedPlaylist = selectedPlaylist;
    }



    public CategoryFragmentVedioAdapter(MainActivity context, ArrayList<Object> list, HomeModel homeModel, String canonicalName) {
        mContext = context;
        this.categoryListWIthAd = list;
        Log.e("noOfItem", String.valueOf(this.categoryListWIthAd.size()));
        this.homeModel = homeModel;
        this.fragmentTag = canonicalName;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        for (Object recyclerItem : categoryListWIthAd) {
            if (recyclerItem instanceof SubCategoryModel) {
                SubCategoryModel model = (SubCategoryModel) recyclerItem;
                if (fragmentTag.equalsIgnoreCase(" com.applex.swarsageetmala.vedio.CategoryFragmentVedio")) {
                    if (homeModel != null) {
                        if (homeModel.getCategory_name() != null) {
                            model.setCategory_id(homeModel.getCategory_id());
                            model.setCategory_image(homeModel.getCategory_image());
                            model.setCategory_name(homeModel.getCategory_name());
                            model.setTypeHm(homeModel.getTypeHm());
                        }
                    }
                }
                mItem.add(model);
            }
        }


        //Get path of song name
        realmHelper = new RealmHelper();
    }


    @Override
    public int getItemViewType(int position) {
        return MENU_ITEM_VIEW_TYPE;
       /* if (LIST_AD_DELTA == 0) {
            return MENU_ITEM_VIEW_TYPE;
        } else
            return (position > 0 && position % LIST_AD_DELTA == 0) ? UNIFIED_NATIVE_AD_VIEW_TYPE
                    : MENU_ITEM_VIEW_TYPE;*/
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
           /* case UNIFIED_NATIVE_AD_VIEW_TYPE:
                View bannerLayoutView = LayoutInflater.from(
                        parent.getContext()).inflate(R.layout.list_item_ad,
                        parent, false);
                return new AdViewHolder(bannerLayoutView);*/
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                View menuItemLayoutView = LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.subcategory_list_itemvedio, parent, false);
                return new MenuItemViewHolder(menuItemLayoutView);


        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case MENU_ITEM_VIEW_TYPE:
                final MenuItemViewHolder menuItemHolder = (MenuItemViewHolder) holder;
                SubCategoryModel content = (SubCategoryModel) categoryListWIthAd.get(position);
                //Get path of song name
                songsID = new ArrayList<>();
                songsID = realmHelper.retrieveVideoIdListDEmo();
                menuItemHolder.tv_title.setTypeface(mContext.getTypeFace());
                menuItemHolder.tv_desc.setTypeface(mContext.getTypeFace());
                menuItemHolder.tv_duration.setTypeface(mContext.getTypeFace());

                menuItemHolder.tv_title.setText(content.getItem_name());
                menuItemHolder.tv_desc.setText(content.getItem_description());


                Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.download.setImageDrawable(mDrawable);
                Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.play.setImageDrawable(arrowDrawable);
                Drawable playDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                playDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.imagePlay.setImageDrawable(playDrawable);
                Drawable popupMenuDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_more_new);
                popupMenuDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.popupMenu.setImageDrawable(popupMenuDrawable);

                if (InternetStatus.isInternetOn(mContext)) {
                    Glide.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);
                    //Picasso.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);

                } else {
                    /*try {
                        Bitmap bitmap = BitmapFactory.decodeFile(content.getItem_image());

                        BitmapDrawable d = new BitmapDrawable(bitmap);
                        menuItemHolder.cat_image.setImageBitmap(bitmap);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }*/
                        Glide.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);
                        // Picasso.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).fit().into(menuItemHolder.cat_image);
                    
                }


                menuItemHolder.download.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mListener != null) {
                            SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                            if (selectedObject.getCategory_id() == null) {
                                if (homeModel != null) {
                                    if (homeModel.getCategory_name() != null) {
                                        selectedObject.setCategory_id(homeModel.getCategory_id());
                                        selectedObject.setCategory_image(homeModel.getCategory_image());
                                        selectedObject.setCategory_name(homeModel.getCategory_name());
                                        selectedObject.setTypeHm(homeModel.getTypeHm());
                                    }
                                }
                            }
                            if (selectedObject.isDownloaded) {

                                if (songsID != null) {

                                    if (songsID.size() > 0) {

                                        for (int i = 0; i < songsID.size(); i++) {

                                            if (content.getItem_id().equals(songsID.get(i).getItem_id())) {
                                                if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                                    // download
                                                    content.setDownloaded(false);
                                                    ToastUtil.showShortToastMessage(getApplicationContext(), "Already Downloading.." + selectedObject.getDownload_name());

                                                } else {
                                                    deleteSong(songsID,i);
                                                    //update code
                                                    int pos = getAudioIndexFromList(selectedObject.getItem_id());
                                                    mListener.onItemClick(v, pos, selectedObject);
                                                    menuItemHolder.download.setClickable(false);
                                                    ClickGuard.guard(menuItemHolder.download);
                                                    selectedObject.setDownloaded(true);
                                                }
                                                break;
                                            }

                                        }
                                    }

                                }
                            } else {
                                //fresh download
                                int pos = getAudioIndexFromList(selectedObject.getItem_id());
                                mListener.onItemClick(v, pos, selectedObject);
                                menuItemHolder.download.setClickable(false);
                                ClickGuard.guard(menuItemHolder.download);
                                selectedObject.setDownloaded(true);

                            }
                        }
                    }
                });


                if (!content.getItem_file().startsWith("https")) {
                    menuItemHolder.download.setVisibility(View.GONE);
                    menuItemHolder.tv_youtube_label.setVisibility(View.GONE);
                    content.setDownloaded(true);
                }else if(Utils.isYoutubeLink(content.getVideo_url())){
                    menuItemHolder.download.setVisibility(View.GONE);
                    menuItemHolder.tv_youtube_label.setVisibility(View.VISIBLE);
                } else {
                    menuItemHolder.tv_youtube_label.setVisibility(View.GONE);
                    Drawable mDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                    mDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    menuItemHolder.download.setImageDrawable(mDrawable1);
                    if (songsID != null) {

                        if (songsID.size() > 0) {

                            for (int i = 0; i < songsID.size(); i++) {

                                if (content.getItem_id().equals(songsID.get(i).getItem_id())) {
                                    if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                    content.setDownloaded(true);
                                    Drawable arrowDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_download_complete);

                                    arrowDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                                    menuItemHolder.download.setBackgroundResource(0);
                                    menuItemHolder.download.setImageDrawable(arrowDrawable1);


                                    // menuItemHolder.download.setBackgroundResource(R.drawable.download_finished);
                                    menuItemHolder.download.setClickable(false);
                                    ClickGuard.guard(menuItemHolder.download);
                                    menuItemHolder.download.setOnClickListener(null);
                                    }else {
                                        menuItemHolder.download.setVisibility(View.VISIBLE);
                                        content.setDownloaded(false);
                                    }

                                    break;
                                } else {
                                    menuItemHolder.download.setVisibility(View.VISIBLE);
                                    content.setDownloaded(false);
                                }
                            }
                        }
                    }
                }
                menuItemHolder.play.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        menuItemHolder.layout_main.performClick();
                    }
                });
                menuItemHolder.imagePlay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        menuItemHolder.layout_main.performClick();
                    }
                });
                menuItemHolder.layout_main.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mContext.player != null) {
                            if (mContext.isPlaying()) {
                                mContext.pauseSong();
                                ((MainActivity) mContext).bottum_layout.setVisibility(View.GONE);
                            }
                        }

                        SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                        //clear cached playlist
                        Utilities.hideKeyboard(mContext);
                        String videoUrl = selectedObject.getVideo_url();
                        if(Utils.isYoutubeLink(videoUrl)){
                           //mContext.playYoutubeVideo(selectedObject);
                        }else {
                            int audIndex=0;
                            ArrayList<SubCategoryModel> filteredList=new ArrayList<>();
                            for (SubCategoryModel subCategoryModel : mItem) {
                                if(!Utils.isYoutubeLink(subCategoryModel.getVideo_url())){
                                    filteredList.add(subCategoryModel);
                                }
                            }
                            for (int i=0;i< filteredList.size();i++) {
                                String id=filteredList.get(i).getItem_id();
                                if(selectedObject.getItem_id().equals(id)){
                                    audIndex=i;
                                    break;
                                }
                            }
                            StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                            storage.clearCachedAudioPlaylist();
                            storage.storeAudio(filteredList);
                            //storage.storeAudioIndex(getAudioIndexFromList(selectedObject.getItem_id()));
                            storage.storeAudioIndex(audIndex);
                            storage.storeMode(0);
                            mContext.setMode(0);
                            storage.storeIsPlayingFrom("Category");
                            Intent intent = new Intent(mContext, VideoPlayer.class);
                            mContext.startActivity(intent);
                        }
                    }
                });

                menuItemHolder.popupMenu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        if (menu != null) {
                            menu.dismiss();
                        }
                        menu = new PopupMenu(mContext, v);
                        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.popup_song_remove_playlist:
                                        boolean isCurrantSong = false;
                                        if (categoryListWIthAd != null && !categoryListWIthAd.isEmpty() && categoryListWIthAd.size() > position) {
                                            if (categoryListWIthAd.get(position) instanceof SubCategoryModel) {
                                                SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                                                StorageUtil storage = new StorageUtil(getApplicationContext());
                                                int currentPlaylistId = storage.loadCurrentPlaylistId();
                                                int mode=storage.loadMode();
                                                if ( mode == 2 && currentPlaylistId != -1) {
                                                    int selectedId = selectedPlaylist.getId();
                                                    if (currentPlaylistId == selectedId) {  //means current playlist is playing
                                                        String currentlyPlayingId = storage.loadAudio().get(storage.loadAudioIndex()).getItem_id();
                                                        isCurrantSong = currentlyPlayingId.equalsIgnoreCase(selectedObject.getItem_id());
                                                    }
                                                }
                                                if (isCurrantSong) {
                                                    Toast.makeText(mContext, R.string.you_can_not_remove_current_song, Toast.LENGTH_SHORT).show();
                                                } else {
                                                    removeSongFromPlaylist(selectedObject, position);
                                                }
                                            }
                                        }
                                        break;
                                    case R.id.popup_song_play:
                                        menuItemHolder.layout_main.performClick();
                                        break;
                                    case R.id.popup_song_addto_playlist:
                                        if(InternetStatus.isInternetOn(mContext)) {
                                            if (categoryListWIthAd != null && !categoryListWIthAd.isEmpty() && categoryListWIthAd.size() > position) {
                                                if (categoryListWIthAd.get(position) instanceof SubCategoryModel) {
                                                    SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                                                    FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                    AddPlaylistVedioDialog infoDialog = AddPlaylistVedioDialog.newInstance("SongList", selectedObject, "Vedio");
                                                    infoDialog.setCancelable(false);
                                                    infoDialog.show(fragmentManager, "Dialog");
                                                }
                                            }
                                        }else {
                                            Toast.makeText(mContext,R.string.no_internet_connection_found,Toast.LENGTH_SHORT).show();
                                        }
                                        break;
                                    case R.id.download:
                                        menuItemHolder.download.performClick();
                                        break;
                                }
                                return false;
                            }
                        });
                        menu.inflate(R.menu.popup_video);
                        menu.show();
                        if (fragmentTag.equals(FROM_PLAYLIST))
                            menu.getMenu().findItem(R.id.popup_song_remove_playlist).setVisible(true);


                        if (!content.getItem_file().startsWith("https")) {
                            menuItemHolder.download.setVisibility(View.GONE);
                            menuItemHolder.tv_youtube_label.setVisibility(View.GONE);
                            content.setDownloaded(true);
                        }else if(Utils.isYoutubeLink(content.getVideo_url())){
                            menuItemHolder.download.setVisibility(View.GONE);
                            menuItemHolder.tv_youtube_label.setVisibility(View.VISIBLE);
                        }else {
                            menuItemHolder.tv_youtube_label.setVisibility(View.GONE);
                            if (songsID != null) {

                                if (songsID.size() > 0) {

                                    for (int i = 0; i < songsID.size(); i++) {

                                        if (content.getItem_id().equals(songsID.get(i).getItem_id())) {
                                            if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                                // download
                                                menu.getMenu().findItem(R.id.download).setEnabled(false);
                                                content.setDownloaded(false);

                                            } else {

                                                content.setDownloaded(true);
                                                menu.getMenu().findItem(R.id.download).setEnabled(true);
                                                menu.getMenu().findItem(R.id.download).setTitle("Update");
                                            }
                                            break;
                                        } else {
                                            menu.getMenu().findItem(R.id.download).setEnabled(true);
                                            content.setDownloaded(false);
                                        }
                                    }
                                }
                            }else {
                                menuItemHolder.download.setVisibility(View.GONE);
                                menu.getMenu().findItem(R.id.download).setEnabled(false);
                                content.setDownloaded(true);
                            }


                        }
                    }
                });

                break;
            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return categoryListWIthAd.size();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }


    public class MenuItemViewHolder extends RecyclerView.ViewHolder {

        private ImageButton play;
        public ImageButton download;
        private TextView tv_title, tv_desc, tv_duration,tv_youtube_label;
        private String urls;
        private String imgpath;
        private LinearLayout layout_main;
        public ProgressBar downloadProgress;
        private ImageButton popupMenu;
        private ImageView cat_image, imagePlay;

        public MenuItemViewHolder(View itemView) {
            super(itemView);
            cat_image = (ImageView) itemView.findViewById(R.id.image);

            play = (ImageButton) itemView.findViewById(R.id.play);
            download = (ImageButton) itemView.findViewById(R.id.download);

            tv_title = (TextView) itemView.findViewById(R.id.tv_title);
            tv_desc = (TextView) itemView.findViewById(R.id.tv_desc);
            tv_duration = (TextView) itemView.findViewById(R.id.tv_duration);
            tv_youtube_label = (TextView) itemView.findViewById(R.id.label_youTube);
            popupMenu = itemView.findViewById(R.id.popup_menu);
            layout_main = (LinearLayout) itemView.findViewById(R.id.layout_main);
            downloadProgress = itemView.findViewById(R.id.download_progress_normal);
            imagePlay = itemView.findViewById(R.id.img_play);
        }
    }


    private int getAudioIndexFromList(String itemId) {
        int position = 0;
        for (int i = 0; i < mItem.size(); i++) {
            if (mItem.get(i).getItem_id().equals(itemId)) {
                position = i;
                break;
            }
        }
        return position;
    }

    private void removeSongFromPlaylist(SubCategoryModel selectedObject, int position) {
        realmHelper.removeSongFromPlaylist(selectedPlaylist, selectedObject);
        StorageUtil storage = new StorageUtil(getApplicationContext());
        int currentPlaylistId = storage.loadCurrentPlaylistId();
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        String currentlyPlayingId = audioList.get(storage.loadAudioIndex()).getItem_id();
        if (audioList != null) {
            int selectedPlayList = selectedPlaylist.getId();
            if (storage.loadMode() == 2 && currentPlaylistId != -1) { //means not playing from playlist
                if (currentPlaylistId == selectedPlayList) {
                    for (SubCategoryModel model : audioList) {
                        if (model.getItem_id().equalsIgnoreCase(selectedObject.getItem_id())) {
                            audioList.remove(model);
                            storage.storeAudio(audioList);
                            break;
                        }
                    }
                    ArrayList<SubCategoryModel> currentQueue = storage.loadAudio();
                    for (int i = 0; i < currentQueue.size(); i++) {
                        if (currentQueue.get(i).getItem_id().equals(currentlyPlayingId)) {
                            storage.storeAudioIndex(i);
                            Log.e("New Index == ",String.valueOf(i));
                            break;
                        }
                    }

                }
            }
        }
        ToastUtil.showShortToastMessage(getApplicationContext(), selectedObject.getItem_name() + " removed from " + selectedPlaylist.getName());
        categoryListWIthAd.remove(position);
        notifyDataSetChanged();
    }

    private void deleteSong(ArrayList<SongModel> songList,int position) {
        fileName = songList.get(position).getDownload_name() + ".mp3";
        videoName=Utilities.getVideoName(songList.get(position).getVideo_url());
        imageName = songList.get(position).getDownload_name() + ".jpg";
        lyricsPdf= songList.get(position).getDownload_name() + ".pdf";
        Log.d("SONG_PATH", "" + songList.get(position).getVideo_url());

        //delete mp4 file
        File videoDir = new File(Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH);
        if (!videoDir.exists()) {
            return;
        }

        // Output stream to write file
        File outputFile2 = new File(videoDir, videoName);
        if (outputFile2.exists()) {
            boolean deleted = outputFile2.delete();
            Log.e("videoDeleted", "==" + deleted);
        }

        //delete image file
        File imgDir = new File(Constants.DIRECTORY_PATH + Constants.IMAGE_FOLDER_PATH);
        if (!imgDir.exists()) {
            return;
        }

        // Output stream to write file
        File file = new File(imgDir, imageName);
        if (file.exists()) {
            boolean deleted = file.delete();
            Log.e("imageDeleted", "==" + deleted);
        }


        RealmHelper realmHelper = new RealmHelper();
        Log.e("itemId", songList.get(position).getItem_id());
        realmHelper.deleteSongData(songList.get(position).getItem_id());

        StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        if (audioList != null) {
            if (!audioList.get(0).getVideo_url().startsWith("https")) { //means not playing from download
                for (int i = 0; i < audioList.size(); i++) {
                    String currentlyPlayingId = audioList.get(i).getItem_id();
                    String currentSongId = songList.get(position).getItem_id();
                    if (currentlyPlayingId.equalsIgnoreCase(currentSongId)) {
                        audioList.remove(i);
                        storage.storeAudio(audioList);
                        int index = storage.loadAudioIndex();
                        if (index > 0) {
                            storage.storeAudioIndex(index - 1);
                        }
                        break;
                    }
                }
            }
        }
        songList.remove(position);
        notifyDataSetChanged();
    }
}
