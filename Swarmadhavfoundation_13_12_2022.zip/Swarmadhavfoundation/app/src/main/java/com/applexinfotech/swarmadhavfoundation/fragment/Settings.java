package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.LoginActivity;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.nostra13.universalimageloader.cache.memory.impl.LargestLimitedMemoryCache;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.view.Gravity.START;
import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Settings#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Settings extends MasterFragment {
    private MainActivity mContext;

    LinearLayout linearLayoutMyProfile,linearLayoutAboutUs,
            linearLayoutTermsAndCondition,linearLayoutMyPrivacyAndPolicy,
            linearLayoutLogout;
    Button btnNO,btnYes;
    SessionManager sessionManager;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Settings() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Settings.
     */
    // TODO: Rename and change types and number of parameters
    public static Settings newInstance(String param1, String param2) {
        Settings fragment = new Settings();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mContext=(MainActivity)getMasterActivity();
        return inflater.inflate(R.layout.fragment_settings, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext.setTitle("Settings");
        mContext.showDrawerBack();

        sessionManager=new SessionManager(getMasterActivity());
       // mContext.hideDrawer();
        linearLayoutMyProfile=view.findViewById(R.id.linearLayoutMyProfile);
        linearLayoutAboutUs=view.findViewById(R.id.linearLayoutAboutUs);
        linearLayoutTermsAndCondition=view.findViewById(R.id.linearLayoutTermsAndCondition);
        linearLayoutMyPrivacyAndPolicy=view.findViewById(R.id.linearLayoutMyPrivacyAndPolicy);
        linearLayoutLogout=view.findViewById(R.id.linearLayoutLogout);
        onClick();
    }
    public void onClick(){
        linearLayoutMyProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProfileDetailFragment profileDetailFragment=new ProfileDetailFragment();
                mContext.ReplaceFragment(profileDetailFragment);
            }
        });
        linearLayoutAboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AboutUs aboutUs=new AboutUs();
                mContext.ReplaceFragment(aboutUs);
            }
        });
        linearLayoutTermsAndCondition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://docs.google.com/document/d/1BJRgBj0n4izel2YDQb_FtAqxItkUELz6FmrgEO3YVys/edit?usp=sharing";
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    Uri uri = Uri.parse(url);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }else{
                    Toast.makeText(mContext, "Invalid Url", Toast.LENGTH_SHORT).show();
                }
            }
        });
        linearLayoutMyPrivacyAndPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://docs.google.com/document/d/1LRVaGIk_yIymqBeSV-Y4MYck9_Fshx7iiEC7-RL1wRg/edit?usp=sharing";
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    Uri uri = Uri.parse(url);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }else{
                    Toast.makeText(mContext, "Invalid Url", Toast.LENGTH_SHORT).show();
                }
            }
        });
        linearLayoutLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alert_logout=new AlertDialog.Builder(mContext,R.style.NewCustomAlertDialog);
                final View custom_logout=getLayoutInflater()
                        .inflate(R.layout.custom_confirm_logout,null);
                alert_logout.setView(custom_logout);
                //add a button
                btnNO=custom_logout.findViewById(R.id.btnNo);
                btnYes=custom_logout.findViewById(R.id.btnYes);
                final AlertDialog alertDialog=alert_logout.create();
                btnNO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                btnYes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        postlogout();
                    }
                });
                alertDialog.show();
                alertDialog.setCancelable(false);
            }

        });

        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mContext.onBackPressed();
            }
        });
    }
    private void postlogout() {
        mContext.showWaitIndicator(true);
        String mobile_IDst=sessionManager.getKEY_mobile();

        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.mobile_ID,mobile_IDst));
        dishRequest.sendRequest(Constants.API_Logout,
                carData, catCallback);
    }
    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("Logout", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    String response_message=jObject.getString("response_message");
                    if (status.equalsIgnoreCase("1")) {
                        ToastUtil.showLongToastMessage(getMasterActivity(),response_message);
                        sessionManager.logoutUser();
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        mContext.finish();

                    }else{
                        mContext.showWaitIndicator(false);
                        ToastUtil.showLongToastMessage(getMasterActivity(),response_message);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);

        }
    };
}