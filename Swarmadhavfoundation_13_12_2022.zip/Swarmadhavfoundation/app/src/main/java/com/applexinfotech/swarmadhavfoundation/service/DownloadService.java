package com.applexinfotech.swarmadhavfoundation.service;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.FileDownloader;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.executer.DefaultExecutorSupplier;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;

import org.apache.http.util.ByteArrayBuffer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.concurrent.ThreadPoolExecutor;

import static com.applexinfotech.swarmadhavfoundation.MainActivity.downloadQueue;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.DOWNLOADS;

/**
 * Created by JD Android on 10-Aug-18.
 */

public class DownloadService extends Service {
    private static final String TAG ="DownloadService" ;
    public static final String ACTION_DOWNLOAD_BROAD_CAST = "com.applexinfotech.swarmadhavfoundation.ACTION_DOWNLOAD_BROAD_CAST";
    // Binder given to clients
    private final IBinder iBinder = new LocalBinder();
    public static final String ACTION_START_DOWNLOAD = "com.applexinfotech.swarmadhavfoundation.ACTION_START_DOWNLOAD";
    public static final String ACTION_PAUSE_DOWNLOAD = "com.applexinfotech.swarmadhavfoundation.ACTION_PAUSE_DOWNLOAD";
    public static final String ACTION_STOP_DOWNLOAD = "com.applexinfotech.swarmadhavfoundation.ACTION_STOP_DOWNLOAD";
    public static final String SHUTDOWN_EXECUTOR = "com.applexinfotech.swarmadhavfoundation.SHUTDOWN_EXECUTOR";
    public static final String EXTRA_POSITION = "com.applexinfotech.swarmadhavfoundation.EXTRA_POSITION";
    public static final String EXTRA_APP_INFO = "com.applexinfotech.swarmadhavfoundation.EXTRA_APP_INFO";

    private LocalBroadcastManager mLocalBroadcastManager;
    ThreadPoolExecutor threadPoolExecutor;
    final ArrayList<String> downloadList = new ArrayList<>();
    private ArrayList<String> realmIdList;
    private Handler handler;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return iBinder;
    }

    /**
     * Service Binder
     */
    public class LocalBinder extends Binder {
        public DownloadService getService() {
            // Return this instance of LocalService so clients can call public methods
            return DownloadService.this;
        }
    }
    @Override
    public void onCreate() {
        super.onCreate();
        register_shutdown();
        handler = new Handler(Looper.getMainLooper());

        realmIdList = new RealmHelper().retrieveSongIdList();
        if (realmIdList != null) {
            if (realmIdList.size() > 0) {
                downloadList.clear();
                downloadList.addAll(realmIdList);
            }
        }
//        Intent closeIntent=new Intent(this,DownloadService.class);
//        closeIntent.setAction(ACTION_STOP_DOWNLOAD);
//        PendingIntent pendingIntent=PendingIntent.getService(this,0,closeIntent,0);
    }

    private void register_shutdown() {
        //Register playNewMedia receiver
        IntentFilter filter = new IntentFilter(MainActivity.Broadcast_STOP_DOWNLOADING);
        registerReceiver(shutDown, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        handleIncomingActions(intent);
        return super.onStartCommand(intent, flags, startId);
    }

    private void handleIncomingActions(Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String actionString = intent.getAction();
        if (actionString.equalsIgnoreCase(ACTION_START_DOWNLOAD)) {
            // startDownloading();
        } else if (actionString.equalsIgnoreCase(ACTION_PAUSE_DOWNLOAD)) {
        } else if (actionString.equalsIgnoreCase(ACTION_STOP_DOWNLOAD)) {
        } else if (actionString.equalsIgnoreCase(SHUTDOWN_EXECUTOR)) {
        }
    }


    public void startDownloading(final SubCategoryModel subCategoryModel, final int position) {
        if (downloadQueue.isEmpty()) {
            downloadQueue.add(subCategoryModel);
        } else {
            if (contains(subCategoryModel.getItem_id())) {
                Log.e(TAG, "alreadyDownloaded");
                Log.e("DIRECTORY_PATH", Constants.DIRECTORY_PATH);
                handler.post(new Runnable() {

                    @Override
                    public void run() {
                        //Your UI code here
                        ToastUtil.showShortToastMessage(getApplicationContext(), "Already Downloading...." + subCategoryModel.getDownload_name());

                    }
                });
                return;
            } else {
                downloadQueue.add(subCategoryModel);
            }
        }

        if (threadPoolExecutor == null) {
            threadPoolExecutor = DefaultExecutorSupplier.getInstance().forBackgroundTasks();
        }
        threadPoolExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        // do some background work here.
                        int count;
                        try {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //Your UI code here
                                    ToastUtil.showShortToastMessage(getApplicationContext(), "Downloading.." + subCategoryModel.getDownload_name());
                                }
                            });
                            Log.e(TAG, "startDownloading");
                            URL url = new URL(subCategoryModel.getItem_file());
                            URLConnection conection = url.openConnection();
                            conection.setRequestProperty("Accept-Encoding", "identity");
                            conection.connect();
                            // getting file length
                            long lenghtOfFile = conection.getContentLength();
                            Log.e("Log", "url" + " " + url);
                            Log.e("Log", "lenghtOfFile" + " " + lenghtOfFile);
                            // input stream to read file - with 8k buffer
                            InputStream input = new BufferedInputStream(url.openStream(), 8192);

                            //Download image start
                            File  myDir = new File(Constants.DIRECTORY_PATH +  Constants.IMAGE_FOLDER_PATH);
                            myDir.mkdirs();
                            try {
                                File image = new File(myDir, subCategoryModel.getDownload_name() + ".jpg");
                                if (!image.exists()) {
                                    try {
                                        Bitmap Image = getImage(subCategoryModel.getItem_image());
                                        FileOutputStream out = new FileOutputStream(image);
                                        Image.compress(Bitmap.CompressFormat.JPEG, 90, out);
                                        out.flush();
                                        out.close();
                                    } catch (Exception e) {
                                        System.out.println("Error in downloading image:"
                                                + e.toString());
                                        e.printStackTrace();
                                    }
                                }
                            } catch (Exception ex) {
                                System.out.println("Error in downloading image:"
                                        + ex.toString());
                            }
                            //End

                            //Download category image start
                            myDir = new File(Constants.DIRECTORY_PATH +  Constants.CATEGORY_IMG_FOLDER_PATH);
                            myDir.mkdirs();
                            try {
                                File image = new File(myDir, subCategoryModel.getCategory_name() + ".jpg");
                                if (!image.exists()) {
                                    try {
                                        Bitmap Image = getImage(subCategoryModel.getCategory_image());
                                        FileOutputStream out = new FileOutputStream(image);
                                        Image.compress(Bitmap.CompressFormat.JPEG, 90, out);
                                        out.flush();
                                        out.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            } catch (Exception ex) {
                                System.out.println("Error in downloading category image:"
                                        + ex.toString());
                            }

                            //Download Pdf file
                            Log.d(TAG, "Downloading lyrics" + "http://maven.apache.org/maven-1.x/maven.pdf");
                            myDir = new File(Constants.DIRECTORY_PATH + Constants.PDF_FOLDER_PATH);
                            myDir.mkdirs();

                                try {
                                    File destFile = new File(myDir, subCategoryModel.getDownload_name() + ".pdf");
                                    // save to internal storage
                                    //Log.v(TAG, "Saving downloaded file ...");
                                    if (!destFile.exists()) {
                                        destFile.createNewFile();
                                    }
                                    //Download image start
                                    //myDir = new File(Constants.DIRECTORY_PATH + Constants.PDF_FOLDER_PATH);
//                                    if (!myDir.exists()) {
//                                        myDir.mkdirs();
//                                    }

                                    // save to internal storage
                                    //Log.v(TAG, "Saving downloaded file ...");

                                    FileDownloader.downloadFile("http://maven.apache.org/maven-1.x/maven.pdf", destFile);
                                } catch (Exception e) {
                                    Log.e(TAG, "Error while downloading and saving lyrics file !", e);
                                }



                            String vedioUrl=subCategoryModel.getVideo_url();

                            if(!vedioUrl.equals("null")) {
                                // vedio Downloding
                                // input stream to read file - with 8k buffer -DOWNLOAD VIDEO
                                myDir = new File(Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH);
                                myDir.mkdirs();
                                if (!myDir.exists()) {
                                    myDir.mkdirs();
                                }
                                String file_extn = Utilities.getFileExtension(subCategoryModel.getVideo_url());
                                // Output stream to write file
                                File outputFile = new File(myDir, subCategoryModel.getDownload_name() + "." + file_extn);
                                OutputStream output = new FileOutputStream(outputFile);
                                Log.e(TAG, "File Created");
                                byte data[] = new byte[1024];
                                long total = 0;
                                while ((count = input.read(data)) != -1) {
                                    total += count;
                                    // publishing the progress....
                                    // After this onProgressUpdate will be called
                                    // publishProgress("" + (int) ((total * 100) / lenghtOfFile));
                                    final int percent = (int) (total * 100 / lenghtOfFile);
                                    publishProgress(subCategoryModel, position, percent);
                                    // writing data to file
                                    output.write(data, 0, count);
                                }
                                // flushing output
                                output.flush();
                                Log.e(TAG, "File Written");
                                // closing streams
                                output.close();
                                input.close();
                            }else {
                                //start Downloading song
                                myDir = new File(Constants.DIRECTORY_PATH + Constants.SONG_FOLDER_PATH);
                                myDir.mkdirs();
                                if (!myDir.exists()) {
                                    myDir.mkdirs();
                                    Log.e(TAG, "File mkdir");
                                }
                                // Output stream to write file
                                File outputFilem = new File(myDir, subCategoryModel.getDownload_name() + ".mp3");
                                OutputStream outputm = new FileOutputStream(outputFilem);
                                byte datam[] = new byte[1024];
                                double totalm = 0;
                                while ((count = input.read(datam)) != -1) {
                                    totalm += count;
                                    // publishing the progress....
                                    // After this onProgressUpdate will be called
                                    // publishProgress("" + (int) ((total * 100) / lenghtOfFile));
                                    final int percent = (int) (totalm * 100 / lenghtOfFile);
                                    publishProgress(subCategoryModel, position, percent);
                                    // writing data to file
                                    outputm.write(datam, 0, count);
                                }

                                // flushing output
                                outputm.flush();

                                // closing streams
                                outputm.close();
                                input.close();
                                //End
                            }
                        } catch (Exception e) {
                            Log.e("Error: ", e.getMessage());
                        }
                    }
                });
    }

    public void stopDownloading(final SubCategoryModel subCategoryModel,final int position){
        threadPoolExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            ToastUtil.showLongToastMessage(getApplicationContext(), "Downloading Stopped...");
                        }
                    });
                    URL url = new URL(subCategoryModel.getItem_file());
                    HttpURLConnection conection = (HttpURLConnection)url.openConnection();
                    conection.setRequestProperty("Accept-Encoding", "identity");
                    conection.disconnect();
                }catch (Exception e){
                    Log.e("Error",e.getMessage());
                }
            }
        });
    }

    public void startDownloadingPdf(final SubCategoryModel subCategoryModel,final int position){
        if (downloadQueue.isEmpty()){
            downloadQueue.add(subCategoryModel);
        }else {
            if (contains(subCategoryModel.getItem_id())){
                Log.e(TAG, "alreadyDownloadedPDF");
                Log.e("DIRECTORY_PATH", Constants.DIRECTORY_PATH);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                       ToastUtil.showLongToastMessage(getApplicationContext(),"Already downloading pdf");
                    }
                });
                return;
            }else {
                downloadQueue.add(subCategoryModel);
            }
        }
        if (threadPoolExecutor==null){
            threadPoolExecutor=DefaultExecutorSupplier.getInstance().forBackgroundTasks();
        }
        threadPoolExecutor.execute(new Runnable() {
            @Override
            public void run() {
                int count;
               try {
                   handler.post(new Runnable() {
                       @Override
                       public void run() {
                           ToastUtil.showLongToastMessage(getApplicationContext(),"Downloading PDF...");
                       }
                   });
                   Log.e(TAG, "startDownloadingPDF");
                   URL url = new URL("http://maven.apache.org/maven-1.x/maven.pdf");
                   URLConnection conection = url.openConnection();
                   conection.setRequestProperty("Accept-Encoding", "identity");
                   conection.connect();
                   // getting file length
                   long lenghtOfFile = conection.getContentLength();
                   Log.e("Log", "url" + " " + url);
                   Log.e("Log", "lenghtOfFile" + " " + lenghtOfFile);
                   // input stream to read file - with 8k buffer
                   InputStream input = new BufferedInputStream(url.openStream(), 8192);

                   //Download Pdf file
                   Log.d(TAG, "Downloading lyrics" + "http://maven.apache.org/maven-1.x/maven.pdf");
                   File myDir = new File(Constants.DIRECTORY_PATH + Constants.PDF_FOLDER_PATH);
                   myDir.mkdirs();
                   if (!myDir.exists()){
                       myDir.mkdirs();
                   }
                   // Output stream to write file
                   File destFile = new File(myDir, subCategoryModel.getDownload_name() + ".pdf");
                   FileDownloader.downloadFile("http://maven.apache.org/maven-1.x/maven.pdf", destFile);
                   OutputStream outputStream=new FileOutputStream(destFile);

                   byte datam[]=new byte[1024];
                   double totalm=0;
                   while ((count=input.read(datam))!=-1){
                       totalm += count;
                       // publishing the progress....
                       // After this onProgressUpdate will be called
                       // publishProgress("" + (int) ((total * 100) / lenghtOfFile));
                       final int percent = (int) (totalm * 100 / lenghtOfFile);
                       publishProgress(subCategoryModel, position, percent);
                       // writing data to file
                       outputStream.write(datam, 0, count);
                   }
                   // flushing output
                   outputStream.flush();
                   // closing streams
                   outputStream.close();
                   input.close();

//                   Intent target = new Intent(Intent.ACTION_VIEW);
//                   target.setDataAndType(Uri.parse("http://maven.apache.org/maven-1.x/maven.pdf"), "application/pdf");
//                   target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                   try {
//                       startActivity(target);

                   } catch (ActivityNotFoundException e) {
                       // Instruct the user to install a PDF reader here, or something
                   }

               }catch (Exception e){
                   Log.e("Error",e.getMessage());
               }

            }
        });

    }

    public void pauseDownloading(final SubCategoryModel subCategoryModel,final int position){
        try{
            Log.e(TAG, "paiuseDownloading");
            URL url = new URL(subCategoryModel.getItem_file());
            URLConnection conection = url.openConnection();
            conection.setRequestProperty("Accept-Encoding", "identity");
            conection.wait();
        }catch (Exception e){

        }

    }

    private void publishProgress(final SubCategoryModel subCategoryModel, int position, int percent) {
        subCategoryModel.setStatus(SubCategoryModel.STATUS_DOWNLOADING);
        if (percent >= 100) {
            String imagePath = Constants.DIRECTORY_PATH +  Constants.IMAGE_FOLDER_PATH;
            String songPath = Constants.DIRECTORY_PATH +  Constants.SONG_FOLDER_PATH;
            String categoryImgPath = Constants.DIRECTORY_PATH +  Constants.CATEGORY_IMG_FOLDER_PATH;
            String videoPath = Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH;
            String PdfFile = Constants.DIRECTORY_PATH + Constants.PDF_FOLDER_PATH;
            RealmHelper realmHelper = new RealmHelper();
            SongModel downloadedModel = new SongModel();
            downloadedModel.setItem_id(subCategoryModel.getItem_id());
            downloadedModel.setItem_name(subCategoryModel.getItem_name());
            String vedioUrl=subCategoryModel.getVideo_url();

            if(vedioUrl.equals("null")){
                downloadedModel.setItem_image(imagePath + subCategoryModel.getDownload_name() + ".jpg");
                downloadedModel.setItem_file(songPath + subCategoryModel.getDownload_name() + ".mp3");
                downloadedModel.setLyrics_file(subCategoryModel.getLyrics_file());
                downloadedModel.setLyrics_filePdf(PdfFile+subCategoryModel.getDownload_name()+".pdf");
                downloadedModel.setVideo_url("null");
            }else {
                downloadedModel.setItem_image(imagePath + subCategoryModel.getDownload_name() + ".jpg");
                downloadedModel.setItem_file(subCategoryModel.getItem_file());
                String extn = Utilities.getFileExtension(subCategoryModel.getVideo_url());
                downloadedModel.setVideo_url(videoPath + subCategoryModel.getDownload_name() + "." + extn);
                downloadedModel.setLyrics_file(null);
                downloadedModel.setLyrics_filePdf(null);
            }
            downloadedModel.setItem_description(subCategoryModel.getItem_description());
            downloadedModel.setDownload_name(subCategoryModel.getDownload_name());
            downloadedModel.setCategory_id(subCategoryModel.getCategory_id());
            downloadedModel.setTypeHm(subCategoryModel.getTypeHm());
            downloadedModel.setUpdate_count(subCategoryModel.getUpdate_count());
            downloadedModel.setCategory_name(subCategoryModel.getCategory_name());
            downloadedModel.setCategory_image(categoryImgPath + subCategoryModel.getCategory_name() + ".jpg");
            realmHelper.saveDownloadedData(downloadedModel);
            Log.e(TAG, "Download success");
            //if playing from download then add new downloaded song to list related code
            StorageUtil storage = new StorageUtil(getApplicationContext());
            if (storage.loadIsPlayingFrom() != null) {
                if (storage.loadIsPlayingFrom().equalsIgnoreCase(DOWNLOADS)) {
                    ArrayList<SubCategoryModel> currentList = storage.loadAudio();
                    currentList.add(new SubCategoryModel().getCategoryFromRealm(downloadedModel));
                    storage.storeAudio(currentList);
                }
            }
            //if playing from download then add new downloaded song to list related code --ends
            handler.post(new Runnable() {

                @Override
                public void run() {
                    //Your UI code here
                    ToastUtil.showShortToastMessage(getApplicationContext(), "Download Complete.." + subCategoryModel.getDownload_name());

                }
            });

            if (!downloadQueue.isEmpty()) {
                for (SubCategoryModel model : downloadQueue) {
                    if (model.getItem_id().equals(subCategoryModel.getItem_id())) {
                        Log.e("DownloadRemove", subCategoryModel.getItem_name());
                        downloadQueue.remove(model);
                        break;
                    }
                }
            }

            subCategoryModel.setStatus(SubCategoryModel.STATUS_COMPLETE);
            Log.e("Download", "completed: " + subCategoryModel.getDownload_name());
        }
        subCategoryModel.setProgress(percent);
        sendBroadCast(subCategoryModel, position);
    }

    public static Bitmap getImage(String url) {
        try {
            URL imageUrl = new URL(url);
            URLConnection ucon = imageUrl.openConnection();

            InputStream is = ucon.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is);

            ByteArrayBuffer baf = new ByteArrayBuffer(12653504);
            int current = 0;
            while ((current = bis.read()) != -1) {
                baf.append((byte) current);
            }



            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, null, options);

            options.inSampleSize = calculateInSampleSize(options, 100, 100);
            options.inPurgeable = true;
            options.inInputShareable = true;
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;



            Bitmap bitmap = null;

            try {
                bitmap = BitmapFactory.decodeByteArray(baf.toByteArray(), 0, baf.toByteArray().length, options);
            } catch (OutOfMemoryError e) {
                Log.e("Map", "Tile Loader (241) Out Of Memory Error " + e.getLocalizedMessage());
                System.gc();
            }

            return bitmap;
        } catch (Exception e) {
            Log.d("ImageManager", "Error: " + e.toString());
        }
        return null;
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee
            // a final image with both dimensions larger than or equal to the
            // requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }


        return inSampleSize;
    }


    private void sendBroadCast(SubCategoryModel appInfo, int mPosition) {
        Intent intent = new Intent();
        intent.setAction(DownloadService.ACTION_DOWNLOAD_BROAD_CAST);
        intent.putExtra(EXTRA_POSITION, mPosition);
        intent.putExtra(EXTRA_APP_INFO, appInfo);
        sendBroadcast(intent);
    }

    private final BroadcastReceiver shutDown = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (threadPoolExecutor != null) {
                Log.e("ThreadPoolExecutor", "shutting Down ThreadPoolExecutor");
                threadPoolExecutor.shutdown();
            }
            stopSelf();
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy");
        unregisterReceiver(shutDown);
    }

    boolean contains(String id) {
        for (SubCategoryModel item : downloadQueue) {
            if (item.getItem_id().equals(id)) {
                return true;
            }
        }
        return false;
    }
}
