package com.applexinfotech.swarmadhavfoundation;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;


public class SplashActivity extends MasterActivity {
    protected final int splashTime = 2000;
    private Thread splashTread;
    private LinearLayout linearLayout1,linearLayout2,linearLayout3,linearLayout4,linerlayour5;
    private SessionManager sessionManager;
    private int STORAGE_PERMISSION_CODE = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Constants.DIRECTORY_PATH=getApplicationContext().getFilesDir().getPath();   //path when share feature should be enabled
      //  Constants.DIRECTORY_PATH=Constants.DIRECTORY_PATH+getApplicationContext().getPackageName();  //path when share feature disable and store song in internal storage
        Log.e("DIRECTORY_PATH",Constants.DIRECTORY_PATH);
        sessionManager=new SessionManager(SplashActivity.this);

        isInternet = InternetStatus.isInternetOn(this);
        try {
            if (!isReadStorageAllowed()) {
                requestStoragePermission();
            } else {
                getmethod();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    private boolean isReadStorageAllowed() {
        //Getting the permission status
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        //If permission is granted returning true
        if (result == PackageManager.PERMISSION_GRANTED )
            return true;

        //If permission is not granted returning false
        return false;
    }

    //Requesting permission
    private void requestStoragePermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.CAMERA}, STORAGE_PERMISSION_CODE);
    }

    //This method will be called when the user will tap on allow or deny
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if (requestCode == STORAGE_PERMISSION_CODE) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                getmethod();
                //Displaying a toast
            } else {
                //Displaying another toast if permission is not granted
                Toast.makeText(this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }

    public  void getmethod(){
        final SplashActivity sPlashScreen = this;
        splashTread = new Thread() {
            @Override
            public void run() {
                try {
                    synchronized (this) {
                        wait(splashTime);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally
                {
                    if (sessionManager.isLoggedIn()) {
                        Intent intent1 = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent1);
                        finish();
                    } else {
                        Intent intent2 = new Intent(SplashActivity.this, LoginActivity.class);
                        startActivity(intent2);
                        finish();

                    }

                }
            }
        };
        splashTread.start();
    }


}
