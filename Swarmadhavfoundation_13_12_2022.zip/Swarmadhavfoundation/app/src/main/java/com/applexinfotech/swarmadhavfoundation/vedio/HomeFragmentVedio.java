package com.applexinfotech.swarmadhavfoundation.vedio;


import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchviedoAudioSongListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment.hideKeyboard;


/**
 * Created by Ajay on 11-09-2015.
 */
public class HomeFragmentVedio extends MasterFragment {

    MainActivity mContext;

    RecyclerView listView_category;

    ArrayList<Object> CatArray = new ArrayList<Object>();
    // List of banner ads and MenuItems that populate the RecyclerView.

    private SeekBar mSeekBar;
    private int overflowcounter = 0;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    private int numberOfColumns=2;
    private static int ITEMS_PER_AD = 4;
    private static final int LIST_NO_AD_DELTA = 0; //when no internet
    public static ArrayList<HomeModel> realmArray=new ArrayList<>();
    private LinearLayout Linerlayourserach;
    private EditText search;
    private RecyclerView VideoCategories_search_type2Re,video_sub_rev_search_type2Re,video_song_search_type2;
    NestedScrollView nestedScrollView;
    private TextView textenofound;
    private LinearLayout relsearch,CategoryListLi,VideoCategoriesLi,VideoSubCategoriesLi,VideoSongsLi,noSongFoundView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContext = (MainActivity) getMasterActivity();

        View V = inflater.inflate(R.layout.home_fragment, container, false);
        return V;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       // mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.Video));
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeToRefresh);
        listView_category = (RecyclerView) view.findViewById(R.id.listView_category);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        Linerlayourserach= view.findViewById(R.id.Linerlayourserach);
        Linerlayourserach.setVisibility(View.VISIBLE);
        search=(EditText) view.findViewById(R.id.search);
        relsearch=view.findViewById(R.id.relsearch);
        CategoryListLi=view.findViewById(R.id.CategoryListLi);
        VideoCategoriesLi=view.findViewById(R.id.VideoCategoriesLi);
        VideoSubCategoriesLi=view.findViewById(R.id.VideoSubCategoriesLi);
        VideoSongsLi=view.findViewById(R.id.VideoSongsLi);

        VideoCategories_search_type2Re=view.findViewById(R.id.VideoCategories_search_type2);
        video_sub_rev_search_type2Re=view.findViewById(R.id.video_sub_rev_search_type2);
        video_song_search_type2=view.findViewById(R.id.video_song_search_type2);
        textenofound = view.findViewById(R.id.textenofound);
        textenofound.setText("No Video Folder Found !!");

        // vedio add Masteractivity  2  after remove master cataaryist clear
        MasterActivity.CatArrayMaster.clear();

        loadCategoryData();
        noSongFoundView = view.findViewById(R.id.noItemFound);


        if(search.getText().toString().equals("")){
            CategoryListLi.setVisibility(View.VISIBLE);
            relsearch.setVisibility(View.GONE);
            VideoCategories_search_type2Re.setAdapter(null);
            video_sub_rev_search_type2Re.setAdapter(null);
            video_song_search_type2.setAdapter(null);
            if (InternetStatus.isInternetOn(getMasterActivity())) {
                getCategory();
            }
        }


        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getCategory();
                } else {
                    getDataFromRealm();
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        VideoCategories_search_type2Re.setAdapter(null);
                        video_sub_rev_search_type2Re.setAdapter(null);
                        video_song_search_type2.setAdapter(null);
                        getCategory();
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        VideoCategories_search_type2Re.setAdapter(null);
                        video_sub_rev_search_type2Re.setAdapter(null);
                        video_song_search_type2.setAdapter(null);
                        getCategory();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.length()>0){
                        listView_category.setAdapter(null);
                        getHomeCategory(s.toString());
                    }else{
                        hideKeyboard(mContext);
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        VideoCategories_search_type2Re.setAdapter(null);
                        video_sub_rev_search_type2Re.setAdapter(null);
                        video_song_search_type2.setAdapter(null);
                        getCategory();
                    }
                }
            }

        });

        nestedScrollView=view.findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Utilities.hideKeyboard(getMasterActivity());
            }
        });


        search.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_DEL) {
                    String _text= search.getText().toString();
                    if(_text.isEmpty()){
                        if (InternetStatus.isInternetOn(getMasterActivity())) {
                            hideKeyboard(mContext);
                            CategoryListLi.setVisibility(View.VISIBLE);
                            relsearch.setVisibility(View.GONE);
                            VideoCategories_search_type2Re.setAdapter(null);
                            video_sub_rev_search_type2Re.setAdapter(null);
                            video_song_search_type2.setAdapter(null);
                            getCategory();
                        }
                    }
                    //editText is now empty
                }

                return false;
            }
        });

    }

    private void showListView(boolean flag) {
        if (flag) {
            noSongFoundView.setVisibility(View.GONE);

        } else {
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }

    private void loadCategoryData() {
        listView_category.setVisibility(View.VISIBLE);
        if (InternetStatus.isInternetOn(getMasterActivity())) {
            if (MasterActivity.CatArrayMaster.size() > 0) {
                CatArray = new ArrayList<>();
                CatArray.addAll(MasterActivity.CatArrayMaster);
             /*   if (Constants.showListBannerAd) {
                    addBannerAds();
                    loadBannerAds();
                }*/
                HomeVedioAdapter Adapter = new HomeVedioAdapter(mContext, R.layout.category_item, CatArray, listView_category);
                listView_category.setAdapter(Adapter);
                listView_category.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
                Adapter.notifyDataSetChanged();
            } else {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getCategory();
                } else {
                    ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
                }
            }
        } else {
            getDataFromRealm();
        }

    }

    private void getDataFromRealm() {
        RealmHelper realmHelper = new RealmHelper();
        CatArray = new ArrayList<>();
        realmArray = new ArrayList<>();
        realmArray = realmHelper.retrieveCategoryListVideo();
        if (realmArray != null && realmArray.size() > 0) {
            CatArray.addAll(realmArray);
            HomeVedioAdapter Adapter = new HomeVedioAdapter(mContext, R.layout.category_item, CatArray, listView_category);
            listView_category.setAdapter(Adapter);
            listView_category.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
            Adapter.notifyDataSetChanged();
        } else {
            ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
            listView_category.setVisibility(View.GONE);
        }
    }


    private void getCategory() {
        getVideoCategoryUs();
    }


    private void getVideoCategoryUs() {
        mContext.showWaitIndicator(true);
        String url = Constants.API_GET_HOME_URLvedio;

        StringRequest strReq = new StringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                try {
                    if (response != null) {
                        hideKeyboard(mContext);

                        JSONObject jObject = new JSONObject(response.toString());
                        String status = jObject.getString("response_status");

                        ArrayList<HomeModel> arrayList = new ArrayList<>();
                        CatArray = new ArrayList<>();
                        JSONArray data = jObject.getJSONArray("data");

                        Log.d("data.length()", "" + data.length());

                        for (int i = 0; i < data.length(); i++) {
                            HomeModel home = new HomeModel();

                            home.setCategory_id(data.getJSONObject(i).getString(Constants.CATEGORY_ID));
                            home.setCategory_image(data.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                            home.setCategory_name(data.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                            home.setIsSubcategoryAvailable(data.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                            home.setTypeHm("Video");
                            arrayList.add(home);
                            CatArray.add(home);
                        }
                        showListView(true);
                        MasterActivity.CatArrayMaster = arrayList;
                        HomeVedioAdapter Adapter = new HomeVedioAdapter(mContext, R.layout.category_item, CatArray, listView_category);
                        listView_category.setAdapter(Adapter);
                        listView_category.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mContext.showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });

// Adding request to request queue
        Volley.newRequestQueue(getMasterActivity()).add(strReq);
    }

    @Override
    public void onPause() {
        mContext.showWaitIndicator(false);
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    private void getHomeCategory(String catergor) {
        // String catergor=search.getText().toString();
        mContext.showWaitIndicator(false);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.CATEGORY_NAME, catergor));
        dishRequest.sendRequest(Constants.API_Video_category_search_list,
                carData, catCallback);
    }

    final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            // mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());

                    String status = jObject.optString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        CategoryListLi.setVisibility(View.GONE);
                        relsearch.setVisibility(View.VISIBLE);
                        JSONObject data = jObject.getJSONObject("data");

                        ArrayList<SubCategoryModel> video_listItem = new ArrayList<>();
                        JSONArray video_list= data.getJSONArray("video_list");

                        if(!(video_list.length()==0)) {
                            for (int j = 0; j < video_list.length(); j++) {
                                VideoSongsLi.setVisibility(View.VISIBLE);
                                SubCategoryModel categoryModel1 = new SubCategoryModel();
                                categoryModel1.setItem_id(video_list.getJSONObject(j).getString("video_id"));
                                categoryModel1.setItem_name(video_list.getJSONObject(j).getString("video_title"));
                                categoryModel1.setItem_description(video_list.getJSONObject(j).getString("video_description"));
                                categoryModel1.setItem_file(video_list.getJSONObject(j).getString("video_file"));
                                categoryModel1.setItem_image(video_list.getJSONObject(j).getString("front_cover"));
                                categoryModel1.setDownload_name(video_list.getJSONObject(j).getString("video_title"));
                                categoryModel1.setVideo_url(video_list.getJSONObject(j).optString("video_file"));
                                categoryModel1.setCategory_id(video_list.getJSONObject(j).getString("video_category_id"));
                                video_listItem.add(categoryModel1);
                            }

                            SearchviedoAudioSongListAdapter Adaptervi = new SearchviedoAudioSongListAdapter(mContext, video_listItem, video_song_search_type2);
                            video_song_search_type2.setAdapter(Adaptervi);
                            video_song_search_type2.setLayoutManager(new GridLayoutManager(getActivity(), 3));
                        }else {
                            VideoSongsLi.setVisibility(View.GONE);
                        }



                        ArrayList<Object> video_CatArray = new ArrayList<>();
                        ArrayList<HomeModel> video_categoryarry = new ArrayList<>();
                        JSONArray videoCategoryList = data.getJSONArray("video_category_list");
                        if(!(videoCategoryList.length()==0)) {

                            VideoCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < videoCategoryList.length(); i++) {
                                HomeModel home = new HomeModel();
                                home.setCategory_id(videoCategoryList.getJSONObject(i).getString("video_category_id"));
                                home.setCategory_image(videoCategoryList.getJSONObject(i).getString("video_category_image"));
                                home.setCategory_name(videoCategoryList.getJSONObject(i).getString("video_category_name"));
                                home.setIsSubcategoryAvailable(videoCategoryList.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                                home.setTypeHm("Video");
                                video_categoryarry.add(home);
                                video_CatArray.add(home);
                            }

                            SearchVedioMainAdapter Adapter1 = new SearchVedioMainAdapter(mContext, R.layout.search_adapter_layout, video_CatArray, VideoCategories_search_type2Re);
                            VideoCategories_search_type2Re.setAdapter(Adapter1);
                            VideoCategories_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            VideoCategoriesLi.setVisibility(View.GONE);
                        }

                        ArrayList<Object> videosubcategoryarry = new ArrayList<>();
                        ArrayList<SubHomeCategory> videosubcategorylist = new ArrayList<>();
                        JSONArray videosublist = data.getJSONArray("video_subcategory_list");
                        if(!(videosublist.length()==0)) {
                            VideoSubCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < videosublist.length(); i++) {
                                SubHomeCategory home = new SubHomeCategory();
                                home.setAudio_subcategory_id(videosublist.getJSONObject(i).getString("video_subcategory_id"));
                                home.setAudio_subcategory_name(videosublist.getJSONObject(i).getString("video_subcategory_name"));
                                home.setAudio_subcategory_image(videosublist.getJSONObject(i).getString("video_subcategory_image"));
                                home.setCategory_id(videosublist.getJSONObject(i).getString("video_category_id"));
                                home.setCategory_name(videosublist.getJSONObject(i).getString("video_category_name"));
                                home.setTypeHm("Video");
                                videosubcategorylist.add(home);
                                videosubcategoryarry.add(home);
                            }

                            SearchVideoSubCategoyAdapter Adapter2 = new SearchVideoSubCategoyAdapter(mContext, R.layout.search_adapter_layout, videosubcategoryarry, video_sub_rev_search_type2Re);
                            video_sub_rev_search_type2Re.setAdapter(Adapter2);
                            video_sub_rev_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            VideoSubCategoriesLi.setVisibility(View.GONE);
                        }

                        showListView(true);

                    } else {
                        //noSongFoundTv.setText("No Data");
                        showListView(false);
                    }
                } else {
                    //showListView(false);
                }

            } catch (Exception e) {
                //mContext.showWaitIndicator(false);
                Log.e("Exception", e.toString());
                e.printStackTrace();

            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            //mContext.showWaitIndicator(false);
        }
    };


}
