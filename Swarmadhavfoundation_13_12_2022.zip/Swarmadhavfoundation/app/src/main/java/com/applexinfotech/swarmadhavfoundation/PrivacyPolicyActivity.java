package com.applexinfotech.swarmadhavfoundation;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class PrivacyPolicyActivity extends MasterActivity {
    private JustifyTextView txtPrivacyPolicyContent;
    Activity PrivacyPolicy=this;
    private ProgressDialog progressDialog;
    private ImageButton imgBAck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);

        setTitle(getString(R.string.privacy_policy));

        iniUI();
        onClick();

        isInternet= InternetStatus.isInternetOn(PrivacyPolicy);
        if (isInternet) {
            getPrivacyPolicy();
        } else {
            ToastUtil.showLongToastMessage(PrivacyPolicy, getString(R.string.no_internet_connection_found));
        }
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        return;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    public void iniUI(){
        txtPrivacyPolicyContent=(JustifyTextView) findViewById(R.id.txtPrivacyPolicyContent);
        imgBAck=(ImageButton)findViewById(R.id.drawer_back);
    }
    public void onClick(){
        imgBAck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(PrivacyPolicy,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    public void getPrivacyPolicy(){
        showWaitIndicator(true);
        String url= Constants.API_Privacy_Policy;
        StringRequest strReq=new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                showWaitIndicator(false);
                try {
                    if (response != null){
                        Log.d("PRIVACY_POLICY_API",""+response.toString());
                        //Toast.makeText(PrivacyPolicy,url,Toast.LENGTH_LONG).show();
                        JSONObject jObject=new JSONObject(response.toString());
                        String status=jObject.getString("response_status");
                        if (status.equalsIgnoreCase("1")){
                            JSONArray data=jObject.getJSONArray("data");
                            String privacy_policy=data.getJSONObject(0).getString("privacy_policy");
                            txtPrivacyPolicyContent.setText(privacy_policy);


                        }else {
                            showWaitIndicator(false);
                        }
                    }

                }catch (Exception e){
                    e.printStackTrace();
                    showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                showWaitIndicator(false);
            }
        });
        Volley.newRequestQueue(PrivacyPolicy).add(strReq);

    }


}