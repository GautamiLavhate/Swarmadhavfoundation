package com.applexinfotech.swarmadhavfoundation.fragment;


import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.HomeAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchAudioMainAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchSubcategoryAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchviedoAudioSongListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.formats.UnifiedNativeAd;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by JD(jikadrajaydeep@gmail.com) on 11-09-2015.
 */
public class HomeFragment extends MasterFragment {

    private MainActivity mContext;

    private RecyclerView listView_category, AudioCategories_search_typeRe,AudioSub_search_type2Re,AudioSongs_search_type2Re;
    HomeAdapter Adapter;

    private ArrayList<Object> CatArray = new ArrayList<>();
    // List of banner ads and MenuItems that populate the RecyclerView.

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    //private static int  = 6;
    private static final int LIST_NO_AD_DELTA = 0; //when no internet
    private static final String AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"; //test id
    public static ArrayList<HomeModel> realmArray;
    private ArrayList<Integer> addPositionList = new ArrayList<>();
    // The AdLoader used to load ads.
    private AdLoader adLoader;
    private int numberOfColumns=2;
    // List of native ads that have been successfully loaded.
    private List<UnifiedNativeAd> mNativeAds = new ArrayList<>();
    private LinearLayout Linerlayourserach;
    private EditText search;
    NestedScrollView nestedScrollView;
    private LinearLayout relsearch,CategoryListLi,AudioCategoriesLi,AudioSubCategoriesli,AudioSongsLi,noSongFoundView;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext.showWaitIndicator(false);


        /*if (!Constants.showListBannerAd) {
            ITEMS_PER_AD = 0;
        }*/
        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.Audio));
        Linerlayourserach= view.findViewById(R.id.Linerlayourserach);
        listView_category = view.findViewById(R.id.listView_category);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());

        AudioCategoriesLi=view.findViewById(R.id.AudioCategoriesLi);
        AudioSubCategoriesli=view.findViewById(R.id.AudioSubCategoriesli);
        AudioSongsLi=view.findViewById(R.id.AudioSongsLi);
        noSongFoundView = view.findViewById(R.id.noItemFound);

        AudioCategories_search_typeRe=view.findViewById(R.id.AudioCategories_search_type);
        AudioSub_search_type2Re=view.findViewById(R.id.AudioSub_search_type2);
        AudioSongs_search_type2Re=view.findViewById(R.id.AudioSongs_search_type2);

        relsearch=view.findViewById(R.id.relsearch);
        CategoryListLi=view.findViewById(R.id.CategoryListLi);

        Linerlayourserach.setVisibility(View.VISIBLE);

        loadCategoryData();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);

                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getCategory();
                } else {
                    loadDataFromRealm();
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        search=(EditText) view.findViewById(R.id.search);

        if(search.getText().toString().equals("")){
            CategoryListLi.setVisibility(View.VISIBLE);
            relsearch.setVisibility(View.GONE);
            showListView(true);
            AudioCategories_search_typeRe.setAdapter(null);
            AudioSub_search_type2Re.setAdapter(null);
            AudioSongs_search_type2Re.setAdapter(null);
            if (InternetStatus.isInternetOn(getMasterActivity())) {
                getCategory();
            }
        }

        search.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_DEL) {
                    String _text= search.getText().toString();
                    if(_text.isEmpty()){
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        showListView(true);
                        AudioCategories_search_typeRe.setAdapter(null);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        if (InternetStatus.isInternetOn(getMasterActivity())) {
                            getCategory();
                        }
                    }
                    //editText is now empty
                }

                        return false;
        }
    });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        showListView(true);
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        AudioCategories_search_typeRe.setAdapter(null);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        getCategory();
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        showListView(true);
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        AudioCategories_search_typeRe.setAdapter(null);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        getCategory();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.length() > 0){
                        listView_category.setAdapter(null);
                        getHomeCategory(s.toString());
                    }else{
                        showListView(true);
                        hideKeyboard(mContext);
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        AudioCategories_search_typeRe.setAdapter(null);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        getCategory();
                    }
                }
            }

        });

        nestedScrollView=view.findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Utilities.hideKeyboard(getMasterActivity());
            }
        });

    }

    private void loadCategoryData() {
        listView_category.setVisibility(View.VISIBLE);
        if (InternetStatus.isInternetOn(getMasterActivity())) {
            if (!MasterActivity.categoryListWithAd.isEmpty()) {
                CatArray = new ArrayList<>();
                CatArray.addAll(MasterActivity.categoryListWithAd);
                setHomeAdapter();
            } else {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getCategory();
                } else {
                    ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
                }
            }
        } else {
            loadDataFromRealm();

        }

    }

    private void loadDataFromRealm() {
        RealmHelper realmHelper = new RealmHelper();
        CatArray = new ArrayList<>();
        realmArray = new ArrayList<>();
        realmArray = realmHelper.retrieveCategoryListAudio();
        if (realmArray != null && realmArray.size() > 0) {
            CatArray.addAll(realmArray);
            setHomeAdapter();
        } else {
            mContext.showWaitIndicator(false);
            ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
            listView_category.setVisibility(View.GONE);
        }
    }

    private void getCategory() {
        getAudioCategoryUs();
    }

    private void getAudioCategoryUs() {
        mContext.showWaitIndicator(true);
        String url = Constants.API_audio_category_list;

        StringRequest strReq = new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                try {
                    if (response != null) {
                        hideKeyboard(mContext);
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);

                        JSONObject jObject = new JSONObject(response.toString());
                        String status = jObject.getString("response_status");

                        ArrayList<HomeModel> arrayList = new ArrayList<>();
                        CatArray = new ArrayList<>();
                        JSONArray data = jObject.getJSONArray("data");

                        Log.d("data.length()", "" + data.length());

                        for (int i = 0; i < data.length(); i++) {
                            HomeModel home = new HomeModel();

                            home.setCategory_id(data.getJSONObject(i).getString(Constants.CATEGORY_ID));
                            home.setCategory_image(data.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                            home.setCategory_name(data.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                            home.setIsSubcategoryAvailable(data.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                            home.setTypeHm("Audio");
                            arrayList.add(home);
                            CatArray.add(home);
                        }

                        MasterActivity.CatArrayMaster = arrayList;
                        MasterActivity.categoryListWithAd=new ArrayList<>();
                        MasterActivity.categoryListWithAd.addAll(CatArray);
                        setHomeAdapter();
                        showListView(true);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mContext.showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });

// Adding request to request queue
        Volley.newRequestQueue(getMasterActivity()).add(strReq);
    }
    private void setHomeAdapter() {
        mContext.showWaitIndicator(false);
         Adapter = new HomeAdapter(mContext, R.layout.category_item, CatArray, listView_category);
        listView_category.setAdapter(Adapter);
        listView_category.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
        listView_category.post(new Runnable() {
            @Override
            public void run() {
                Adapter.notifyDataSetChanged();
            }
        });
    }

    private void getHomeCategory(String catergor) {
       // String catergor=search.getText().toString();
        mContext.showWaitIndicator(false);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.CATEGORY_NAME, catergor));
        dishRequest.sendRequest(Constants.API_Audio_category_search_list,
                carData, catCallback);
    }

     private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    showListView(true);
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.optString("response_status");
                    CategoryListLi.setVisibility(View.GONE);
                    relsearch.setVisibility(View.VISIBLE);
                    if (status.equalsIgnoreCase("1")) {
                        JSONObject data = jObject.getJSONObject("data");
                        JSONArray audio_list= data.getJSONArray("audio_list");
                        ArrayList<SubCategoryModel> audio_listItem = new ArrayList<>();
                        Log.d("data.length()", "" + audio_list.length());
                        if(!(audio_list.length()==0)) {
                            for (int i = 0; i < audio_list.length(); i++) {
                                AudioSongsLi.setVisibility(View.VISIBLE);
                                SubCategoryModel categoryModel = new SubCategoryModel();
                                categoryModel.setItem_id(audio_list.getJSONObject(i).getString("audio_id")+"audio_id");
                                categoryModel.setItem_name(audio_list.getJSONObject(i).getString("audio_title"));
                                categoryModel.setItem_description(audio_list.getJSONObject(i).getString("audio_description"));
                                categoryModel.setItem_file(audio_list.getJSONObject(i).getString("audio_file"));
                                categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                                categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("audio_title"));
                                categoryModel.setLyrics_file(audio_list.getJSONObject(i).getString("audio_lyrics"));
                                categoryModel.setLyrics_filePdf(audio_list.getJSONObject(i).getString("pdf_file"));
                                categoryModel.setCategory_id(audio_list.getJSONObject(i).getString("audio_category_id"));
                                categoryModel.setVideo_url("null");
                                audio_listItem.add(categoryModel);
                            }
                            SearchviedoAudioSongListAdapter audio_listItemAdaptervi = new SearchviedoAudioSongListAdapter(mContext, audio_listItem, AudioSongs_search_type2Re);
                            AudioSongs_search_type2Re.setAdapter(audio_listItemAdaptervi);
                            AudioSongs_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 3));
                        }else {
                            AudioSongsLi.setVisibility(View.GONE);
                        }


                        ArrayList<Object> CatArray = new ArrayList<>();
                        ArrayList<HomeModel> audio_category_list = new ArrayList<>();
                        JSONArray audioCatdata = data.getJSONArray("audio_category_list");
                        if(!(audioCatdata.length()==0)) {
                            AudioCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < audioCatdata.length(); i++) {
                                HomeModel home = new HomeModel();
                                home.setCategory_id(audioCatdata.getJSONObject(i).getString(Constants.CATEGORY_ID));
                                home.setCategory_image(audioCatdata.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                                home.setCategory_name(audioCatdata.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                                home.setIsSubcategoryAvailable(audioCatdata.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                                home.setTypeHm("Audio");
                                audio_category_list.add(home);
                                CatArray.add(home);
                            }

                            SearchAudioMainAdapter Adapter = new SearchAudioMainAdapter(mContext, R.layout.search_adapter_layout, CatArray, AudioCategories_search_typeRe);
                            AudioCategories_search_typeRe.setAdapter(Adapter);
                            AudioCategories_search_typeRe.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            AudioCategoriesLi.setVisibility(View.GONE);
                        }




                        ArrayList<Object> audio_subCatArray = new ArrayList<>();
                        ArrayList<SubHomeCategory> audio_subcategory = new ArrayList<>();
                        JSONArray  audiosubdata = data.getJSONArray("audio_subcategory_list");
                        if(!(audiosubdata.length()==0)) {
                            AudioSubCategoriesli.setVisibility(View.VISIBLE);
                            for (int i = 0; i < audiosubdata.length(); i++) {
                                SubHomeCategory home = new SubHomeCategory();
                                home.setAudio_subcategory_id(audiosubdata.getJSONObject(i).getString("audio_subcategory_id"));
                                home.setAudio_subcategory_name(audiosubdata.getJSONObject(i).getString("audio_subcategory_name"));
                                home.setAudio_subcategory_image(audiosubdata.getJSONObject(i).getString("audio_subcategory_image"));
                                home.setCategory_id(audiosubdata.getJSONObject(i).getString("category_id"));
                                home.setCategory_name(audiosubdata.getJSONObject(i).getString("category_name"));
                                home.setTypeHm("Audio");
                                audio_subcategory.add(home);
                                audio_subCatArray.add(home);
                            }

                            SearchSubcategoryAdapter searchAudioMainAdapter = new SearchSubcategoryAdapter(mContext, R.layout.search_adapter_layout, audio_subCatArray, AudioSub_search_type2Re);
                            AudioSub_search_type2Re.setAdapter(searchAudioMainAdapter);
                            AudioSub_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            AudioSubCategoriesli.setVisibility(View.GONE);
                        }



                }else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                        AudioSubCategoriesli.setVisibility(View.GONE);
                        AudioSongsLi.setVisibility(View.GONE);
                        AudioCategoriesLi.setVisibility(View.GONE);
                    }
                } else {
                    mContext.showWaitIndicator(false);
                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        if(search.getText().toString().equals("")){
            CategoryListLi.setVisibility(View.VISIBLE);
            relsearch.setVisibility(View.GONE);
            AudioCategories_search_typeRe.setAdapter(null);
            AudioSub_search_type2Re.setAdapter(null);
            AudioSongs_search_type2Re.setAdapter(null);
            if (InternetStatus.isInternetOn(getMasterActivity())) {
                getCategory();
            }
        }

    }

    private void showListView(boolean flag) {
        if (flag) {
            noSongFoundView.setVisibility(View.GONE);

        } else {
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

}
