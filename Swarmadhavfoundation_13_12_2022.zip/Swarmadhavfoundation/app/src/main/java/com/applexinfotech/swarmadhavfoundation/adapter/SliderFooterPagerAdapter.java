package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.model.FooterSliderUtils;
import com.applexinfotech.swarmadhavfoundation.model.SliderUtils;
import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;

public class SliderFooterPagerAdapter extends SliderViewAdapter<SliderFooterPagerAdapter.SliderAdapterViewHolder> {
    private ArrayList<FooterSliderUtils> footerSliderUtils;
    private Context context;
    private LayoutInflater layoutInflater;

    public SliderFooterPagerAdapter(Context context, ArrayList<FooterSliderUtils> footerSliderUtils){
        this.context=context;
        this.footerSliderUtils =footerSliderUtils;
    }
    @Override
    public int getItemPosition(Object object) {
        return super.getItemPosition(object);
    }

    @Override
    public SliderAdapterViewHolder onCreateViewHolder(ViewGroup parent) {
        View inflate= LayoutInflater.from(parent.getContext()).inflate(R.layout.footer_slider_layout,null);
        return new SliderAdapterViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterViewHolder viewHolder, int position) {
        final FooterSliderUtils footerSliderItem= footerSliderUtils.get(position);

        Glide.with(viewHolder.itemView)
                .load(footerSliderItem.getFootersliderImageUrl())

                .error(R.drawable.new_launching_logo)
                //.fitCenter()
                .into(viewHolder.imageViewBackground);
    }

    @Override
    public int getCount() {
        return footerSliderUtils.size();
    }
    static class SliderAdapterViewHolder extends SliderViewAdapter.ViewHolder {
        View itemView;

        ImageView imageViewBackground;

        public SliderAdapterViewHolder(View itemView) {
            super(itemView);
            imageViewBackground=itemView.findViewById(R.id.myimagefooter);
            this.itemView=itemView;
        }
    }
}
