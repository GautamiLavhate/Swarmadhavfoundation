package com.applexinfotech.swarmadhavfoundation.fragment;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.PlaylistVedioFragment;
import com.applexinfotech.swarmadhavfoundation.BuildConfig;
import com.applexinfotech.swarmadhavfoundation.CustomVolleyRequeat;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.CategoryRecyclerAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.RecentRecyclerAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SliderFooterPagerAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SliderPagerAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.ViewPagerAdapterBottomImage;
import com.applexinfotech.swarmadhavfoundation.adapter.ViewPagerAdapterImage;
import com.applexinfotech.swarmadhavfoundation.common.ui.CustomSwipeToRefresh;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.downloadvedio.DownloadsMainVedioFragment;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.MusicStateListener;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.CategoryResponse;
import com.applexinfotech.swarmadhavfoundation.model.FooterSliderUtils;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SliderUtils;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.CategoryRecyclervedioAdapter;
import com.applexinfotech.swarmadhavfoundation.vedio.HomeFragmentVedio;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;


import com.smarteist.autoimageslider.SliderView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_ASSETS;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_RECENTLY_PLAYED;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.IS_FROM;


public class DashBoardFragment extends MasterFragment implements View.OnClickListener, OnItemClickListener<SubCategoryModel>, DownloadListener, MusicStateListener {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam2, mParam1;
    private MainActivity mContext;

    RecyclerView listView_category;

    private ArrayList<HomeModel> catArraySubList = new ArrayList<>();
    private ArrayList<SubCategoryModel> recentlyPlayedSubList = new ArrayList<>();
    private ArrayList<SubCategoryModel> mostPlayedSubList = new ArrayList<>();
    private ArrayList<SubCategoryModel> mostDownloadedSubList = new ArrayList<>();

    private ArrayList<HomeModel> catArraySubListvedio = new ArrayList<>();
    // List of banner ads and MenuItems that populate the RecyclerView.
    private int overflowcounter = 0;

    private View rootView;
    private CustomSwipeToRefresh mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager, linearLayoutManager2, linearLayoutManager3, linearLayoutManager4,linearLayoutManager5,linearLayoutManagervideo;
    private static ArrayList<HomeModel> realmArray,realmArray1;
    private CardView cardCategory, cardRecentlyPlayed, cardMostPlayed, cardMostDownloaded, cardAssetSongs,card_categoryVedio;
    private Button  btnAllRecentPlayed, btnAllMostPlayed, btnAllMostDownloaded, btnAllAssetSongs;
    private TextView btnAllCategory,btn_view_all_categoryVedio;
    private RecyclerView categoryRecycler, recentPlayedRecycler, mostPlayedRecycler, mostDownloadedRecycler, assetSongsRecycler,category_recyclerVedio;
    int visibleCardCounts = 0;
    private View dashboardAdView;
    private boolean isCategoryCardVisible;
    private boolean isRecentCardVisible;
    private boolean isMostPlayedCardVisible;
    private boolean isMostDownloadedCardVisible;
    private boolean isCategoryCardVisiblevedio;
    private RecentRecyclerAdapter recentRecyclerAdapter, mostDownloadedRecyclerAdapter, mostPlayedRecyclerAdapter,assetSongRecyclerAdapter;

    private UnifiedNativeAdView adView;
    private AdLoader adLoader;

    SharedPreferences settingsShrepref;

    // Editor for Shared preferences
    SharedPreferences.Editor editor;
    // Sharedpref file name
    private static final String PREF_NAME = "MyPrefFileShred";

    // User name (make variable public to access from outside)
    public static final String KEY_TODAY_DATE_ANDTIME = "TimeToday";
    String TodayDate_String;

    public static  String Cardlisttype="Audio";

    // creating object of ViewPager
    ViewPager viewPager,viewPagerBottomSlider;
    LinearLayout sliderDotsPanel;
    private int dotscount;
    private ImageView[] dots;

    RequestQueue rq;
    ArrayList<SliderUtils> sliderImg;
    ArrayList<FooterSliderUtils> footerSliderImg;
    ViewPagerAdapterImage viewPagerAdapter;
    SliderPagerAdapter sliderPagerAdapter;
    SliderFooterPagerAdapter sliderFooterPagerAdapter;
    ViewPagerAdapterBottomImage viewPagerAdapterBottomImage;
    DashBoardFragment context;

    SliderUtils sliderUtils;
    FooterSliderUtils footerSliderUtils;

    //Slider View for AutoSliding Images
//    SliderView sliderView;
//    ArrayList<NewSliderData> sliderUtilsArrayList;
//    SliderPagerAdapter sliderPagerAdapter;
        SessionManager sessionManager;

    //Demo
    ImageView imgDemo;

    //BottomNavigation
    BottomNavigationView bottomNavigationView;

    SliderView sliderView,sliderViewBottom;

    //ImageView for Footer
    ImageView imgFooter;

    //Bottom Sheet Dialog
    BottomSheetDialog bottomSheetDialog,bottomSheetDialogVideo;
    //Linear Layout of bottomsheet
    LinearLayout linearLayoutAllCategories,linearLayoutPlaylist,linearLayoutDownloads,ll,
    linearLayoutAllCategoriesVideo,linearLayoutPlaylistVideo,linearLayoutDownloadsVideo;

    TextView txtVideoCategories;

    //SliderLayout sliderLayout;

    public DashBoardFragment() {
        // Required empty public constructor
    }

    public static DashBoardFragment newInstance(String param1, String param2) {
        DashBoardFragment fragment = new DashBoardFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dash_board, container, false);
        mContext = (MainActivity) getMasterActivity();
        ((MainActivity) getActivity()).setMusicStateListenerListener(this);
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        context=this;
        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
     //   mContext.hideDrawer();
        mContext.hideDrawerBack();
        mContext.showNotification();
        mContext.setTitle(getString(R.string.Home));

        cardCategory = view.findViewById(R.id.card_category);
        cardRecentlyPlayed = view.findViewById(R.id.card_recently_played);
        cardMostPlayed = view.findViewById(R.id.card_most_played);
        cardMostDownloaded = view.findViewById(R.id.card_most_downloaded);
        btnAllCategory = view.findViewById(R.id.btn_view_all_category);
        //txtViewAllAudio=view.findViewById(R.id.txtViewAllAudio);
        btnAllRecentPlayed = view.findViewById(R.id.btn_view_all_recent);
        btnAllMostPlayed = view.findViewById(R.id.btn_view_most_played);
        btnAllMostDownloaded = view.findViewById(R.id.btn_view_most_downloaded);
        categoryRecycler = view.findViewById(R.id.category_recycler);
        recentPlayedRecycler = view.findViewById(R.id.recently_played_recycler);
        mostPlayedRecycler = view.findViewById(R.id.most_played_recycler);
        mostDownloadedRecycler = view.findViewById(R.id.most_downloaded_recycler);
       // dashboardAdView = view.findViewById(R.id.dashboard_adView);

        //BottomNavigation
        bottomNavigationView=view.findViewById(R.id.bottom_navigation_view);

        //Footer imageview
        //imgFooter=view.findViewById(R.id.img_bottom_image);
//        sliderView.addView(sliderView);
        cardAssetSongs = view.findViewById(R.id.card_assets);
        btnAllAssetSongs = view.findViewById(R.id.btn_view_all_assets);
        assetSongsRecycler = view.findViewById(R.id.assets_recycler);
        sessionManager=new SessionManager(getMasterActivity());
        String user_id=sessionManager.getKEY_Userid();
        //Toast.makeText(mContext,user_id,Toast.LENGTH_LONG).show();
        //vedio merge layout
        card_categoryVedio= view.findViewById(R.id.card_categoryVedio);
        btn_view_all_categoryVedio= view.findViewById(R.id.btn_view_all_categoryVedio);
        category_recyclerVedio= view.findViewById(R.id.category_recyclerVedio);
        btnAllCategory.setOnClickListener(this);
        //txtViewAllAudio.setOnClickListener(this);
        btnAllRecentPlayed.setOnClickListener(this);
        btnAllMostPlayed.setOnClickListener(this);
        btnAllMostDownloaded.setOnClickListener(this);
        btnAllAssetSongs.setOnClickListener(this);
        btn_view_all_categoryVedio.setOnClickListener(this);

        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        linearLayoutManager2 = new LinearLayoutManager(mContext);
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
        linearLayoutManager3 = new LinearLayoutManager(mContext);
        linearLayoutManager3.setOrientation(LinearLayoutManager.HORIZONTAL);
        linearLayoutManager4 = new LinearLayoutManager(mContext);
        linearLayoutManager4.setOrientation(LinearLayoutManager.HORIZONTAL);
        linearLayoutManager5 = new LinearLayoutManager(mContext);
        linearLayoutManager5.setOrientation(LinearLayoutManager.HORIZONTAL);

        linearLayoutManagervideo= new LinearLayoutManager(mContext);
        linearLayoutManagervideo.setOrientation(LinearLayoutManager.HORIZONTAL);

        rq= CustomVolleyRequeat.getInstance(getContext()).getRequestQueue();
        sliderImg=new ArrayList<>();
        viewPager=view.findViewById(R.id.viewPager);
        footerSliderImg=new ArrayList<>();
        viewPagerBottomSlider=view.findViewById(R.id.viewPager_bottom_image);
        //viewPager.setAdapter(new ViewPagerAdapterImage(getContext()));

        sliderView=view.findViewById(R.id.imageSlider);
        //sliderView.setIndicatorAnimation(IndicatorAnimationType.FILL);
        //GetImage();
        GetImageSlider();
        sliderViewBottom=view.findViewById(R.id.imageSliderBottom);
        //sliderViewBottom.setIndicatorAnimation(IndicatorAnimationType.FILL);
        //GetFooterSlider();
        GetFooterImageSlider();
        imgDemo=view.findViewById(R.id.imgdemo);


        bottomSheetDialog=new BottomSheetDialog(mContext);
        View sheetView=getLayoutInflater().inflate(R.layout.bottom_sheet_audio,null);
        bottomSheetDialog.setContentView(sheetView);

        linearLayoutAllCategories=(LinearLayout)sheetView.findViewById(R.id.linearLayoutAllCategories);
        linearLayoutPlaylist=(LinearLayout)sheetView.findViewById(R.id.linearLayoutPlatlistAudio);
        linearLayoutDownloads=(LinearLayout)sheetView.findViewById(R.id.linearLayoutDownloadAudio);
        ll=(LinearLayout)sheetView.findViewById(R.id.ll);

        bottomSheetDialogVideo=new BottomSheetDialog(mContext);
        View sheetViewVideo=getLayoutInflater().inflate(R.layout.bottom_sheet_video,null);
        bottomSheetDialogVideo.setContentView(sheetViewVideo);

        linearLayoutAllCategoriesVideo=(LinearLayout)sheetViewVideo.findViewById(R.id.linearLayoutAllCategoriesVideo);
        linearLayoutPlaylistVideo=(LinearLayout)sheetViewVideo.findViewById(R.id.linearLayoutPlatlistVideo);
        linearLayoutDownloadsVideo=(LinearLayout)sheetViewVideo.findViewById(R.id.linearLayoutDownloadVideo);

        txtVideoCategories =(TextView)sheetViewVideo.findViewById(R.id.txtVideoCategories);
        //sliderLayout=view.findViewById(R.id.imageSlider);

        linearLayoutAllCategories.setOnClickListener(new View.OnClickListener() {
        @Override
            public void onClick(View v) {

            HomeFragment homeFragment=new HomeFragment();
            mContext.ReplaceFragment(homeFragment);
            bottomSheetDialog.dismiss();

            }
        });
        linearLayoutPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PlaylistFragment playlistFragment=new PlaylistFragment();
                mContext.ReplaceFragment(playlistFragment);
                bottomSheetDialog.dismiss();
                //bottomNavigationView.setVisibility(View.VISIBLE);
            }
        });
        linearLayoutDownloads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadsMainFragment downloadsMainFragment=new DownloadsMainFragment();
                mContext.ReplaceFragment(downloadsMainFragment);
                bottomSheetDialog.dismiss();
            }
        });

        linearLayoutAllCategoriesVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtVideoCategories.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                HomeFragmentVedio homeFragmentVedio=new HomeFragmentVedio();
                mContext.ReplaceFragment(homeFragmentVedio);
                bottomSheetDialogVideo.dismiss();
            }
        });
        linearLayoutPlaylistVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlaylistVedioFragment playlistVedioFragment=new PlaylistVedioFragment();
                mContext.ReplaceFragment(playlistVedioFragment);
                bottomSheetDialogVideo.dismiss();
            }
        });
        linearLayoutDownloadsVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadsMainVedioFragment downloadsMainVedioFragment=new DownloadsMainVedioFragment();
                mContext.ReplaceFragment(downloadsMainVedioFragment);
                bottomSheetDialogVideo.dismiss();
            }
        });
        //Initialization of slider view
//        sliderUtilsArrayList=new ArrayList<>();
//        sliderView=view.findViewById(R.id.slider);
       // GetNewImage();


        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);

                    if (InternetStatus.isInternetOn(getMasterActivity())) {
                        getHomeDataFromServer();
                    } else {
                        //dashboardAdView.setVisibility(View.GONE);
                        loadDataFromList();
                    }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        mContext.action_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SearchFragment searchFragment = new SearchFragment();
                mContext.ReplaceFragment(searchFragment);
            }
        });
        mContext.action_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Notification notification=new Notification();
                mContext.ReplaceFragment(notification);
            }
        });
        getHomeData();
        //GetFooterSlider();
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId()==R.id.bottom_home){
                    Toast.makeText(mContext,"Home Fragment",Toast.LENGTH_LONG).show();
                    Fragment homeFragment=new DashBoardFragment();
                    mContext.ReplaceFragment(homeFragment);
                }
                if (item.getItemId()==R.id.bottom_settings){
                    Fragment settingsFragment=new Settings();
                    mContext.ReplaceFragment(settingsFragment);
                }
                if (item.getItemId()==R.id.bottom_audio){
                    bottomSheetDialog.show();
                }
                if (item.getItemId()==R.id.bottom_video){
                    bottomSheetDialogVideo.show();
                }
                return false;
            }
        });
    }

    private void getHomeData() {
        if (InternetStatus.isInternetOn(getMasterActivity())) {
            if (MasterActivity.catArrayList.size() > 0 && MasterActivity.catArrayListvedio.size() > 0) {
                loadDataFromList();
            } else {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getHomeDataFromServer();
                } else {
                    ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
                }
            }
        } else {
            loadDataFromList();
        }
    }

    private void loadDataFromList() {
        catArraySubList = new ArrayList<>();
        mostPlayedSubList = new ArrayList<>();
        mostDownloadedSubList = new ArrayList<>();
        catArraySubListvedio= new ArrayList<>();
        if (InternetStatus.isInternetOn(mContext)) {
            catArraySubList.addAll(MasterActivity.catArrayList);
            if (catArraySubList.size() > 10) {
                List<HomeModel> temp = catArraySubList.subList(0, 10);
                catArraySubList = new ArrayList<>();
                catArraySubList.addAll(temp);
            }
            //vedio

            catArraySubListvedio.addAll(MasterActivity.catArrayListvedio);
            if (catArraySubListvedio.size() > 10) {
                List<HomeModel> temp = catArraySubListvedio.subList(0, 10);
                catArraySubListvedio = new ArrayList<>();
                catArraySubListvedio.addAll(temp);
            }
        } else {
            getDataFromRealm();
        }

        if(Constants.enableAssetSongs){
            loadAssetSongList();
        }else{
            cardAssetSongs.setVisibility(View.GONE);
        }
       // loadRecentlyPlayedList();
        loadDashBoardData();
    }

    private void loadAssetSongList() {
        if (MasterActivity.assetsSongList.isEmpty()) {
            MasterActivity.assetsSongList =  readJSONFromAsset();
        }
        if (MasterActivity.assetsSongList.isEmpty()) {
            cardAssetSongs.setVisibility(View.GONE);
        } else {
            cardAssetSongs.setVisibility(View.VISIBLE);
            //load recently played data
            assetSongRecyclerAdapter = new RecentRecyclerAdapter(mContext, MasterActivity.assetsSongList, assetSongsRecycler);
            assetSongsRecycler.setAdapter(assetSongRecyclerAdapter);
            assetSongRecyclerAdapter.setFromAssets(true);
            assetSongRecyclerAdapter.setOnItemClickListener(DashBoardFragment.this);
            assetSongsRecycler.setLayoutManager(linearLayoutManager5);
        }
    }


    public ArrayList<SubCategoryModel> readJSONFromAsset() {
        ArrayList<SubCategoryModel> list;
        try {
            InputStream is = mContext.getAssets().open("appSongs.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");
            CategoryResponse obj = new Gson().fromJson(json, CategoryResponse.class);
            list = obj.getAssetSongs();
        } catch (IOException ex) {
            ex.printStackTrace();
            Log.e("IOException", ex.toString());
            return null;
        }
        return list;
    }

    private void getDataFromRealm() {
        RealmHelper realmHelper = new RealmHelper();
        catArraySubList = new ArrayList<>();
        catArraySubListvedio = new ArrayList<>();
        realmArray = new ArrayList<>();
        realmArray1 = new ArrayList<>();

        realmArray = realmHelper.retrieveCategoryListAudio();
        if (realmArray != null && realmArray.size() > 0) {
            catArraySubList.addAll(realmArray);
        } else {
            ToastUtil.showLongToastMessage(mContext, getString(R.string.you_are_offline));
        }

        realmArray1 = realmHelper.retrieveCategoryListVideo();
        if (realmArray1 != null && realmArray1.size() > 0) {
            catArraySubListvedio.addAll(realmArray1);
        } else {
            ToastUtil.showLongToastMessage(mContext, getString(R.string.you_are_offline));
        }
    }

  /*  private void loadRecentlyPlayedList() {
        if (InternetStatus.isInternetOn(getMasterActivity())) {
            RealmHelper realmHelper = new RealmHelper();
            recentlyPlayedSubList = new ArrayList<>();
            recentlyPlayedSubList = realmHelper.retrieveRecentlyPlayedList(10);
        } else {
            recentlyPlayedSubList = new ArrayList<>();
        }

        if (recentlyPlayedSubList.isEmpty()) {
            cardRecentlyPlayed.setVisibility(View.GONE);
            isRecentCardVisible = false;
        } else {
            cardRecentlyPlayed.setVisibility(View.VISIBLE);
            isRecentCardVisible = true;
            //load recently played data
            recentRecyclerAdapter = new RecentRecyclerAdapter(mContext, recentlyPlayedSubList, categoryRecycler);
            recentPlayedRecycler.setAdapter(recentRecyclerAdapter);
            recentRecyclerAdapter.setOnItemClickListener(DashBoardFragment.this);
            recentPlayedRecycler.setLayoutManager(linearLayoutManager2);
        }

    }*/

    private void loadDashBoardData() {

        if (catArraySubList.isEmpty()) {
            cardCategory.setVisibility(View.GONE);
            sliderView.setVisibility(View.GONE);
            sliderViewBottom.setVisibility(View.GONE);
            isCategoryCardVisible = false;
        } else {
            cardCategory.setVisibility(View.VISIBLE);
            sliderView.setVisibility(View.VISIBLE);
            sliderViewBottom.setVisibility(View.VISIBLE);
            isCategoryCardVisible = true;
            //load category data
            Cardlisttype ="Audio";
            CategoryRecyclerAdapter adapter = new CategoryRecyclerAdapter(mContext, catArraySubList, categoryRecycler);
            categoryRecycler.setAdapter(adapter);
            categoryRecycler.setLayoutManager(linearLayoutManager);
            adapter.notifyDataSetChanged();
        }

        //vedio merge

        if (catArraySubListvedio.isEmpty()) {
            card_categoryVedio.setVisibility(View.GONE);
            isCategoryCardVisiblevedio = false;
        } else {
            card_categoryVedio.setVisibility(View.VISIBLE);
            isCategoryCardVisiblevedio = true;
            //load category data
            Cardlisttype ="vedio";
            CategoryRecyclervedioAdapter adapter = new CategoryRecyclervedioAdapter(mContext, catArraySubListvedio, category_recyclerVedio);
            category_recyclerVedio.setAdapter(adapter);
            category_recyclerVedio.setLayoutManager(linearLayoutManagervideo);
        }
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        //loadRecentlyPlayedList();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {

            private boolean doubleBackToExitPressedOnce;

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP
                        && keyCode == KeyEvent.KEYCODE_BACK) {


                    if (doubleBackToExitPressedOnce) {
                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        // mContext.cancelNotification();
                        mContext.onDestroy();
                        System.exit(1);
                    }

                    this.doubleBackToExitPressedOnce = true;
                    ToastUtil.showLongToastMessage(mContext, getString(R.string.exit_title));

                    new Handler().postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            doubleBackToExitPressedOnce = false;
                        }
                    }, 2000);

                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onPause() {
        mContext.showWaitIndicator(false);
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        Fragment fragment;
        Bundle bundle;
        switch (v.getId()) {
            case R.id.btn_view_all_category:
                mContext.ReplaceFragment(new HomeFragment());
                break;
            case R.id.btn_view_all_categoryVedio:
                mContext.ReplaceFragment(new HomeFragmentVedio());
                break;
            case R.id.btn_view_all_recent:
                MasterActivity.songListWithAd = new ArrayList();
                fragment = new SongsList();
                bundle = new Bundle();
                bundle.putString(IS_FROM, FROM_RECENTLY_PLAYED);
                fragment.setArguments(bundle);
                mContext.ReplaceFragment(fragment);
                break;
           /* case R.id.btn_view_most_played:
                MasterActivity.songListWithAd = new ArrayList();
                fragment = new SongsList();
                bundle = new Bundle();
                bundle.putString(IS_FROM, FROM_MOST_PLAYED);
                fragment.setArguments(bundle);
                mContext.ReplaceFragment(fragment);
                break;
            case R.id.btn_view_most_downloaded:
                MasterActivity.songListWithAd = new ArrayList();
                fragment = new SongsList();
                bundle = new Bundle();
                bundle.putString(IS_FROM, FROM_MOST_DOWNLOADED);
                fragment.setArguments(bundle);
                mContext.ReplaceFragment(fragment);
                break;*/
            case R.id.btn_view_all_assets:
                MasterActivity.songListWithAd = new ArrayList();
                fragment = new SongsList();
                bundle = new Bundle();
                bundle.putString(IS_FROM, FROM_ASSETS);
                fragment.setArguments(bundle);
                mContext.ReplaceFragment(fragment);
                break;

        }
    }

    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.img_download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                downloadQueue(selectedObject, position);
            //    mContext.loadRewardedVideoAd();
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    private void downloadQueue(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.startDownloading(subCategoryModel, position);
            }
        }
    }

    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (DashBoardFragment.this.isVisible()) {
            if (tmpInfo == null || position == -1) {
                return;
            }
            final int status = tmpInfo.getStatus();
            switch (status) {
                case SubCategoryModel.STATUS_COMPLETE:
                    if (recentRecyclerAdapter != null) {
                        Log.e("recentRecyclerAdapter", "notified");
                        recentRecyclerAdapter.notifyDataSetChanged();
                    }
                    /*if (mostDownloadedRecyclerAdapter != null) {
                        Log.e("mostDownloadedRecycler", "notified");
                        mostDownloadedRecyclerAdapter.notifyDataSetChanged();
                    }
                    if (mostPlayedRecyclerAdapter != null) {
                        Log.e("mostPlayedRecycler", "notified");
                        mostPlayedRecyclerAdapter.notifyDataSetChanged();
                    }*/
                    break;
            }
        }
    }

    @Override
    public void restartLoader() {
        if (DashBoardFragment.this.isVisible()) {
            Log.e("ReloadRecentRecycler", "notified");
            //loadRecentlyPlayedList();
        }
    }

    @Override
    public void stopProgressHandler() {

    }

    @Override
    public void onMetaChanged() {

    }


    private void getHomeDataFromServer() {
        getAudioCategoryUs();
    }


    private void getAudioCategoryUs() {
        mContext.showWaitIndicator(true);
        String url = Constants.API_audio_category_list;

        StringRequest strReq = new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                try {
                    if (response != null) {

                        JSONObject jObject = new JSONObject(response);
                        String jsonString = jObject.toString(); //http request
                        Log.d("HOME ", "" + jsonString);
                        //CategoryResponse data = new Gson().fromJson(jsonString, CategoryResponse.class);
                        MasterActivity.catArrayList = new ArrayList<>();
                        MasterActivity.mostPlayedList = new ArrayList<>();
                        MasterActivity.mostDownloadedList = new ArrayList<>();


                        ArrayList<HomeModel> arrayList = new ArrayList<>();
                        JSONArray data = jObject.getJSONArray("data");

                        Log.d("data.length()", "" + data.length());

                        for (int i = 0; i < data.length(); i++) {
                            HomeModel home = new HomeModel();

                            home.setCategory_id(data.getJSONObject(i).getString(Constants.CATEGORY_ID));
                            home.setCategory_image(data.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                            home.setCategory_name(data.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                            home.setIsSubcategoryAvailable(data.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                            home.setTypeHm("Audio");
                            arrayList.add(home);
                        }

                        MasterActivity.catArrayList.addAll(arrayList);

                       /* if (data.getData() != null) {
                            MasterActivity.catArrayList = data.getData();
                        }
                   *//* if (data.getSongData() != null) {
                        MasterActivity.mostPlayedList = data.getSongData();
                    }*//*
                        if (data.getMostDownloaded() != null) {
                            MasterActivity.mostDownloadedList = data.getMostDownloaded();
                        }*/
                        loadDataFromList();

                        getVedioCategoryUs();

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mContext.showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });

// Adding request to request queue
        Volley.newRequestQueue(getMasterActivity()).add(strReq);
    }


    private void getVedioCategoryUs() {
        mContext.showWaitIndicator(true);
        String url = Constants.API_GET_HOME_URLvedio;

        StringRequest strReq = new StringRequest(Request.Method.POST,
                url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                try {
                    if (response != null) {

                        JSONObject jObject = new JSONObject(response);
                        String jsonString = jObject.toString(); //http request
                        Log.d("HOMEvideo", "" + jsonString);
                        //CategoryResponse data = new Gson().fromJson(jsonString, CategoryResponse.class);
                        MasterActivity.catArrayListvedio = new ArrayList<>();
                        MasterActivity.mostPlayedList = new ArrayList<>();
                        MasterActivity.mostDownloadedList = new ArrayList<>();

                     /*   if (data.getData() != null) {
                            MasterActivity.catArrayListvedio = data.getData();
                        }

                        if (data.getMostDownloaded() != null) {
                            MasterActivity.mostDownloadedList = data.getMostDownloaded();
                        }*/

                        ArrayList<HomeModel> arrayList = new ArrayList<>();
                        JSONArray datavideo = jObject.getJSONArray("data");

                        Log.d("data.length()", "" + datavideo.length());

                        for (int i = 0; i < datavideo.length(); i++) {
                            HomeModel home = new HomeModel();

                            home.setCategory_id(datavideo.getJSONObject(i).getString(Constants.CATEGORY_ID));
                            home.setCategory_image(datavideo.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                            home.setCategory_name(datavideo.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                            home.setIsSubcategoryAvailable(datavideo.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                            home.setTypeHm("Video");
                            arrayList.add(home);
                        }
                        MasterActivity.catArrayListvedio.addAll(arrayList);

                        loadDataFromList();


                        try {

                            DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                            Date date = new Date();
                            TodayDate_String = dateFormat.format(date);
                            settingsShrepref = mContext.getSharedPreferences(PREF_NAME, 0);
                            editor = settingsShrepref.edit();
                            String Val=settingsShrepref.getString(KEY_TODAY_DATE_ANDTIME,"");
                            if(!Val.equals(TodayDate_String))
                            {
                                if (InternetStatus.isInternetOn(getMasterActivity())) {
                                    try
                                    {
                                        GetVersion();
                                    }
                                    catch (Exception e)
                                    {
                                        e.printStackTrace();
                                    }
                                } else {

                                }

                            }
                            else
                            {


                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mContext.showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });

        // Adding request to request queue
        Volley.newRequestQueue(getMasterActivity()).add(strReq);
    }

    public void  GetVersion(){
        NetworkRequest dishRequest = new NetworkRequest(mContext);
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.version_no, String.valueOf(BuildConfig.VERSION_CODE)));
        dishRequest.sendRequest(Constants.API_Version,
                carData, catCallbackSearch);
    }
    //Api for ImageSliderTop
    public void GetImageSlider(){
        mContext.showWaitIndicator(true);
        String url=Constants.API_Image_Slider;
        StringRequest strReq=new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                for (int i=0;i<=response.length();i++){
                   SliderUtils sliderUtils=new SliderUtils();
                    try {
                        if(response!=null){
                            Log.d("IMAGE_SLIDER_API",""+response.toString());
                            JSONObject jObject=new JSONObject(response.toString());
                            String status=jObject.getString("response_status");
                            if (status.equalsIgnoreCase("1")){
                                JSONArray data=jObject.getJSONArray("data");
                                String image=data.getJSONObject(i).getString("slider_image");
                                //Toast.makeText(mContext,image,Toast.LENGTH_LONG).show();
                                sliderUtils.setSliderImageUrl(image);
                            }
                            sliderImg.add(sliderUtils);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                        mContext.showWaitIndicator(false);
                    }
                }
                sliderPagerAdapter=new SliderPagerAdapter(getMasterActivity(),sliderImg);
                sliderView.setAutoCycleDirection(SliderView.LAYOUT_DIRECTION_LTR);
                sliderView.setSliderAdapter(sliderPagerAdapter);
                sliderView.setScrollTimeInSec(5);
                sliderView.setAutoCycle(true);
                sliderView.startAutoCycle();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });
        CustomVolleyRequeat.getInstance(getMasterActivity()).addToRequestQueue(strReq);
    }
    //Api for ImageSliderBottom
    public void GetFooterImageSlider(){
        mContext.showWaitIndicator(true);
        String url=Constants.API_Footer_Image_Slider;
        StringRequest strReq=new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                mContext.showWaitIndicator(false);
                for (int i=0;i<=response.length();i++){
                    FooterSliderUtils footersliderUtils=new FooterSliderUtils();
                    try {
                        if(response!=null){
                            Log.d("IMAGE_SLIDER_API",""+response.toString());
                            JSONObject jObject=new JSONObject(response.toString());
                            String status=jObject.getString("response_status");
                            if (status.equalsIgnoreCase("1")){
                                JSONArray data=jObject.getJSONArray("data");
                                String image=data.getJSONObject(i).getString("slider_image");
                                //Toast.makeText(mContext,image,Toast.LENGTH_LONG).show();
                                footersliderUtils.setFootersliderImageUrl(image);
                            }
                            footerSliderImg.add(footersliderUtils);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                        mContext.showWaitIndicator(false);
                    }
                }
                sliderFooterPagerAdapter=new SliderFooterPagerAdapter(getMasterActivity(),footerSliderImg);
                sliderViewBottom.setAutoCycleDirection(SliderView.LAYOUT_DIRECTION_LTR);
                sliderViewBottom.setSliderAdapter(sliderFooterPagerAdapter);
                sliderViewBottom.setScrollTimeInSec(8);
                sliderViewBottom.setAutoCycle(true);
                sliderViewBottom.startAutoCycle();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
            }
        });
        CustomVolleyRequeat.getInstance(getMasterActivity()).addToRequestQueue(strReq);
    }
    private final NetworkRequest.NetworkRequestCallback catCallbackSearch = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            try {
                if (response != null) {
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.optString("response_status");
                    if (status.equalsIgnoreCase("1")) {

                    }else if(status.equalsIgnoreCase("0")){
                        //the app is being launched for first time in a Day, do something
                        try {
                        editor.putString(KEY_TODAY_DATE_ANDTIME, TodayDate_String);
                        editor.commit();
                        String Val=settingsShrepref.getString(KEY_TODAY_DATE_ANDTIME, null);
                        showAppUpdateDialog();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {

        }
    };


      private void showAppUpdateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle("App Update Available");
        builder.setMessage("You are on an older version of the App. Please upgrade to the latest version to enjoy all the new features and get the best experience.");
        builder.setNegativeButton("Later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setPositiveButton("Update Now", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String appPackageName =mContext.getPackageName(); // getPackageName() from Context or Activity object
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }
                mContext.finish();
            }
        });
        builder.setCancelable(false);
        builder.create().show();
    }
}

