package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.DownloadAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2018.
 */
public class Downloads extends MasterFragment implements DownloadListener {
    private ListView listView_downloads;

    private MainActivity mContext;

   public LinearLayout error_layout_downloads;

    private TextView textView_download;
    InterstitialAd interstitial;
    private ArrayList<SubCategoryModel> songList;
    private SwipeRefreshLayout mSwipeRefreshLayout;

   public static String downloadCount;
   public static String count;
   TextView txtDownloadedSongCount;
  public Downloads(){

  }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        return inflater.inflate(R.layout.download_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        listView_downloads = view.findViewById(R.id.listView_downloads);

        error_layout_downloads = view.findViewById(R.id.error_layout_downloads);

        textView_download = view.findViewById(R.id.textView_download);

        txtDownloadedSongCount=view.findViewById(R.id.txtDownloadedSongsCoungt);

        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                Log.e("server request data", "=");
                getDownloadedSongs();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

    }

    private void getDownloadedSongs() {
        songList=new ArrayList<>();
        RealmHelper realmHelper = new RealmHelper();
        ArrayList<SongModel> downloadedList = realmHelper.retrieveDownloadedList();
        if (downloadedList != null) {
            if (downloadedList.size() > 0) {
                for(int i=0;i<downloadedList.size();i++){
                    String VideoUrl= downloadedList.get(i).getVideo_url();
                    if (VideoUrl.equals("null")){
                        songList.add(new SubCategoryModel().getCategoryFromRealm(downloadedList.get(i)));
                    }else {

                   }
                }

                Collections.sort(songList, new Comparator<SubCategoryModel>() {
                    public int compare(SubCategoryModel v1, SubCategoryModel v2) {
                        return v1.getItem_name().toLowerCase().compareTo(v2.getItem_name().toLowerCase());
                    }
                });

                DownloadAdapter adapter = new DownloadAdapter(mContext, R.layout.downloads_list_item,songList,this);
                listView_downloads.setAdapter(adapter);
                error_layout_downloads.setVisibility(View.GONE);
                downloadCount=String.valueOf(songList.size());
                Toast.makeText(mContext,"Downloaded Songs : "+downloadCount,Toast.LENGTH_LONG).show();
                txtDownloadedSongCount.setText(downloadCount);

//                Fragment fragment=new DownloadsMainFragment();
//                Bundle bundle=new Bundle();
//                bundle.putSerializable("COUNT",songList.size());
//                fragment.setArguments(bundle);
//                Toast.makeText(mContext,"Passing Data"+songList.size(),Toast.LENGTH_LONG).show();
//                mContext.ReplaceFragment(fragment);

            } else {
                textView_download.setTypeface(mContext.getTypeFace());
                error_layout_downloads.setVisibility(View.VISIBLE);
            }
        } else {
            textView_download.setTypeface(mContext.getTypeFace());
            error_layout_downloads.setVisibility(View.VISIBLE);
        }


    }
public static String  getDownloadedCount(){
//    downloadCount=String.valueOf(songList.size());
//    Toast.makeText(mContext,"Downloaded Songs : "+downloadCount,Toast.LENGTH_LONG).show();
return downloadCount;
}
//    public void getFromSdcard()
//    {
////        File file = new File(android.os.Environment.getExternalStorageDirectory(),"/Bhakti sagar/images/");
//
//        File file = new File(Environment.getExternalStorageDirectory()
//                + File.separator + "/Bhakti sagar/images/" +getItem(position).getItem_image_name()););
//
//        Log.d("file",""+file);
//
//        if (file.isDirectory())
//        {
//            listFile = file.listFiles();
//            Log.d("listFile",""+listFile);
//
//            for (int i = 0; i < listFile.length; i++)
//            {
//                songsImage.add(listFile[i].getAbsolutePath());
//            }
//        }
//    }


    @Override
    public void onResume() {
        super.onResume();
        getDownloadedSongs();
    }

    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (tmpInfo == null || position == -1) {
            return;
        }
        final int status = tmpInfo.getStatus();
        switch (status) {
            case SubCategoryModel.STATUS_COMPLETE:
                Log.e("Downloads","notified");
                getDownloadedSongs();
                break;
        }
    }
}
