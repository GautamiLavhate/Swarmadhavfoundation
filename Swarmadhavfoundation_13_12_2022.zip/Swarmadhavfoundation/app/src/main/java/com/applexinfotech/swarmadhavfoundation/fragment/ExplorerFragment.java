package com.applexinfotech.swarmadhavfoundation.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.ImageViewer;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.USBActivity;
import com.applexinfotech.swarmadhavfoundation.adapter.UsbFilesAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.CircularImageView;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.recyclerview.EmptyRecyclerView;
import com.applexinfotech.swarmadhavfoundation.recyclerview.RecyclerItemClickListener;
import com.applexinfotech.swarmadhavfoundation.task.CopyTaskParam;
import com.github.mjdev.libaums.UsbMassStorageDevice;
import com.github.mjdev.libaums.fs.FileSystem;
import com.github.mjdev.libaums.fs.UsbFile;
import com.google.android.gms.ads.AdView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.NoSuchElementException;

import static com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity.player;


/**
 * Created by JD(jikadrajaydeep@gmail.com) on 30/08/15.
 */
public class ExplorerFragment extends Fragment implements AudioManager.OnAudioFocusChangeListener{

    private String TAG = getClass().getSimpleName();
    private boolean DEBUG = false;

    private ExplorerCallback mMainActivity;

    private UsbMassStorageDevice mSelectedDevice;
    /* package */ UsbFilesAdapter mAdapter;
    private Deque<UsbFile> dirs = new ArrayDeque<UsbFile>();

    private LinearLayout mEmptyView;
    private TextView mErrorView;
    private boolean mIsShowcase = false;
    private boolean mError = false;

    private EmptyRecyclerView mRecyclerView;
    private RecyclerItemClickListener mRecyclerItemClickListener;

    // Sorting related
    public static int mSortByCurrent;
    public static boolean mSortAsc;

    private int REQUEST_IMAGEVIEWER = 0;

    private final int REQUEST_FOCUS = 0;
    private final int REQUEST_FOCUS_DELAY = 200; //ms

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case REQUEST_FOCUS:
                    if (mRecyclerView != null)
                        mRecyclerView.requestFocus();
            }
        }
    };
    List<UsbFile> videoFileList=new ArrayList<>();
    private USBActivity mContext;
    private MediaPlayer mediaPlayer;
    SeekBar seekBarProgress;
    ImageView buttonPlayPause;
    private int mediaFileLengthInMilliseconds;
    private final Handler handler = new Handler();
    private TextView title,artist;
    private View  playPauseWrapper;
    private CircularImageView mAlbumArt;

    private MediaMetadataRetriever metaRetriver;
    private ImageButton close;
    private AdView mAdView;
    private Runnable mUpdateTimeTask;
    private Dialog dialog; //mediaPlayer dialog
    private boolean mIsDucked;
    private boolean mLostAudioFocus;
    private AudioManager audioManager;

    public ExplorerFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        //Invoked when the audio focus of the system is updated.
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_GAIN:
                // resume playback
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_GAIN");
                if (mIsDucked) {
                    mIsDucked = false;
                    if (mediaPlayer != null && mediaPlayer.isPlaying())
                        mediaPlayer.setVolume(1.0f,1.0f);
                } else if (mLostAudioFocus) {
                    mLostAudioFocus = false;
                    if (mediaPlayer != null && !mediaPlayer.isPlaying()) mediaPlayer.start();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_LOSS");
                // Lost focus for an unbounded amount of time: stop playback and release media player
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                    //  if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                    resetMediaControles();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_LOSS_TRANSIENT");
                // Lost focus for a short time, but we have to stop
                // playback. We don't release the media player because playback
                // is likely to resume
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mLostAudioFocus = true;
                    mediaPlayer.stop();
                    resetMediaControles();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                Log.e("AUDIOFOCUS:", "AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK");
                // Lost focus for a short time, but it's ok to keep playing
                // at an attenuated level
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mIsDucked = true;
                    mediaPlayer.setVolume(0.5f,0.5f);
                }
                break;

        }
    }

    private void resetMediaControles() {
        if (dialog != null) {
            seekBarProgress.setProgress(0);
            seekBarProgress.setMax(100);
            Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_arrow);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            buttonPlayPause.setImageDrawable(mDrawable);
        }
    }

    private boolean requestAudioFocus() {
        audioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        //Focus gained
        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        //Could not gain focus
    }

    private boolean removeAudioFocus() {
        if (audioManager != null) {
            return AudioManager.AUDIOFOCUS_REQUEST_GRANTED ==
                    audioManager.abandonAudioFocus(this);
        }
        return false;
    }


    public interface ExplorerCallback {
        public void setABTitle(String title, boolean showMenu);

        public CoordinatorLayout getCoordinatorLayout();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

   /* private void checkShowcase() {

        if (mError)
            return;

        UsbFile directory = mAdapter.getCurrentDir();
        if (DEBUG)
            Log.d(TAG, "Checking showcase. Current directory: " + directory.isDirectory());
        boolean available = false;
        List<UsbFile> files;

        try {
            files = mAdapter.getFiles();

            int firstImageIndex = 0;
            for (UsbFile file : files) {
                if (Utils.isImage(file)) {
                    available = true;
                    break;
                }
                firstImageIndex++;
            }

            if (available && !files.isEmpty()) {
                mIsShowcase = true;
                copyFileToCache(files.get(firstImageIndex));
            } else {
                Snackbar.make(mMainActivity.getCoordinatorLayout(),
                        getString(R.string.toast_no_images), Snackbar.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/


    private void doRefresh(UsbFile entry) {
        mAdapter.setCurrentDir(entry);
        doRefresh();
    }


    private void doRefresh() {
        try {
            if (mAdapter != null)
                mAdapter.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }

        mRecyclerView.scrollToPosition(0);
        mHandler.sendEmptyMessageDelayed(REQUEST_FOCUS, REQUEST_FOCUS_DELAY);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_explorer, container, false);
        mContext= (USBActivity) getActivity();
        SharedPreferences sharedPref = getActivity().getSharedPreferences(Constants.SORT_FILTER_PREF
                , Context.MODE_PRIVATE);
        mSortAsc = sharedPref.getBoolean(Constants.SORT_ASC_KEY, true);
        mSortByCurrent = sharedPref.getInt(Constants.SORT_FILTER_KEY, 0);

        mRecyclerView = (EmptyRecyclerView) rootView.findViewById(R.id.list_rv);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        mSelectedDevice = null;
        UsbMassStorageDevice[] devices = UsbMassStorageDevice.getMassStorageDevices(getActivity());

        mError = false;

        if (devices.length > 0)
            mSelectedDevice = devices[0];

        updateUI();

        try {
            mSelectedDevice.init();

            // we always use the first partition of the device
            if (mSelectedDevice.getPartitions() != null && !mSelectedDevice.getPartitions().isEmpty()) {
                FileSystem fs = mSelectedDevice.getPartitions().get(0).getFileSystem();
                UsbFile root = fs.getRootDirectory();
/*//                 just play video from "video" directory

                List<UsbFile> fileList = Arrays.asList(root.listFiles());
                videoFileList=new ArrayList<>();
                for (UsbFile file:fileList) {
                    if(file.isDirectory()){
                        file.listFiles();
                        if(file.getName().equalsIgnoreCase("video")){
                            currentDir = file;
                        }

                    }
                }*/
                setupRecyclerView();
                mAdapter = new UsbFilesAdapter(getActivity(),root,
                        mRecyclerItemClickListener);
                mRecyclerView.setAdapter(mAdapter);

                if (DEBUG)
                    Log.d(TAG, "root getCurrentDir: " + mAdapter.getCurrentDir());
            }else {
                Toast.makeText(getActivity(), "Can't setupDevice",Toast.LENGTH_SHORT).show();
            }


        } catch (Exception e) {
            Log.e(TAG, "error setting up device", e);
            Toast.makeText(getActivity(), "Exception "+e.toString(),Toast.LENGTH_LONG).show();
            rootView.findViewById(R.id.error).setVisibility(View.VISIBLE);
            mError = true;
        }

        if (mError) {
            mErrorView = (TextView) rootView.findViewById(R.id.error);
            mErrorView.setVisibility(View.VISIBLE);
        } else {
            mEmptyView = (LinearLayout) rootView.findViewById(R.id.empty);
            mRecyclerView.setEmptyView(mEmptyView);
        }

        // Inflate the layout for this fragment
        return rootView;
    }

    private void setupRecyclerView() {
        mRecyclerItemClickListener = new RecyclerItemClickListener(
                getActivity(), mRecyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                onListItemClick(position);
            }

            @Override
            public void onLongItemClick(View view, int position) {
                onItemLongClick(position);
            }
        });

        mRecyclerView.addOnItemTouchListener(mRecyclerItemClickListener);
    }

    private void onListItemClick(int position) {
        UsbFile entry = mAdapter.getItem(position);
        try {
            if (entry.isDirectory()) {
                dirs.push(mAdapter.getCurrentDir());
                doRefresh(entry);
            } else if(Utils.isAudio(entry)) {
                mIsShowcase = false;
                copyFileToCache(entry);
            }else{
                Toast.makeText(getActivity(),"Can't open this type of file",Toast.LENGTH_SHORT).show();

            }
        } catch (IOException e) {
            Log.e(TAG, "error starting to copy!", e);
        }
    }

    private boolean onItemLongClick(int position) {
        if (DEBUG)
            Log.d(TAG, "Long click on position: " + position);

        UsbFile entry = mAdapter.getItem(position);

        if (Utils.isImage(entry)) {
            showLongClickDialog(entry);
        }

        return true;
    }

    @Override
    public void onActivityCreated(Bundle savedState) {
        super.onActivityCreated(savedState);

        if (DEBUG)
            Log.d(TAG, "onActivityCreated");

        try {
            if (mError) {
                mRecyclerView.setVisibility(View.GONE);
                mRecyclerView.setAdapter(null);
            }
        } catch (Exception e) {
            Log.e(TAG, "Content view is not yet created!", e);
        }
    }

    private void showLongClickDialog(final UsbFile entry) {
        // We already checked it's an image

        final AlertDialog.Builder dialogAlert = new AlertDialog.Builder(getActivity());
        dialogAlert.setTitle(R.string.showcase_longclick_dialog_title);
        dialogAlert.setNegativeButton(getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        dialogAlert.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    mIsShowcase = true;
                    copyFileToCache(entry);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        dialogAlert.show();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        if (DEBUG)
            Log.d(TAG, "onAttach");

        try {
            mMainActivity = (ExplorerCallback) activity;

        } catch (ClassCastException castException) {
            /** The activity does not implement the listener. */
        }

    }

    private void updateUI() {
        mMainActivity.setABTitle(getString(R.string.explorer_title), true);
    }

    @Override
    public void onDetach() {
        super.onDetach();

        mSelectedDevice = null;

        if (DEBUG)
            Log.d(TAG, "onDetach");
    }


    public boolean popUsbFile() {
        try {
            UsbFile dir = dirs.pop();
            doRefresh(dir);

            return true;
        } catch (NoSuchElementException e) {
            Log.e(TAG, "we should remove this fragment!");
        } catch (Exception e) {
            Log.e(TAG, "error initializing mAdapter!", e);
        }

        return false;
    }

    private void copyFileToCache(UsbFile entry) throws IOException {
        CopyTaskParam param = new CopyTaskParam();
        param.from = entry;
        Utils.otgViewerCachePath.mkdirs();

        int index = entry.getName().lastIndexOf(".");

        String prefix;
        String ext = "";

        if (index < 0)
            prefix = entry.getName();
        else {
            prefix = entry.getName().substring(0, index);
            ext = entry.getName().substring(index);
        }

        // prefix must be at least 3 characters
        if (DEBUG)
            Log.d(TAG, "ext: " + ext);

        if (prefix.length() < 3) {
            prefix += "pad";
        }

        String fileName = prefix + ext;
        File downloadedFile = new File(Utils.otgViewerPath, fileName);
        File cacheFile = new File(Utils.otgViewerCachePath, fileName);
        param.to = cacheFile;

        ImageViewer.getInstance().setCurrentFile(entry);

        if (!cacheFile.exists() && !downloadedFile.exists())
            new CopyTask(this, Utils.isImage(entry)).execute(param);
        else
            launchIntent(cacheFile);

    }

    private void launchIntent(File f) {
        if (Utils.isAudio(f)) {
            File file = new File(f.getAbsolutePath());
            if (MasterActivity.serviceBound && mContext.isPlaying()) {
                if (MasterActivity.player != null) {
                    mContext.setIsFromUSB(true);
                    mContext.pauseSong();
                    if(player!=null){ player.cancelNotification();}
                }
            }
            playSong(file);
            } else {
                Toast.makeText(getActivity(), "Can't open this type of file", Toast.LENGTH_SHORT).show();
            }

    }

    private void playSong(final File f) {
        dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.popup_usb_songs);
        dialog.setTitle("Title...");

        buttonPlayPause = (ImageView) dialog.findViewById(R.id.play);
        seekBarProgress = (SeekBar) dialog.findViewById(R.id.song_progress_normal);
        title=dialog.findViewById(R.id.title);
        artist=dialog.findViewById(R.id.artist);
        playPauseWrapper = dialog.findViewById(R.id.play_pause_wrapper);
        mAlbumArt = dialog.findViewById(R.id.album_art_nowplayingcard);
        mAdView = dialog.findViewById(R.id.adView);
        close = dialog.findViewById(R.id.close);
        title.setText(f.getName());
        artist.setText(f.getAbsolutePath());
        dialog.setCanceledOnTouchOutside(false);
       /* if (Constants.showBottomBannerAd) {
            mAdView.setVisibility(View.VISIBLE);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }*/

        metaRetriver = new MediaMetadataRetriever();
        metaRetriver.setDataSource(f.getAbsolutePath());
        try {
             byte[] art = metaRetriver.getEmbeddedPicture();
             Bitmap songImage = BitmapFactory.decodeByteArray(art, 0, art.length);
             mAlbumArt.setImageBitmap(songImage);
            title.setText(metaRetriver .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            artist.setText(metaRetriver .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
        }
        catch (Exception e) {
            mAlbumArt.setBackgroundColor(Color.GRAY);
            title.setText("Unknown Album");
            artist.setText("Unknown Artist");
        }
        seekBarProgress.setProgress(0);
        seekBarProgress.setMax(100);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                // Prevent dialog close on back press button
                return keyCode == KeyEvent.KEYCODE_BACK;
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
                if (mediaPlayer!=null) {
                    mediaPlayer.stop();
                    mHandler.removeCallbacks(mUpdateTimeTask);
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            }
        });
        playPauseWrapper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (mediaPlayer!=null && mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_arrow);
                        mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                        buttonPlayPause.setImageDrawable(mDrawable);

                    }
                    else {
                        Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_pause);
                        mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                        buttonPlayPause.setImageDrawable(mDrawable);
                        if(mediaPlayer==null && requestAudioFocus()){
                            mediaPlayer = new MediaPlayer();
                            mediaPlayer.setDataSource(f.getAbsolutePath());
                            mediaPlayer.prepare();
                            mediaPlayer.setLooping(true);
                            mediaPlayer.start();
                        }else if(mediaPlayer!=null && requestAudioFocus()){
                            mediaPlayer.start();
                        }

                        primarySeekBarProgressUpdater();
                    }
                } catch (Exception e) {
                    Toast.makeText(getActivity(),"Can't open this type of file"+e.toString(),Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                mediaFileLengthInMilliseconds = mediaPlayer!=null? mediaPlayer.getDuration():0;
            }
        });
        seekBarProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (fromUser && mediaPlayer!=null) {
                    updateTime();
                }
            }
        });
        dialog.show();
    }

    private void updateTime() {
        int playPositionInMillisecconds = (mediaFileLengthInMilliseconds / 100) * seekBarProgress.getProgress();
        mediaPlayer.seekTo(playPositionInMillisecconds);
    }


    private class CopyTask extends AsyncTask<CopyTaskParam, Integer, Void> {

        private ProgressDialog dialog;
        private CopyTaskParam param;
        private ExplorerFragment parent;
        private CopyTask cp;

        public CopyTask(ExplorerFragment act, boolean isImage) {
            parent = act;
            cp = this;
            if (isImage)
                showImageDialog();
            else
                showDialog();
        }

        private void showImageDialog() {
            dialog = new ProgressDialog(parent.getActivity());
            dialog.setTitle(getString(R.string.dialog_image_title));
            dialog.setMessage(getString(R.string.dialog_image_message));
            dialog.setIndeterminate(true);
            dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        }

        private void showDialog() {
            dialog = new ProgressDialog(parent.getActivity());
            dialog.setTitle(getString(R.string.dialog_default_title));
            dialog.setIndeterminate(false);
            dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        }

        @Override
        protected void onCancelled(Void result) {
            // Remove uncompleted data file
            if (DEBUG)
                Log.d(TAG, "Removing uncomplete file transfer");
            if (param != null)
                param.to.delete();
        }

        @Override
        protected void onPreExecute() {
            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    if (DEBUG)
                        Log.d(TAG, "Dialog canceled");
                    cp.cancel(true);
                }
            });

            dialog.show();
        }

        @Override
        protected Void doInBackground(CopyTaskParam... params) {
            long time = System.currentTimeMillis();
            ByteBuffer buffer = ByteBuffer.allocate(4096);
            param = params[0];
            long length = params[0].from.getLength();
            try {
                FileOutputStream out = new FileOutputStream(param.to);
                for (long i = 0; i < length; i += buffer.limit()) {
                    if (!isCancelled()) {
                        buffer.limit((int) Math.min(buffer.capacity(), length - i));
                        params[0].from.read(i, buffer);
                        out.write(buffer.array(), 0, buffer.limit());
                        publishProgress((int) i);
                        buffer.clear();
                    }
                }
                out.close();
            } catch (IOException e) {
                Log.e(TAG, "error copying!", e);
            }
            if (DEBUG)
                Log.d(TAG, "copy time: " + (System.currentTimeMillis() - time));

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            dialog.dismiss();

            parent.launchIntent(param.to);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            dialog.setMax((int) param.from.getLength());
            dialog.setProgress(values[0]);
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(dialog!=null){
           dialog.cancel();
        }
        mContext.setIsFromUSB(false);
        if (mediaPlayer!=null) {
            mediaPlayer.stop();
            mHandler.removeCallbacks(mUpdateTimeTask);
            mediaPlayer.release();
            mediaPlayer = null;
        }
        removeAudioFocus();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGEVIEWER) {
            if (DEBUG)
                Log.d(TAG, "Scrolling to position: " + resultCode);
            mRecyclerView.scrollToPosition(resultCode);
        }
    }

    private void primarySeekBarProgressUpdater() {
        if (mediaPlayer != null) {
            seekBarProgress.setProgress((int) (((float) mediaPlayer.getCurrentPosition() / mediaFileLengthInMilliseconds) * 100)); // This math construction give a percentage of "was playing"/"song length"
            if (mediaPlayer.isPlaying()) {
                mUpdateTimeTask = new Runnable() {
                    public void run() {
                        primarySeekBarProgressUpdater();
                    }
                };
                handler.postDelayed(mUpdateTimeTask, 1000);
            }
        }
    }
}
