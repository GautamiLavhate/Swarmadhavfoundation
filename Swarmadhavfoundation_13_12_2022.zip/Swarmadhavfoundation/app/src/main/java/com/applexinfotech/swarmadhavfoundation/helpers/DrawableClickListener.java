package com.applexinfotech.swarmadhavfoundation.helpers;

/**
 * Created by JD Android on 02-Aug-18.
 */

public interface DrawableClickListener {
    public enum DrawablePosition { TOP, BOTTOM, LEFT, RIGHT }
    public void onClick(DrawablePosition target);
}
