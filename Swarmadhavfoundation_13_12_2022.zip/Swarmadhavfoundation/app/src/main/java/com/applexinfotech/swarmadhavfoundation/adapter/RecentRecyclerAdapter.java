package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.core.content.ContextCompat;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.AddPlaylistVedioDialog;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.ClickGuard;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.fragment.AddPlaylistDialog;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.VideoPlayer;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.ASSET_IMAGE_FOLDER_PATH;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.CATEGORY;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_ASSETS;

public class RecentRecyclerAdapter extends RecyclerView.Adapter<RecentRecyclerAdapter.MyViewHolder> {

    private final RealmHelper realmHelper;
    final MainActivity mContext;
    final ArrayList<SubCategoryModel> recentlyPlayedList;
    final RecyclerView recentRecycler;
    public ArrayList<String> songsID = new ArrayList<>();
    private OnItemClickListener mListener;
    private SubCategoryModel selectedObject;
    private PopupMenu menu;
    boolean isFromAssets=false;

    public boolean isFromAssets() {
        return isFromAssets;
    }

    public void setFromAssets(boolean fromAssets) {
        isFromAssets = fromAssets;
    }

    public RecentRecyclerAdapter(MainActivity mContext, ArrayList<SubCategoryModel> recentlyPlayedList, RecyclerView recentRecycler) {
        this.mContext = mContext;
        this.recentlyPlayedList = recentlyPlayedList;
        this.recentRecycler = recentRecycler;
        realmHelper = new RealmHelper();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.song_grid_item, parent, false);
        //  view.setOnClickListener(mOnClickListener);
        return new RecentRecyclerAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder mViewHolder, final int position) {
        //Get path of song name
        songsID = new ArrayList<>();
        songsID = realmHelper.retrieveSongIdList();

        if (recentlyPlayedList.get(position) != null) {
            mViewHolder.tv_title.setTypeface(mContext.getTypeFace());
            mViewHolder.tv_desc.setTypeface(mContext.getTypeFace());
            mViewHolder.tv_title.setText(recentlyPlayedList.get(position).getItem_name());
            mViewHolder.tv_desc.setText(recentlyPlayedList.get(position).getItem_description());

            Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            mViewHolder.download.setImageDrawable(mDrawable);
            Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
            arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            mViewHolder.play.setImageDrawable(arrowDrawable);
            Drawable popupMenuDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_more_new);
            popupMenuDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            mViewHolder.popupMenu.setImageDrawable(popupMenuDrawable);

            if(isFromAssets){
                mViewHolder.download.setVisibility(View.GONE);
                mViewHolder.popupMenu.setVisibility(View.GONE);
            }else{
                mViewHolder.download.setVisibility(View.VISIBLE);
                mViewHolder.popupMenu.setVisibility(View.VISIBLE);
            }

            if(isFromAssets){
                String imageFilePath = ASSET_IMAGE_FOLDER_PATH+recentlyPlayedList.get(position).getItem_image();
                Picasso.with(mContext).load(imageFilePath).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);

            }
            else if (recentlyPlayedList.get(position).getItem_image().startsWith("https")) {
                    Picasso.with(mContext).load(recentlyPlayedList.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);
                } else {
                    try {
                        Bitmap bitmap = BitmapFactory.decodeFile(recentlyPlayedList.get(position).getItem_image());
                        if(bitmap!=null){
                            mViewHolder.thumbnail.setImageBitmap(bitmap);
                        }else {
                            Picasso.with(mContext).load(recentlyPlayedList.get(position).getItem_image()).placeholder(R.drawable.no_image).fit().into(mViewHolder.thumbnail);
                        }
                    } catch (Exception ex) {
                        Log.e("Exception", ex.toString());
                        Picasso.with(mContext).load(R.drawable.no_image).placeholder(R.drawable.no_image).into(mViewHolder.thumbnail);
                        ex.printStackTrace();
                    }
                }



            mViewHolder.play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mViewHolder.layout_main.performClick();
                }
            });

            mViewHolder.layout_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //clear cached playlist
                    //Store Serializable audioList to SharedPreferences
                    SubCategoryModel selectedModel=recentlyPlayedList.get(position);
                    String videoUrl = selectedModel.getVideo_url();

                    if(videoUrl.equals("null")) {

                        StorageUtil storage = new StorageUtil(getApplicationContext());
                        if (storage.loadAudio() != null) {
                            storeGlobalSongInfo(storage, position);
                            if (MasterActivity.serviceBound && mContext.isPlaying()) {
                                Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                                mContext.sendBroadcast(broadcastIntent);
                            } else if (MasterActivity.serviceBound) {
                                mContext.playSong();
                            }

                        } else if (MasterActivity.serviceBound) {
                            storeGlobalSongInfo(storage, position);
                            mContext.playSong();
                        }


                        Fragment investProgramDetail = new Streaming();
                        MainActivity.AudioType="MainAudio";
                        Bundle bundle = new Bundle();
                        bundle.putString("isFrom", CATEGORY);
                        bundle.putInt("mode", isFromAssets ? 4 : 0);  // 4=Assets || 0=category
                        bundle.putSerializable("data", recentlyPlayedList);
                        bundle.putInt("position", position);
                        investProgramDetail.setArguments(bundle);
                        mContext.ReplaceFragment(investProgramDetail);
                    }else {
                        Utilities.hideKeyboard(mContext);
                        if (Utils.isYoutubeLink(videoUrl)) {
                            //mContext.playYoutubeVideo(selectedModel);
                        } else {
                            int audIndex = 0;
                            ArrayList<SubCategoryModel> filteredList = new ArrayList<>();
                            for (SubCategoryModel subCategoryModel : recentlyPlayedList) {
                                if (!Utils.isYoutubeLink(subCategoryModel.getVideo_url())) {
                                    filteredList.add(subCategoryModel);
                                }
                            }
                            for (int i = 0; i < filteredList.size(); i++) {
                                String id = filteredList.get(i).getItem_id();
                                if (selectedModel.getItem_id().equals(id)) {
                                    audIndex = i;
                                    break;
                                }
                            }
                            StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                            storage.clearCachedAudioPlaylist();
                            storage.storeAudio(filteredList);
                            storage.storeAudioIndex(audIndex);
                            storage.storeMode(0);
                            mContext.setMode(0);
                            storage.storeIsPlayingFrom("Category");
                            Intent intent = new Intent(mContext, VideoPlayer.class);
                            mContext.startActivity(intent);
                        }
                    }

                }
            });

            mViewHolder.download.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        selectedObject = recentlyPlayedList.get(position);
                        if (!selectedObject.isDownloaded) {
                            mListener.onItemClick(v, position, selectedObject);
                            mViewHolder.download.setClickable(false);
                            ClickGuard.guard(mViewHolder.download);
                            selectedObject.setDownloaded(true);
                        } else {
                            ToastUtil.showShortToastMessage(getApplicationContext(), "Already Downloading.." + selectedObject.getDownload_name());
                        }
                    }
                }
            });




            if (!recentlyPlayedList.get(position).getItem_file().startsWith("https")) {
                Drawable arrowExtraDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_download_complete);
                arrowExtraDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                mViewHolder.download.setBackgroundResource(0);
                mViewHolder.download.setImageDrawable(arrowExtraDrawable);
                mViewHolder.download.setClickable(false);
                ClickGuard.guard(mViewHolder.download);
                mViewHolder.download.setOnClickListener(null);
                recentlyPlayedList.get(position).setDownloaded(true);
            } else {
                Drawable extraDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                extraDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                mViewHolder.download.setImageDrawable(extraDrawable);

                if (songsID != null) {

                    if (songsID.size() > 0) {

                        for (int i = 0; i < songsID.size(); i++) {

                            if (recentlyPlayedList.get(position).getItem_id().equalsIgnoreCase(songsID.get(i))) {
                                recentlyPlayedList.get(position).setDownloaded(true);
                                Drawable arrowExtraDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_download_complete);

                                arrowExtraDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                                mViewHolder.download.setBackgroundResource(0);
                                mViewHolder.download.setImageDrawable(arrowExtraDrawable);
                                mViewHolder.download.setClickable(false);
                                ClickGuard.guard(mViewHolder.download);
                                mViewHolder.download.setOnClickListener(null);
                                break;
                            } else {
                                recentlyPlayedList.get(position).setDownloaded(false);
                            }
                        }
                    }
                }

            }

            mViewHolder.popupMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    if (menu != null) {
                        menu.dismiss();
                    }
                    menu = new PopupMenu(mContext, v);
                    menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch (item.getItemId()) {
                                case R.id.popup_song_play:
                                    mViewHolder.layout_main.performClick();
                                    break;
                                case R.id.popup_song_addto_playlist:
                                    if (recentlyPlayedList != null && !recentlyPlayedList.isEmpty() && recentlyPlayedList.size() > position) {
                                        SubCategoryModel selectedObject = recentlyPlayedList.get(position);
                                        String videoSt=selectedObject.getVideo_url();
                                        if(videoSt.equals("null")) {
                                            FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                            AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("RecentRecyclerAdapter", selectedObject,"Audio");
                                            infoDialog.setCancelable(false);
                                            infoDialog.show(fragmentManager, "Dialog");
                                        }else {
                                            FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                            AddPlaylistVedioDialog infoDialog = AddPlaylistVedioDialog.newInstance("RecentRecyclerAdapter", selectedObject,"Vedio");
                                            infoDialog.setCancelable(false);
                                            infoDialog.show(fragmentManager, "Dialog");
                                        }
                                    }
                                    break;
                            }
                            return false;
                        }
                    });
                    menu.inflate(R.menu.popup_song);
                    menu.show();
                }
            });

        }
    }

    private void storeGlobalSongInfo(StorageUtil storage, int position) {
        storage.clearCachedAudioPlaylist();
        storage.storeAudio(recentlyPlayedList);
        storage.storeAudioIndex(position);
        storage.storeMode(isFromAssets?4:0);
        storage.storeIsPlayingFrom(isFromAssets?FROM_ASSETS:CATEGORY);
        mContext.setShuffleMode(false);
        mContext.setRepeatMode(false);
        mContext.setNoOfRepeats(0);
        mContext.setMode(isFromAssets?4:0);
        mContext.stopProgressHandler();
    }


    @Override
    public int getItemCount() {
        return recentlyPlayedList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final ImageView thumbnail;
        private final ImageButton play;
        private final ImageButton download;
        private final ImageButton popupMenu;
        private final TextView tv_title;
        private final TextView tv_desc;
        private String urls;
        private String imgpath;
        private final LinearLayout layout_main;
        final CardView parentLayout;
        public final ProgressBar downloadProgress;

        public MyViewHolder(View itemView) {
            super(itemView);
            thumbnail = itemView.findViewById(R.id.img_thumbnail);
            parentLayout = itemView.findViewById(R.id.card_view);

            play = itemView.findViewById(R.id.img_play);
            download = itemView.findViewById(R.id.img_download);
            popupMenu = itemView.findViewById(R.id.popup_menu);

            tv_title = itemView.findViewById(R.id.tv_title);
            tv_desc = itemView.findViewById(R.id.tv_desc);

            layout_main = itemView.findViewById(R.id.layout_main);
            downloadProgress = itemView.findViewById(R.id.download_progress_normal);
        }
    }
}
