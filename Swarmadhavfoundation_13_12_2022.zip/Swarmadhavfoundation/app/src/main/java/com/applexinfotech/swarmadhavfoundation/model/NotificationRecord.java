package com.applexinfotech.swarmadhavfoundation.model;

public class NotificationRecord extends MasterModel
{
	private static final long serialVersionUID = 6104048947898684570L;

	private String title;
	private String description;
	private String notification_image;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNotification_image() {
		return notification_image;
	}

	public void setNotification_image(String notification_image) {
		this.notification_image = notification_image;
	}
}