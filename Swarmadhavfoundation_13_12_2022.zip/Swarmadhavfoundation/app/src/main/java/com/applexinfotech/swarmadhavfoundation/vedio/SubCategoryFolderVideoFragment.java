package com.applexinfotech.swarmadhavfoundation.vedio;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchviedoAudioSongListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment.hideKeyboard;

public class SubCategoryFolderVideoFragment  extends MasterFragment {
    MainActivity mContext;
    RecyclerView listView_category;
    ArrayList<Object> CatArray = new ArrayList<Object>();
    private SeekBar mSeekBar;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    private int numberOfColumns=2;
    private String category_id,CategoryName;
    private Bundle bundle;
    private HomeModel homeModel = new HomeModel();
    public static ArrayList<HomeModel> realmArray=new ArrayList<>();
    private LinearLayout Linerlayourserach;
    private EditText search;
    private LinearLayout noSongFoundView;
    private TextView textenofound;
    private RecyclerView video_sub_rev_search_type2Re,video_song_search_type2;

    private LinearLayout relsearch,CategoryListLi,VideoSubCategoriesLi,VideoSongsLi;
    NestedScrollView nestedScrollView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContext = (MainActivity) getMasterActivity();

        View V = inflater.inflate(R.layout.home_fragment, container, false);
        return V;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeToRefresh);
        listView_category = (RecyclerView) view.findViewById(R.id.listView_category);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        Linerlayourserach= view.findViewById(R.id.Linerlayourserach);
        search=(EditText) view.findViewById(R.id.search);
        Linerlayourserach.setVisibility(View.VISIBLE);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        textenofound = view.findViewById(R.id.textenofound);

        relsearch=view.findViewById(R.id.relsearch);
        CategoryListLi=view.findViewById(R.id.CategoryListLi);
        VideoSubCategoriesLi=view.findViewById(R.id.VideoSubCategoriesLi);
        VideoSongsLi=view.findViewById(R.id.VideoSongsLi);
        video_sub_rev_search_type2Re=view.findViewById(R.id.video_sub_rev_search_type2);
        video_song_search_type2=view.findViewById(R.id.video_song_search_type2);

        textenofound.setText("No Video Folder Found !!");
        // vedio add Masteractivity  2  after remove master cataaryist clear
      //  MasterActivity.CatArrayMaster.clear();

        bundle = getArguments();

        if (bundle != null) {
            homeModel = (HomeModel) bundle.getSerializable("CAT_ID");
            category_id = homeModel.getCategory_id();
            CategoryName= homeModel.getCategory_name();
        }
        mContext.setTitle(CategoryName);

        getSubVideoCategory();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getSubVideoCategory();
                } else {

                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        if(search.getText().toString().equals("")){
            CategoryListLi.setVisibility(View.VISIBLE);
            relsearch.setVisibility(View.GONE);
            video_sub_rev_search_type2Re.setAdapter(null);
            video_song_search_type2.setAdapter(null);
            if (InternetStatus.isInternetOn(getMasterActivity())) {
                getSubVideoCategory();
            }
        }

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        video_sub_rev_search_type2Re.setAdapter(null);
                        video_song_search_type2.setAdapter(null);
                        getSubVideoCategory();
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        video_sub_rev_search_type2Re.setAdapter(null);
                        video_song_search_type2.setAdapter(null);
                        getSubVideoCategory();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.length()>0){
                        listView_category.setAdapter(null);
                        getSubVideoSearch(s.toString());
                    }else{
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        video_sub_rev_search_type2Re.setAdapter(null);
                        video_song_search_type2.setAdapter(null);
                        getSubVideoCategory();
                    }
                }
            }

        });

        nestedScrollView=view.findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Utilities.hideKeyboard(getMasterActivity());
            }
        });

        search.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_DEL) {
                    String _text= search.getText().toString();
                    if(_text.isEmpty()){
                        if (InternetStatus.isInternetOn(getMasterActivity())) {
                            CategoryListLi.setVisibility(View.VISIBLE);
                            relsearch.setVisibility(View.GONE);
                            video_sub_rev_search_type2Re.setAdapter(null);
                            video_song_search_type2.setAdapter(null);
                            getSubVideoCategory();
                        }
                    }
                    //editText is now empty
                }

                return false;
            }
        });

    }
    private void getSubVideoCategory() {
        mContext.showWaitIndicator(true);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.CATEGORY_ID, category_id));
        dishRequest.sendRequest(Constants.API_video_subcategory_list, carData, catCallback);
    }


    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    hideKeyboard(mContext);
                    Log.d("CATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {

                    ArrayList<SubHomeCategory> arrayList = new ArrayList<>();
                    CatArray = new ArrayList<>();
                    JSONArray data = jObject.getJSONArray("data");

                    Log.d("data.length()", "" + data.length());

                    for (int i = 0; i < data.length(); i++) {
                        SubHomeCategory home = new SubHomeCategory();
                        home.setAudio_subcategory_id(data.getJSONObject(i).getString("video_subcategory_id"));
                        home.setAudio_subcategory_name(data.getJSONObject(i).getString("video_subcategory_name"));
                        home.setAudio_subcategory_image(data.getJSONObject(i).getString("video_subcategory_image"));
                        home.setCategory_id(data.getJSONObject(i).getString("video_category_id"));
                        home.setCategory_name(data.getJSONObject(i).getString("video_category_name"));
                        home.setTypeHm("Video");
                        arrayList.add(home);
                        CatArray.add(home);
                    }
                        showListView(true);
                        setHomeAdapter();
                    }else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };


    private void setHomeAdapter() {
        mContext.showWaitIndicator(false);
        SubCategoryFolderVideoAdapter Adapter = new SubCategoryFolderVideoAdapter(mContext, R.layout.category_item, CatArray, listView_category);
        listView_category.setAdapter(Adapter);
        listView_category.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
        Adapter.notifyDataSetChanged();
    }

    //Search

    private void getSubVideoSearch(String catergor) {
        mContext.showWaitIndicator(false);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.CATEGORY_ID, category_id));
        carData.add(new BasicNameValuePair(Constants.subcategory_name, catergor));
        dishRequest.sendRequest(Constants.API_video_subcat_search,
                carData, catCallbackSearch);
    }

    final NetworkRequest.NetworkRequestCallback catCallbackSearch = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            // mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());

                    String status = jObject.optString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        CategoryListLi.setVisibility(View.GONE);
                        relsearch.setVisibility(View.VISIBLE);
                        JSONObject data = jObject.getJSONObject("data");

                        ArrayList<SubCategoryModel> video_listItem = new ArrayList<>();
                        JSONArray video_list= data.getJSONArray("video_list");

                        if(!(video_list.length()==0)) {
                            for (int j = 0; j < video_list.length(); j++) {
                                VideoSongsLi.setVisibility(View.VISIBLE);
                                SubCategoryModel categoryModel1 = new SubCategoryModel();
                                categoryModel1.setItem_id(video_list.getJSONObject(j).getString("video_id"));
                                categoryModel1.setItem_name(video_list.getJSONObject(j).getString("video_title"));
                                categoryModel1.setItem_description(video_list.getJSONObject(j).getString("video_description"));
                                categoryModel1.setItem_file(video_list.getJSONObject(j).getString("video_file"));
                                categoryModel1.setItem_image(video_list.getJSONObject(j).getString("front_cover"));
                                categoryModel1.setDownload_name(video_list.getJSONObject(j).getString("video_title"));
                                categoryModel1.setVideo_url(video_list.getJSONObject(j).optString("video_file"));
                                categoryModel1.setCategory_id(video_list.getJSONObject(j).getString("video_category_id"));
                                video_listItem.add(categoryModel1);
                            }

                            SearchviedoAudioSongListAdapter Adaptervi = new SearchviedoAudioSongListAdapter(mContext, video_listItem, video_song_search_type2);
                            video_song_search_type2.setAdapter(Adaptervi);
                            video_song_search_type2.setLayoutManager(new GridLayoutManager(getActivity(), 3));
                        }else {
                            VideoSongsLi.setVisibility(View.GONE);
                        }


                        ArrayList<Object> videosubcategoryarry = new ArrayList<>();
                        ArrayList<SubHomeCategory> videosubcategorylist = new ArrayList<>();
                        JSONArray videosublist = data.getJSONArray("video_subcategory_list");
                        if(!(videosublist.length()==0)) {
                            VideoSubCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < videosublist.length(); i++) {
                                SubHomeCategory home = new SubHomeCategory();
                                home.setAudio_subcategory_id(videosublist.getJSONObject(i).getString("subcategory_id"));
                                home.setAudio_subcategory_name(videosublist.getJSONObject(i).getString("subcategory_name"));
                                home.setAudio_subcategory_image(videosublist.getJSONObject(i).getString("subcategory_image"));
                                home.setCategory_id(videosublist.getJSONObject(i).getString("category_id"));
                                home.setCategory_name(videosublist.getJSONObject(i).getString("category_name"));
                                home.setTypeHm("Video");
                                videosubcategorylist.add(home);
                                videosubcategoryarry.add(home);
                            }

                            SearchVideoSubCategoyAdapter Adapter2 = new SearchVideoSubCategoyAdapter(mContext, R.layout.search_adapter_layout, videosubcategoryarry, video_sub_rev_search_type2Re);
                            video_sub_rev_search_type2Re.setAdapter(Adapter2);
                            video_sub_rev_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            VideoSubCategoriesLi.setVisibility(View.GONE);
                        }
                        showListView(true);

                    } else if(status.equalsIgnoreCase("0")){
                        showListView(false);
                    }
                } else {
                    //showListView(false);
                }

            } catch (Exception e) {
                //mContext.showWaitIndicator(false);
                Log.e("Exception", e.toString());
                e.printStackTrace();

            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            //mContext.showWaitIndicator(false);
        }
    };

    private void showListView(boolean flag) {
        if (flag) {
            noSongFoundView.setVisibility(View.GONE);

        } else {

            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }


}
