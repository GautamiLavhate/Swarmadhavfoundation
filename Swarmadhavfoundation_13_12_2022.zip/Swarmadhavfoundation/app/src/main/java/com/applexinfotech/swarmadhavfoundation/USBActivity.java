package com.applexinfotech.swarmadhavfoundation;

import android.Manifest;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.VisibilityManager;
import com.applexinfotech.swarmadhavfoundation.common.util.Utils;
import com.applexinfotech.swarmadhavfoundation.fragment.ExplorerFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.USBHomeFragment;
import com.applexinfotech.swarmadhavfoundation.helpers.JavaFsFileSystemCreator;
import com.github.mjdev.libaums.UsbMassStorageDevice;
import com.github.mjdev.libaums.fs.FileSystemFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class USBActivity extends MasterActivity implements USBHomeFragment.HomeCallback,
        ExplorerFragment.ExplorerCallback {

    private String TAG = "OTGViewer";
    private boolean DEBUG = false;

    private List<UsbDevice> mDetectedDevices;
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 11;
    int PERMISSION_ALL = 1;
    private int checkedPermission = PackageManager.PERMISSION_DENIED;
    private static final String ACTION_USB_PERMISSION = "com.androidinspain.otgviewer.USB_PERMISSION";
    private PendingIntent mPermissionIntent;
    private UsbManager mUsbManager;
    private UsbMassStorageDevice mUsbMSDevice;

    private Toolbar mToolbar;
    private CoordinatorLayout mCoordinatorLayout;

    private USBHomeFragment mHomeFragment;
    private ExplorerFragment mExplorerFragment;
    private VisibilityManager mVisibilityManager;

    private final int HOME_FRAGMENT = 0;
    private final int SETTINGS_FRAGMENT = 1;
    private final int EXPLORER_FRAGMENT = 2;
    String[] PERMISSIONS = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private boolean mShowIcon = false;

    static {
        FileSystemFactory.registerFileSystem(new JavaFsFileSystemCreator());
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usb);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mCoordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinator_layout);

        setSupportActionBar(mToolbar);

        if (DEBUG)
            Log.d(TAG, "onCreate");

        mHomeFragment = new USBHomeFragment();
        mExplorerFragment = new ExplorerFragment();

        mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
        mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        mDetectedDevices = new ArrayList<UsbDevice>();
        mVisibilityManager = new VisibilityManager();
        checkAndGrantPermissions();
    }

    private void checkAndGrantPermissions() {
        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        } else {
            checkedPermission = PackageManager.PERMISSION_GRANTED;
            displayView(HOME_FRAGMENT);
        }
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    public CoordinatorLayout getCoordinatorLayout() {
        return mCoordinatorLayout;
    }

    private void displayView(int position) {
        Fragment fragment = null;

        switch (position) {
            case HOME_FRAGMENT:
                fragment = mHomeFragment;
                break;
            case EXPLORER_FRAGMENT:
                fragment = (Fragment) mExplorerFragment;
                break;
            default:
                break;
        }

        String tag = Integer.toString(position);

        if (getFragmentManager().findFragmentByTag(tag) != null && getFragmentManager().findFragmentByTag(tag).isVisible()) {
            if (DEBUG)
                Log.d(TAG, "No transition needed. Already in that fragment!");

            return;
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            //  fragmentTransaction.setCustomAnimations(R.animator.enter, R.animator.exit, R.animator.pop_enter, R.animator.pop_exit);;
            fragmentTransaction.replace(R.id.container_body, fragment, tag);

            // Home fragment is not added to the stack
            if (position != HOME_FRAGMENT) {
                fragmentTransaction.addToBackStack(null);
            }

            fragmentTransaction.commitAllowingStateLoss();

            getFragmentManager().executePendingTransactions();
        }

    }

    @Override
    public void onBackPressed() {
        // Catch back action and pops from backstack
        // (if you called previously to addToBackStack() in your transaction)
        boolean result = false;

        if (mExplorerFragment != null && mExplorerFragment.isVisible()) {
            if (DEBUG)
                Log.d(TAG, "we are on ExplorerFragment. Result: " + result);

            result = mExplorerFragment.popUsbFile();
        }

        if (result)
            return;
        else if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack();

            if (DEBUG)
                Log.d(TAG, "Pop fragment");
        }
        // Default action on back pressed
        else super.onBackPressed();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item = menu.findItem(R.id.action_settings);
        item.setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {
            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void removedUSB() {

        if (mVisibilityManager.getIsVisible()) {
            while (getFragmentManager().getBackStackEntryCount() != 0) {
                getFragmentManager().popBackStackImmediate();
            }

            displayView(HOME_FRAGMENT);
        } else {
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
    }

    BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (DEBUG)
                Log.d(TAG, "mUsbReceiver triggered. Action " + action);

            checkUSBStatus();

            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action))
                removedUSB();

            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            //call method to set up device communication
                            if (DEBUG)
                                Log.d(TAG, "granted permission for device " + device.getDeviceName() + "!");
                            connectDevice(device);
                        }
                    } else {
                        Log.e(TAG, "permission denied for device " + device);
                    }
                }
            }
        }
    };

    private void checkUSBStatus() {

        if (DEBUG)
            Log.d(TAG, "checkUSBStatus");

        mDetectedDevices.clear();

        mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

        if (mUsbManager != null) {
            HashMap<String, UsbDevice> deviceList = mUsbManager.getDeviceList();

            if (!deviceList.isEmpty()) {
                Iterator<UsbDevice> deviceIterator = deviceList.values().iterator();
                while (deviceIterator.hasNext()) {
                    UsbDevice device = deviceIterator.next();
                    if (Utils.isMassStorageDevice(device))
                        mDetectedDevices.add(device);
                }
            }

            updateUI();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (DEBUG)
            Log.d(TAG, "onResume");

        mVisibilityManager.setIsVisible(true);

        IntentFilter filter = new IntentFilter();
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        filter.addAction(ACTION_USB_PERMISSION);

        registerReceiver(mUsbReceiver, filter);

        checkUSBStatus();

    }

    @Override
    public void onPause() {
        super.onPause();

        if (DEBUG)
            Log.d(TAG, "onPause");
        mVisibilityManager.setIsVisible(false);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();

        unregisterReceiver(mUsbReceiver);
       // Utils.deleteCache(getCacheDir());
    }

    private void updateUI() {
        if (DEBUG)
            Log.d(TAG, "updateUI");

        if (mHomeFragment != null && mHomeFragment.isAdded()) {
            mHomeFragment.updateUI();
        }
    }

    private void connectDevice(UsbDevice device) {
        if (DEBUG)
            Log.d(TAG, "Connecting to device");

        if (mUsbManager.hasPermission(device) && DEBUG)
            Log.d(TAG, "got permission!");

        UsbMassStorageDevice[] devices = UsbMassStorageDevice.getMassStorageDevices(this);
        if (devices.length > 0) {
            mUsbMSDevice = devices[0];
            setupDevice();
        }
    }


    private void setupDevice() {
        displayView(EXPLORER_FRAGMENT);
    }

    @Override
    public void requestPermission(int pos) {
        mUsbManager.requestPermission(mDetectedDevices.get(pos), mPermissionIntent);
    }

    @Override
    public List<UsbDevice> getUsbDevices() {
        return mDetectedDevices;
    }

    @Override
    public void setABTitle(String title, boolean showMenu) {

        getSupportActionBar().setTitle(title);
        getSupportActionBar().setDisplayHomeAsUpEnabled(showMenu);
        // Set logo
        getSupportActionBar().setDisplayShowHomeEnabled(mShowIcon);
        getSupportActionBar().setIcon(R.drawable.logo_swar);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_ALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkedPermission = PackageManager.PERMISSION_GRANTED;
                Log.e("permission ", "" + "PERMISSION_GRANTED");
                displayView(HOME_FRAGMENT);
                return;
            } else {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        showMessageOKCancel("You need to allow access to all the permissions",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            checkAndGrantPermissions();
                                        }
                                    }
                                });
                        return;
                    }
                }
            }


        } else {
            Log.e("permission ", "" + "PERMISSION_DENIED");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                //requestPermission();
                checkAndGrantPermissions();
            } else
                Toast.makeText(this, "Read Phone State permission is Required from Settings", Toast.LENGTH_LONG).show();

        }

    }

    public void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(USBActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

}
