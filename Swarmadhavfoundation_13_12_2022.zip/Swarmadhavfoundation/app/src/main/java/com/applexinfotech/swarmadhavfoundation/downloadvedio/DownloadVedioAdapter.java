package com.applexinfotech.swarmadhavfoundation.downloadvedio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;


import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.VideoPlayer;
import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Adite on 03-01-2016.
 */
public class DownloadVedioAdapter extends ArrayAdapter<String> {
    private LayoutInflater layoutInflater;

    public MainActivity mContext;

    int resource;

    private ProgressDialog pDialog;
    ArrayList<SubCategoryModel> songList = new ArrayList<>();
    private String fileName, imageName,videoName,lyricsPdf;
    DownloadsVedio classContext;

    public DownloadVedioAdapter(MainActivity context, int resource, ArrayList<SubCategoryModel> downloadedList, DownloadsVedio downloads) {
        super(context, resource);
        mContext = context;
        this.resource = resource;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        songList = downloadedList;
        Log.d("Adapter Call", "Size: " + songList.size());
        classContext = downloads;
    }

    public int getCount() {
        return songList.size();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View rootView = convertView;

        rootView = layoutInflater.inflate(R.layout.downloadsvedio_list_item, null, true);

        ImageView cat_image = (ImageView) rootView.findViewById(R.id.image);

        ImageButton play = (ImageButton) rootView.findViewById(R.id.play_download);
        final ImageButton delete = (ImageButton) rootView.findViewById(R.id.delete_download);
        final ImageButton share = (ImageButton) rootView.findViewById(R.id.share_download);


            Drawable mDrawable=ContextCompat.getDrawable(mContext,R.drawable.ic_delete_new);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
            delete.setImageDrawable(mDrawable);
            Drawable arrowDrawable=ContextCompat.getDrawable(mContext,R.drawable.ic_play_new);
            arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.iconPrimaryColor),PorterDuff.Mode.MULTIPLY));
            play.setImageDrawable(arrowDrawable);
            Drawable shareDrawable=ContextCompat.getDrawable(mContext,R.drawable.ic_share_new);
            shareDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext,R.color.iconPrimaryColor),PorterDuff.Mode.MULTIPLY));
            share.setImageDrawable(shareDrawable);


        TextView tv_title = (TextView) rootView.findViewById(R.id.tv_title);
        TextView tv_desc = (TextView) rootView.findViewById(R.id.tv_desc);
        final LinearLayout layout_main = (LinearLayout) rootView.findViewById(R.id.layout_main);
        ImageView  imagePlay=rootView.findViewById(R.id.img_play);
       // tv_title.setTypeface(mContext.getTypeFace());
        tv_desc.setTypeface(mContext.getTypeFace());

        tv_title.setText(songList.get(position).getItem_name());
        tv_desc.setText(songList.get(position).getItem_description());

        Log.d("TITLE", "" + songList.get(position).getItem_name());
        Log.d("IMAGE", "" + songList.get(position).getItem_image());
        Utilities.getVideoName(songList.get(position).getVideo_url());

        Glide.with(mContext).load(songList.get(position).getItem_image()).placeholder(R.drawable.no_image).into(cat_image);
       /* try {
            Bitmap bitmap = BitmapFactory.decodeFile(songList.get(position).getItem_image());
            cat_image.setImageBitmap(bitmap);
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout_main.performClick();
            }
        });
        imagePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout_main.performClick();
            }
        });
        layout_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mContext.player != null) {
                    if (mContext.isPlaying()) {
                        mContext.pauseSong();
                        ((MainActivity) mContext).bottum_layout.setVisibility(View.GONE);
                    }
                }
                Log.d("SONG_PATH", "" + songList.get(position).getVideo_url());
                StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                storage.clearCachedAudioPlaylist();
                storage.storeAudio(songList);
                storage.storeAudioIndex(position);
                storage.storeMode(0);
                mContext.setMode(0);
                storage.storeIsPlayingFrom("Download");
                Intent intent = new Intent(mContext, VideoPlayer.class);
                mContext.startActivity(intent);
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
                if (storage.loadAudio() != null) {
                    ArrayList<SubCategoryModel> nowPlayingList = storage.loadAudio();
                    ArrayList<SubCategoryModel> templist=new ArrayList<SubCategoryModel>();
                    if (nowPlayingList.get(position).getVideo_url().startsWith("https")) { //means not playing from download
                        showDeleteAlert(position);
                    } else {
                        String currentlyPlayingId = nowPlayingList.get(storage.loadAudioIndex()).getItem_id();
                        String currentSongId = songList.get(position).getItem_id();
                        if (currentlyPlayingId.equalsIgnoreCase(currentSongId)) {
                            Toast.makeText(mContext, R.string.you_can_not_remove_current_song, Toast.LENGTH_SHORT).show();
                        } else {
                            showDeleteAlert(position);
                        }
                    }
                } else {
                    showDeleteAlert(position);
                }
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //shareSong(position);
            }
        });

        return rootView;
    }

    private void showDeleteAlert(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

        builder.setTitle(R.string.confirm);
        builder.setMessage(R.string.do_you_want_to_remove_this_song);

        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog
                deleteSong(position);
                dialog.dismiss();
            }
        });

        builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

    private void deleteSong(int position) {
        fileName = songList.get(position).getDownload_name() + ".mp3";
        videoName=Utilities.getVideoName(songList.get(position).getVideo_url());
        imageName = songList.get(position).getDownload_name() + ".jpg";
        lyricsPdf= songList.get(position).getDownload_name() + ".pdf";
        Log.d("SONG_PATH", "" + songList.get(position).getVideo_url());

       //delete mp4 file
        File videoDir = new File(Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH);
        if (!videoDir.exists()) {
            return;
        }

        // Output stream to write file
        File outputFile2 = new File(videoDir, videoName);
        if (outputFile2.exists()) {
            boolean deleted = outputFile2.delete();
            Log.e("videoDeleted", "==" + deleted);
        }

        //delete image file
        File imgDir = new File(Constants.DIRECTORY_PATH + Constants.IMAGE_FOLDER_PATH);
        if (!imgDir.exists()) {
            return;
        }

        // Output stream to write file
        File file = new File(imgDir, imageName);
        if (file.exists()) {
            boolean deleted = file.delete();
            Log.e("imageDeleted", "==" + deleted);
        }


        RealmHelper realmHelper = new RealmHelper();
        Log.e("itemId", songList.get(position).getItem_id());
        realmHelper.deleteSongData(songList.get(position).getItem_id());

        StorageUtil storage = new StorageUtil(mContext.getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        if (audioList != null) {
            if (!audioList.get(0).getVideo_url().startsWith("https")) { //means not playing from download
                for (int i = 0; i < audioList.size(); i++) {
                    String currentlyPlayingId = audioList.get(i).getItem_id();
                    String currentSongId = songList.get(position).getItem_id();
                    if (currentlyPlayingId.equalsIgnoreCase(currentSongId)) {
                        audioList.remove(i);
                        storage.storeAudio(audioList);
                        int index = storage.loadAudioIndex();
                        if (index > 0) {
                            storage.storeAudioIndex(index - 1);
                        }
                        break;
                    }
                }
            }
        }
        songList.remove(position);
        Toast.makeText(mContext, R.string.song_removed_successfully, Toast.LENGTH_SHORT).show();
        if (songList.isEmpty()) {
            classContext.error_layout_downloads.setVisibility(View.VISIBLE);
        }
        notifyDataSetChanged();

    }

    private void shareSong(int position) {
        String SHARE_URL = mContext.getString(R.string.google_playstore_url) + mContext.getApplicationContext().getPackageName();
        Log.e("SHARE_URL","==="+SHARE_URL);

        String  fileName = Utilities.getVideoName(songList.get(position).getVideo_url());

        File songDir = new File(Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH);
        if (!songDir.exists()) {
            return;
        }

        // Output stream to write file
        File outputFile = new File(songDir, fileName);
        String path = outputFile.getAbsolutePath();
        Uri photoURI = FileProvider.getUriForFile(mContext,
                mContext.getString(R.string.file_provider_authority),
                outputFile);
        String EXTRA_TEXT=mContext.getString(R.string.i_am_watching)+ songList.get(position).getDownload_name()+"' by "+ mContext.getString(R.string.app_name)+"..! \n"+mContext.getString(R.string.download_from_here)+SHARE_URL;
        String EXTRA_SUBJECT= "'"+ songList.get(position).getDownload_name()+"' from "+mContext.getString(R.string.app_name)+"...";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.putExtra(Intent.EXTRA_STREAM, photoURI);
        share.putExtra(Intent.EXTRA_TEXT,EXTRA_TEXT);
        share.putExtra(Intent.EXTRA_SUBJECT,EXTRA_SUBJECT);
        share.setType("video/*");
        mContext.startActivity(Intent.createChooser(share, "Share with"));

    }
}