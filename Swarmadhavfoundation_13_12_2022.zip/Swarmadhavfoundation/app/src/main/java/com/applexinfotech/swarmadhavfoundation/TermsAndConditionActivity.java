package com.applexinfotech.swarmadhavfoundation;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.text.LineBreaker;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class TermsAndConditionActivity extends MasterActivity {
    private MainActivity mContext;
    private JustifyTextView txtTermsAndConditionContent;
    Activity TermsAndCondition=this;
    private ProgressDialog progressDialog;
    private ImageButton imgBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_and_condition);
        setTitle(getString(R.string.terms_condition));

        initUI();
        onClick();

        isInternet= InternetStatus.isInternetOn(TermsAndCondition);
        if (isInternet) {
            getTermsAndCondition();
        } else {
            ToastUtil.showLongToastMessage(TermsAndCondition, getString(R.string.no_internet_connection_found));
        }

    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        return;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    public void initUI(){
        txtTermsAndConditionContent=(JustifyTextView) findViewById(R.id.txtTermsAndConditionContent);
        imgBack=(ImageButton)findViewById(R.id.drawer_back);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            txtTermsAndConditionContent.setJustificationMode(LineBreaker.JUSTIFICATION_MODE_INTER_WORD);
        }
    }
    public void onClick(){
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TermsAndCondition,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    public void getTermsAndCondition(){
        //progressDialog=new ProgressDialog(TermsAndCondition);
        //progressDialog.show();
        showWaitIndicator(true);
        String url= Constants.API_Terms_And_Condition;
        StringRequest strReq=new StringRequest(Request.Method.GET,
                url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                showWaitIndicator(false);
                try {
                    if (response != null){
                        Log.d("TERMS_AND_CONDITION_API",""+response.toString());
                        //Toast.makeText(TermsAndCondition,url,Toast.LENGTH_LONG).show();
                        JSONObject jObject=new JSONObject(response.toString());
                        String status=jObject.getString("response_status");
                        if (status.equalsIgnoreCase("1")){
                            JSONArray data=jObject.getJSONArray("data");
                            String terms_conditions=data.getJSONObject(0).getString("terms_conditions");
                            txtTermsAndConditionContent.setText(terms_conditions);


                        }else {
                            showWaitIndicator(false);
                        }
                    }

                }catch (Exception e){
                    e.printStackTrace();
                    showWaitIndicator(false);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                showWaitIndicator(false);
            }
        });
        Volley.newRequestQueue(TermsAndCondition).add(strReq);

    }

}