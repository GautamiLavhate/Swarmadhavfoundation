package com.applexinfotech.swarmadhavfoundation.model;

public class SubHomeCategory extends MasterModel {
    private static final long serialVersionUID = 6104048947898684570L;
    private String audio_subcategory_id;
    private String audio_subcategory_name;
    private String audio_subcategory_image;
    private String category_id;
    private String category_name;
    private String TypeHm;

    public String getTypeHm() {
        return TypeHm;
    }

    public void setTypeHm(String typeHm) {
        TypeHm = typeHm;
    }

    public String getAudio_subcategory_id() {
        return audio_subcategory_id;
    }

    public void setAudio_subcategory_id(String audio_subcategory_id) {
        this.audio_subcategory_id = audio_subcategory_id;
    }

    public String getAudio_subcategory_name() {
        return audio_subcategory_name;
    }

    public void setAudio_subcategory_name(String audio_subcategory_name) {
        this.audio_subcategory_name = audio_subcategory_name;
    }

    public String getAudio_subcategory_image() {
        return audio_subcategory_image;
    }

    public void setAudio_subcategory_image(String audio_subcategory_image) {
        this.audio_subcategory_image = audio_subcategory_image;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
}
