package com.applexinfotech.swarmadhavfoundation.model;

import java.io.Serializable;

public class MasterModel implements Serializable {
	private static final long serialVersionUID = 6608693830502035009L;
}
