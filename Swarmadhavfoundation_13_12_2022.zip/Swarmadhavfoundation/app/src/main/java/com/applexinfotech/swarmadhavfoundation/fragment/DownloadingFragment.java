package com.applexinfotech.swarmadhavfoundation.fragment;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.telecom.Call;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.DownloadingAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.android.gms.ads.InterstitialAd;
import com.squareup.picasso.OkHttpDownloader;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.OkHttpClient;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.downloadQueue;
import static com.crashlytics.android.Crashlytics.TAG;

public class DownloadingFragment extends MasterFragment implements DownloadListener, OnItemClickListener<SubCategoryModel> {

    private MainActivity mContext;
    private final HomeModel homeModel = new HomeModel();
    private ListView mCategoryList;
    private String category_id;
    private Bundle bundle;
    private DownloadingAdapter Adapter;

    InterstitialAd interstitial;

    public static RelativeLayout topContainer;
    private ProgressBar mProgress;
    private SeekBar mSeekBar;
    private int overflowcounter = 0;
    private View rootView;


    private LinearLayout noSongFoundView;
    private TextView textView_download;
    public ArrayList<SubCategoryModel> mItem = new ArrayList<>();
    public String lastSearchedString = "";
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private Parcelable state;

    Handler handler;
    //OkHttpClient client;


    OkHttpClient client;
    public static final String ACTION_PAUSE_DOWNLOAD = "com.applexinfotech.swarmadhavfoundation.ACTION_PAUSE_DOWNLOAD";
    public static final String CANCEL_TAG="c_tag";
    public HashMap<String, Call> hashMap=new HashMap<>();;
    public DownloadingFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = (MainActivity) getMasterActivity();
        handler=new Handler(Looper.getMainLooper());
        client=new OkHttpClient();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_downloading, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCategoryList = view.findViewById(R.id.listView_cat_list);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        textView_download = view.findViewById(R.id.textView_download);
        textView_download.setTypeface(mContext.getTypeFace());
        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    Log.e("server request data", "=");
                    showDownloadingData();

                } else {
                    showListView(false);
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
        // Restore previous state (including selected item index and scroll position)
        if (state != null) {
            Log.d(TAG, "trying to restore listview state..");
            mCategoryList.onRestoreInstanceState(state);
        }

        showDownloadingData();


    }

    public void showDownloadingData() {
        if (!downloadQueue.isEmpty()) {
            showListView(true);
            Adapter = new DownloadingAdapter(mContext, R.layout.subcategory_list_item, downloadQueue, homeModel, DownloadingFragment.this.getClass().getCanonicalName());
            mCategoryList.setAdapter(Adapter);
            Toast.makeText(mContext,"Downloading Songs : "+String.valueOf(mCategoryList.getCount()),Toast.LENGTH_LONG).show();
          //  Adapter.setOnItemClickListener(DownloadingFragment.this);
            Adapter.notifyDataSetChanged();
        } else {
            showListView(false);
        }
    }

    @Override
    public void onPause() {
        // Save ListView state @ onPause
        Log.d(TAG, "saving listview state @ onPause");
        state = mCategoryList.onSaveInstanceState();
        super.onPause();
    }


    private void showListView(boolean flag) {
        if (flag) {
            mCategoryList.setVisibility(View.VISIBLE);
            noSongFoundView.setVisibility(View.GONE);

        } else {
            mCategoryList.setVisibility(View.GONE);
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }

    //Downloading Service calls and receiver methods
    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                // downloadQueue(selectedObject, position);
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    public void pauseDownloading(final SubCategoryModel subCategoryModel,final int position){
        if (downloadQueue.isEmpty()){

        }else {
            if (contains(subCategoryModel.getItem_id())){
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(mContext,"Pause Download",Toast.LENGTH_LONG).show();
                        Log.e("Pause Downloading","Start pause downloading");
                        try {
                            URL url=new URL(subCategoryModel.getItem_file());
                            Toast.makeText(mContext,url.toString(),Toast.LENGTH_LONG).show();
                            if (client != null){
                                for (okhttp3.Call call:client.dispatcher().runningCalls()){
                                    if (call.request().tag().equals(CANCEL_TAG)){
                                        call.cancel();
                                        Toast.makeText(mContext,"Pause Download",Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                    }
                });
                return;
            }
        }
    }
    boolean contains(String id) {
        for (SubCategoryModel item : downloadQueue) {
            if (item.getItem_id().equals(id)) {
                return true;
            }
        }
        return false;
    }
    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (DownloadingFragment.this.isVisible()) {
            if (tmpInfo == null || position == -1) {
                return;
            }
            final int status = tmpInfo.getStatus();
            switch (status) {
                case SubCategoryModel.STATUS_DOWNLOADING:
                    if (!downloadQueue.isEmpty()) {
                        if (Adapter != null) {
                            int viewPosition = getAdapterItemPosition(tmpInfo.getItem_id());
                           Log.e("DOWNLOADING", "viewPosition" + String.valueOf(viewPosition));
                            final SubCategoryModel appInfo = downloadQueue.get(viewPosition);
                            if (appInfo.getItem_id().equalsIgnoreCase(tmpInfo.getItem_id())) {
                                if (isCurrentListViewItemVisible(viewPosition)) {
                                    DownloadingAdapter.ViewHolder holder = getViewHolder(viewPosition);
                                    holder.mProgress.setVisibility(View.VISIBLE);
                                    holder.tv.setVisibility(View.VISIBLE);

                                    holder.mProgress.setProgress(tmpInfo.getProgress());
                                    holder.tv.setText(String.valueOf(tmpInfo.getProgress())+"%");
                                    holder.download.setClickable(false);
                                    holder.close.setVisibility(View.VISIBLE);
                                   // holder.pause.setVisibility(View.VISIBLE);


                                    holder.close.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            String url=tmpInfo.getItem_file();

                                            if (!downloadQueue.isEmpty()){
                                                for (SubCategoryModel model : downloadQueue){
                                                    if (model.getItem_id().equals(tmpInfo.getItem_id())){
                                                        stopDownloading(tmpInfo,viewPosition);
                                                        downloadQueue.remove(viewPosition);
                                                        mCategoryList.removeViewInLayout(holder.linearLayoutsong);
                                                        Adapter.notifyDataSetChanged();
                                                        if (downloadQueue.isEmpty()){
                                                            noSongFoundView.setVisibility(View.VISIBLE);
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    });
//                                    holder.pause.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
////                                            pauseDownloading(tmpInfo,viewPosition);
//                                            pauseDownload(tmpInfo,viewPosition);
//                                            holder.pause.setVisibility(View.GONE);
//                                            holder.playDownload.setVisibility(View.VISIBLE);
//
//                                        }
//                                    });
//                                    holder.playDownload.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
//
//                                            holder.playDownload.setVisibility(View.GONE);
//                                            holder.pause.setVisibility(View.VISIBLE);
//                                        }
//                                    });


                                }
                            }

                        }
                    }
                    break;
                case SubCategoryModel.STATUS_COMPLETE:
                    if (!downloadQueue.isEmpty()) {
                        if (Adapter != null) {
                            Adapter.notifyDataSetChanged();
                        }
                    }
                    else{
                        showListView(false);
                    }
                    break;
                case SubCategoryModel.STATUS_PAUSE:

                    break;
            }
        }
    }
    private void stopDownloading(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.stopDownloading(subCategoryModel, position);
            }
        }
    }
    private void pauseDownload(SubCategoryModel subCategoryModel,int position){
        if (MasterActivity.downloadServiceBound){
            if (MasterActivity.downloadService != null){
                MasterActivity.downloadService.pauseDownloading(subCategoryModel,position);
            }

        }
    }
    private BroadcastReceiver onDownloadComplete=new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action=intent.getAction();
            Toast.makeText(mContext,action,Toast.LENGTH_LONG).show();

        }
    };

    private boolean DownloadPause(Context context,String downloadTitle){
        SubCategoryModel subCategoryModel = new SubCategoryModel();
        String url=subCategoryModel.getItem_file();
        int updateRows=0;
        ContentValues pauseDownload=new ContentValues();
        pauseDownload.put("control",1);

        try {
            updateRows=context
                    .getContentResolver()
                    .update(Uri.parse(url),
            pauseDownload,
            "title=?",
            new String[]{downloadTitle});
            Toast.makeText(mContext,"Downloading Paused",Toast.LENGTH_LONG).show();
        }catch (Exception e){
            Log.e(TAG, "Failed to update control for downloading video");
        }
        return 0<updateRows;
    }

    private boolean isCurrentListViewItemVisible(int position) {
        int first = mCategoryList.getFirstVisiblePosition();
        int last = mCategoryList.getLastVisiblePosition();
        return first <= position && position <= last;
    }

    private DownloadingAdapter.ViewHolder getViewHolder(int position) {
        int childPosition = position - mCategoryList.getFirstVisiblePosition();
        View view = mCategoryList.getChildAt(childPosition);
        return (DownloadingAdapter.ViewHolder) view.getTag();
    }

    private int getAdapterItemPosition(String id) {
        for (int position = 0; position < downloadQueue.size(); position++)
            if (downloadQueue.get(position).getItem_id().equalsIgnoreCase(id))
                return position;
        return 0;
    }
    //Downloading Service calls and receiver methods ends


}
