package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.AppHelper;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.VolleyMultipartRequest;
import com.squareup.picasso.Picasso;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;

public class ProfileDetailFragment extends MasterFragment {
    private MainActivity mContext;
    private TextView edit,titlename,FullName,Mobilenumber,datebirth,Email,Address;
    private String mContent;
    private Button ChangePassword;
    private String textColor,backgroundColor;
    private SessionManager sessionManager;
    private CircleImageView profile_image,img_plus;
    private String UseridSt;
    private static final int PICKFILE_RESULT_CODE = 1;
    private static final int REQUEST_IMAGE = 100;
    private String Path;
    private File destination;
    String nameSt,mobileST,addressST,dobST,user_idST,picST,emailST;
    private String Fiximge;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.layout_profile, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setHasOptionsMenu(true);
        mContext = (MainActivity) getMasterActivity();
       // mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle("Profile");
        sessionManager=new SessionManager(getMasterActivity());
        ChangePassword=view.findViewById(R.id.ChangePassword);
        edit=view.findViewById(R.id.edit);
        titlename=view.findViewById(R.id.titlename);
        FullName=view.findViewById(R.id.FullName);
        Mobilenumber=view.findViewById(R.id.Mobilenumber);
        datebirth=view.findViewById(R.id.datebirth);
        profile_image=view.findViewById(R.id.profile_image);
        UseridSt=sessionManager.getKEY_Userid();
        img_plus=view.findViewById(R.id.img_plus);
        Email=view.findViewById(R.id.Email);
        Address=view.findViewById(R.id.Address);


        ChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mContext.ReplaceFragment(new ChangePasswordFragment());
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mContext.ReplaceFragment(new EditProfileFragments());
            }
        });

        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        if (mContext.isInternet) {
            getCategory();
        } else {
            String ImagePath=sessionManager.getKEY_image();
            Picasso.with(getMasterActivity()).load(ImagePath).into(profile_image);
            titlename.setText(sessionManager.getKEY_name());
            FullName.setText(sessionManager.getKEY_name());
            Mobilenumber.setText(sessionManager.getKEY_mobile());
            datebirth.setText(sessionManager.getKEY_dob());
            Email.setText(sessionManager.getKEY_email());
            Address.setText(sessionManager.getKEY_address());
            ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
        }
        textColor=getResources().getString(R.color.primaryTextColor).substring(3);
        backgroundColor=getResources().getString(R.color.colorPrimary).substring(3);
        //Log.e("textColor",textColor +"& backgroundColor="+backgroundColor);
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        mContext.action_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SearchFragment searchFragment = new SearchFragment();
                mContext.ReplaceFragment(searchFragment);
            }
        });
        img_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPictureDialog();

            }
        });

    }
    private void showPictureDialog() {

        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(getActivity());
        pictureDialog.setTitle("Select Action");
        final CharSequence[] pictureDialogItems = {"Remove Photo","Take Photo","Choose from Gallery"};
        pictureDialog.setItems(pictureDialogItems, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case 0:
                        Picasso.with(mContext).load(R.drawable.ic_profile_edit).into(profile_image);
                        break;
                    case 1:
                        TakePhotoFromCamera();

                        break;
                    case 2:
                        ChoosePhotoFromGallery();

                        break;
                }
            }
        });
        pictureDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        pictureDialog.show();
    }
    private void ChoosePhotoFromGallery() {

        Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent,PICKFILE_RESULT_CODE);
    }
    private void TakePhotoFromCamera() {

        Intent it=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(it,REQUEST_IMAGE);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.menu_edit, menu);

        super.onCreateOptionsMenu(menu, inflater);
    }
    @Override

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_edit) {
            Toast.makeText(getActivity(), "Message clicked!", Toast.LENGTH_SHORT).show();
            return true;

        }

        return super.onOptionsItemSelected(item);
    }


    private void getCategory() {

        mContext.showWaitIndicator(true);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.user_ID, sessionManager.getKEY_Userid()));
        dishRequest.sendRequest(Constants.API_user_deatil,
                carData, catCallback);
    }


    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {
            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        JSONArray data = jObject.getJSONArray("data");
                        Log.d("data.length()", "" + data.length());

                        String name=data.getJSONObject(0).getString("name");
                        String mobile=data.getJSONObject(0).getString("mobile");
                        String email=data.getJSONObject(0).getString("email");
                        String address=data.getJSONObject(0).getString("address");
                        String dob=data.getJSONObject(0).getString("dob");
                        String image=data.getJSONObject(0).getString("image");


                        Picasso.with(getMasterActivity()).load(image).into(profile_image);
                        titlename.setText(name);
                        FullName.setText(name);
                        Mobilenumber.setText(mobile);
                        datebirth.setText(dob);
                        Email.setText(email);
                        Address.setText(address);
                        sessionManager.logoutUser();
                        sessionManager.createLoginSession(UseridSt,name,mobile,address,dob,image,email);



                    }else{
                        ToastUtil.showLongToastMessage(getMasterActivity(),
                                getString(R.string.check_if_you_are_connected_to_network));
                    }
                }

            } catch (Exception e) {
                mContext.showWaitIndicator(false);
                e.printStackTrace();
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);

        }
    };

    public void EditPostPrductInfo() {

        mContext.showWaitIndicator(true);
        String url = Constants.API_update_user;
        VolleyMultipartRequest multipartRequest = new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                mContext.showWaitIndicator(false);
                //   sessionManager.UpdateKEY_name(nameSt);
                Toast.makeText(getMasterActivity(), " Profile photo updated", Toast.LENGTH_LONG).show();
                mContext.onBackPressed();
               /* try {
                    JSONObject jObject = new JSONObject(response.toString());
                    mContext.onBackPressed();
                   *//* String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        Toast.makeText(getMasterActivity(), " Save", Toast.LENGTH_LONG).show();
                        mContext.onBackPressed();
                    } else {
                        Toast.makeText(getMasterActivity(), "No Data Save", Toast.LENGTH_LONG).show();
                        mContext.showWaitIndicator(false);
                    }*//*
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
                NetworkResponse networkResponse = error.networkResponse;
                String errorMessage = "Unknown error";
                if (networkResponse == null) {
                    if (error.getClass().equals(TimeoutError.class)) {
                        errorMessage = "Request timeout";
                    } else if (error.getClass().equals(NoConnectionError.class)) {
                        errorMessage = "Failed to connect server";
                    }
                } else {
                    String result = new String(networkResponse.data);
                    try {
                        JSONObject response = new JSONObject(result);
                        String status = response.getString("status");
                        String message = response.getString("message");

                        Log.e("Error Status", status);
                        Log.e("Error Message", message);

                        if (networkResponse.statusCode == 404) {
                            errorMessage = "Resource not found";
                        } else if (networkResponse.statusCode == 401) {
                            errorMessage = message+" Please login again";
                        } else if (networkResponse.statusCode == 400) {
                            errorMessage = message+ " Check your inputs";
                        } else if (networkResponse.statusCode == 500) {
                            errorMessage = message+" Something is getting wrong";
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Log.i("Error", errorMessage);
                error.printStackTrace();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();


                nameSt = FullName.getText().toString().trim();
                mobileST = Mobilenumber.getText().toString().trim();
                addressST = sessionManager.getKEY_address();
                dobST = datebirth.getText().toString().trim();
                user_idST=sessionManager.getKEY_Userid();
                picST = Path;

                //  emailST =sessionManager.getKEY_email();

                if(picST==null){
                    Fiximge=sessionManager.getKEY_image();
                }else {
                    Fiximge=picST;
                }


                params.put("user_id",user_idST);
                params.put("name", nameSt);
                params.put("mobile", mobileST);
                params.put("email", emailST);
                params.put("address", addressST);
                params.put("dob", dobST);
                params.put("pic",Fiximge);

                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                // file name could found file base or direct access from real path
                // for now just get bitmap data from ImageView
                String filename=Path+".jpg";
                params.put("pic", new DataPart(filename, AppHelper.getFileDataFromDrawable(getMasterActivity(), profile_image.getDrawable()), "image/png"));
                return params;
            }
        };

        Volley.newRequestQueue(getMasterActivity()).add(multipartRequest);

    }
}
