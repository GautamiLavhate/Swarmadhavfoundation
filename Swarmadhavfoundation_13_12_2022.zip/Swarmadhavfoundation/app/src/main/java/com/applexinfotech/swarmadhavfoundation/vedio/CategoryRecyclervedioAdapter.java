package com.applexinfotech.swarmadhavfoundation.vedio;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CategoryRecyclervedioAdapter extends RecyclerView.Adapter<CategoryRecyclervedioAdapter.MyViewHolder> {
    MainActivity mContext;
    ArrayList<HomeModel> catArrayList;
    RecyclerView categoryRecycler;

    public CategoryRecyclervedioAdapter(MainActivity mContext, ArrayList<HomeModel> catArrayList, RecyclerView categoryRecycler) {
        this.mContext = mContext;
        this.catArrayList = catArrayList;
        this.categoryRecycler = categoryRecycler;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.category_recycler_item, parent, false);
        // view.setOnClickListener(mOnClickListener);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final HomeModel homeModel = catArrayList.get(position);

        if (homeModel != null) {
            String TypeHMSt = homeModel.getTypeHm();
            if (TypeHMSt.equals("Video")) {
                holder.itemView.setVisibility(View.VISIBLE);
                holder.folderLinearLayout.setVisibility(View.VISIBLE);
                holder.catTextView.setTypeface(mContext.getTypeFace());
                holder.catTextView.setText(homeModel.getCategory_name());
                holder.catImgView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                if (homeModel.getCategory_image().startsWith("https")) {
                    Picasso.with(mContext).load(homeModel.getCategory_image()).into(holder.catImgView);
                } else if (homeModel.getCategory_image() != null) {
                    Bitmap bitmap = BitmapFactory.decodeFile(homeModel.getCategory_image());
                    holder.catImgView.setImageBitmap(bitmap);
                }


                holder.catImgView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (InternetStatus.isInternetOn(mContext)) {

                            String CategorySub = catArrayList.get(position).getIsSubcategoryAvailable();
                            if(CategorySub==null){
                                Fragment categoryList = new CategoryFragmentVedio();
                                Bundle bundle = new Bundle();
                                bundle.putSerializable("CAT_ID", homeModel);
                                categoryList.setArguments(bundle);
                                mContext.ReplaceFragment(categoryList);
                            }else {
                                if (CategorySub.equals("0")) {
                                    Fragment categoryList = new CategoryFragmentVedio();
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("CAT_ID", homeModel);
                                    categoryList.setArguments(bundle);
                                    mContext.ReplaceFragment(categoryList);
                                } else if (CategorySub.equals("1")) {
                                    Fragment categoryList = new SubCategoryFolderVideoFragment();
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("CAT_ID", homeModel);
                                    categoryList.setArguments(bundle);
                                    mContext.ReplaceFragment(categoryList);
                                }
                            }
                        } else {
                            Fragment categoryList = new CategoryFragmentVedio();
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("CAT_ID", homeModel);
                            categoryList.setArguments(bundle);
                            mContext.ReplaceFragment(categoryList);
                        }
                    }
                });

            } else {
                holder.itemView.setVisibility(View.GONE);
                holder.folderLinearLayout.setVisibility(View.GONE);

            }
        }
    }


    @Override
    public int getItemCount() {
        return catArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView catTextView;
        private ImageView catImgView;
        private LinearLayout folderLinearLayout;

        public MyViewHolder(View itemView) {
            super(itemView);
            catImgView = (ImageView) itemView.findViewById(R.id.cat_image);
            catTextView = (TextView) itemView.findViewById(R.id.cat_name);
            folderLinearLayout= itemView.findViewById(R.id.folderLinearLayout);
        }
    }
}
