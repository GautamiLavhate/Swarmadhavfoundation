package com.applexinfotech.swarmadhavfoundation.adapter;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;

import java.util.ArrayList;

public class PlayListAdapter extends RecyclerView.Adapter<PlayListAdapter.MyViewHolder> {
    final MainActivity mContext;
    final ArrayList<Playlist> playList;
    private final OnItemClickListener mListener;
    final SubCategoryModel selectedSong;
    final boolean isFromDialog;

    public PlayListAdapter(MainActivity context, ArrayList<Playlist> list, OnItemClickListener listener, SubCategoryModel categoryModel, boolean isDialog) {
        this.mContext = context;
        this.playList = list;
        mListener= listener;
        selectedSong=categoryModel;
        isFromDialog=isDialog;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.playlist_item, parent, false);
        return new PlayListAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        if (playList != null) {
            String  playlisttype=playList.get(position).getType();
            if(playlisttype.equals("Audio")) {
            holder.rootView.setVisibility(View.VISIBLE);
            if(isFromDialog){
                holder.deletePlaylist.setVisibility(View.GONE);
            }else{
                holder.deletePlaylist.setVisibility(View.VISIBLE);
            }
                //holder.playListName.setTypeface(mContext.getTypeFace());
                holder.playListName.setText(playList.get(position).getName());
                holder.songCount.setTypeface(mContext.getTypeFace());
                int noOffSongs = playList.get(position).getSongs().size();
                String songCount = String.valueOf(noOffSongs) + " " + "Songs";
                holder.songCount.setText(songCount);
                holder.rootView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mListener.onItemClick(v, position, selectedSong);
                    }
                });

                holder.deletePlaylist.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mListener.onItemClick(v, position, selectedSong);
                    }
                });
            }else {
                holder.rootView.setVisibility(View.GONE);
            }
        }
        }


    @Override
    public int getItemCount() {
        return playList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final TextView playListName;
        private final TextView songCount;
        final LinearLayout rootView;
        final ImageButton deletePlaylist;

        public MyViewHolder(View itemView) {
            super(itemView);
            rootView=itemView.findViewById(R.id.root_playlist);
            playListName=itemView.findViewById(R.id.tv_playlist_name);
            songCount=itemView.findViewById(R.id.tv_song_count);
            deletePlaylist=itemView.findViewById(R.id.delete_playlist);
        }
    }
}
