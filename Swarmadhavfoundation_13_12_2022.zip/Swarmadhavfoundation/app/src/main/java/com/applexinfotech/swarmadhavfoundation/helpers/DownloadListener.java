package com.applexinfotech.swarmadhavfoundation.helpers;

import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;

/**
 * Created by JD Android on 11-Aug-18.
 */

public interface DownloadListener
{
    void onDownloadsBroadcastUpdate(SubCategoryModel subCategoryModel,int position);
}
