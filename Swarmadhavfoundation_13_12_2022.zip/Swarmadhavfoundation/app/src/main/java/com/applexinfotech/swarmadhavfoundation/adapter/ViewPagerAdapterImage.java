package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.toolbox.ImageLoader;
import com.applexinfotech.swarmadhavfoundation.CustomVolleyRequeat;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.model.SliderUtils;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ViewPagerAdapterImage extends PagerAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<SliderUtils> sliderImg;
    private ImageLoader imageLoader;


    // Array of images
    //Integer[] images={R.drawable.imagefirst,R.drawable.imagesecond,R.drawable.imagethird};

    // Layout Inflater
    LayoutInflater mLayoutInflater;

    // Viewpager Constructor
    public ViewPagerAdapterImage(ArrayList sliderImg,Context context) {
        this.sliderImg=sliderImg;
        this.context = context;

    }


    @Override
    public int getItemPosition(@NonNull Object object) {
        return super.getItemPosition(object);
    }

    @Override
    public int getCount() {
        // return the number of images
        return sliderImg.size();
        //return (null != sliderImg ? sliderImg.size() : 0);
        //return Integer.MAX_VALUE;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }
    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container,final int position) {
        layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view=layoutInflater.inflate(R.layout.layout_image_view,null);
        SliderUtils utils=sliderImg.get(position);
        ImageView imageView = (ImageView) view.findViewById(R.id.img_view_slider);
        imageLoader=CustomVolleyRequeat.getInstance(context).getImageLoader();
        //imageLoader.get(utils.getFootersliderImageUrl(),imageLoader.getImageListener(imageView,R.drawable.new_launching_logo, android.R.drawable.ic_dialog_alert));
        Glide.with(view.getContext())
                .load(utils.getSliderImageUrl())
                .into(imageView);

        ViewPager vp=(ViewPager) container;
        vp.addView(view,0);
        return view;
//        mLayoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//
//
//        imageView.setImageResource(images[position]);
//        ViewPager vp=(ViewPager)container;
//        vp.addView(view,0);
//        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        ViewPager vp = (ViewPager) container;
        View view = (View) object;
        vp.removeView(view);
    }


}
