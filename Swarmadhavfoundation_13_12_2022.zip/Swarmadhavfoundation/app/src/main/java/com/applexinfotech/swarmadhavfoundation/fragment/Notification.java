package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.NotificationAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.fcm.DataBaseAdapter;
import com.applexinfotech.swarmadhavfoundation.fcm.Models;
import com.applexinfotech.swarmadhavfoundation.fcm.Notifictable;
import com.applexinfotech.swarmadhavfoundation.model.NotificationRecord;


import java.util.ArrayList;
import java.util.List;

import com.google.android.gms.ads.InterstitialAd;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2018.
 */
public class Notification extends MasterFragment {
    MainActivity mContext;
    ListView listView_notification;
    NotificationAdapter adapter;
    LinearLayout ll_nodata;
    TextView text_nonotifiction;
    private DataBaseAdapter dba;
    private Models models;
    private InterstitialAd interstitial;
    SessionManager session;
    Models mod;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
    {
        mContext =  (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.notification_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.notification));

        listView_notification = view.findViewById(R.id.listView_notification);
        models=new Models();
        dba=new DataBaseAdapter(getMasterActivity());
        ll_nodata = view.findViewById(R.id.ll_nodata);

        text_nonotifiction = view.findViewById(R.id.text_nonotifiction);
        text_nonotifiction.setTypeface(mContext.getTypeFace());
        mod = new Models();
        ArrayList<NotificationRecord> notif = GeatNotiDisplay();

        if(notif.size() > 0)
            {
                ll_nodata.setVisibility(View.GONE);
                listView_notification.setVisibility(View.VISIBLE);

                adapter = new NotificationAdapter(mContext,R.layout.notification_list_item, notif);
                listView_notification.setAdapter(adapter);
            }
            else
            {
                listView_notification.setVisibility(View.GONE);
                ll_nodata.setVisibility(View.VISIBLE);
            }

        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

    }

    ArrayList<NotificationRecord> GeatNotiDisplay() {
        ArrayList<NotificationRecord> results = new ArrayList<NotificationRecord>();
        NotificationRecord sr = new NotificationRecord();
        try {
            dba.open();
            String sql = "select * from Notifictable";
            Cursor cur = DataBaseAdapter.ourDatabase.rawQuery(sql, null);
            Log.w("CA", "SQL1 :" + sql);
            if (cur.getCount() > 0) {
                while (cur.moveToNext()) {
                    sr = new NotificationRecord();
                    sr.setTitle(cur.getString(cur.getColumnIndex("title")));
                    sr.setDescription(cur.getString(cur.getColumnIndex("description")));
                    sr.setNotification_image(cur.getString(cur.getColumnIndex("notification_image")));
                    results.add(sr);
                }
            }  else {
                Toast.makeText(getMasterActivity(), "No Data", Toast.LENGTH_LONG).show();
            }
            dba.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  results;
    }

}
