package com.applexinfotech.swarmadhavfoundation.AddVideoPlay;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.MusicStateListener;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.vedio.CategoryFragmentVedioAdapter;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;

import java.util.ArrayList;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_ASSETS;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_PLAYLIST;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_RECENTLY_PLAYED;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.IS_FROM;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.PLAYLIST_ID;

public class VedioSongList extends MasterFragment implements OnItemClickListener<SubCategoryModel>, DownloadListener, MusicStateListener {
    MainActivity mContext;
    ArrayList<SubCategoryModel> CatListItem = new ArrayList<>();
    final HomeModel homeModel = new HomeModel();
    private RecyclerView mCategoryList;
    private Bundle bundle;
    public CategoryFragmentVedioAdapter Adapter;
    InterstitialAd interstitial;
    public static RelativeLayout topContainer;
    private LinearLayout noSongFoundView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private Parcelable state;
    private String isFrom;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<Object> categoryListWIthAd = new ArrayList<>();
    private static int ITEMS_PER_AD = 6;
    private static final int LIST_NO_AD_DELTA = 0; //when no internet
    public ArrayList<SubCategoryModel> mItem = new ArrayList<>();
    ArrayList<Integer> addPositionList = new ArrayList<>();
    // The AdLoader used to load ads.
    private AdLoader adLoader;
    // List of native ads that have been successfully loaded.
    private List<UnifiedNativeAd> mNativeAds = new ArrayList<>();
    Playlist playlist;
    int playlistId;
    String TypeString;


    private static String canonicalName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContext = (MainActivity) getMasterActivity();
        mContext.showWaitIndicator(false);
        ((MainActivity) getActivity()).setMusicStateListenerListener(this);
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        return inflater.inflate(R.layout.fragment_category, container, false);
    }


    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

       // mContext.hideDrawer();
        mContext.showDrawerBack();
        mCategoryList = view.findViewById(R.id.listView_cat_list);
        noSongFoundView = view.findViewById(R.id.noItemFound);

        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity()) || isFrom.equals(FROM_ASSETS)) {
                    Log.e("server request data", "=");
                    loadDataFromMaster();

                } else {
                    ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
                    showListView(false);
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        bundle = getArguments();

        if (bundle != null) {
            isFrom = bundle.getString(IS_FROM);
            if (isFrom.equals(FROM_PLAYLIST)) {
                if (bundle.containsKey(PLAYLIST_ID)) {
                    playlistId =  bundle.getInt(PLAYLIST_ID);
                    TypeString=bundle.getString("Type");
                    playlist=new RealmHelper().retrievePlaylist(playlistId,TypeString);
                }
            }
        }

        isInternet = InternetStatus.isInternetOn(mContext);


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });
        // Set new items
        if (!isFrom.equals(FROM_RECENTLY_PLAYED)) {
            loadCategoryData();
        }
    }


    private void loadCategoryData() {
        if (InternetStatus.isInternetOn(getMasterActivity()) || isFrom.equals(FROM_ASSETS)) {
            Log.e("server request data", "=");
            if(MasterActivity.songListWithAd.isEmpty()){
                loadDataFromMaster();
            }else{
                categoryListWIthAd = new ArrayList<>();
                categoryListWIthAd.addAll(MasterActivity.songListWithAd);
                Log.e(" existing ARRAY =", String.valueOf(categoryListWIthAd.size()));
                setAdapterData(ITEMS_PER_AD);
            }

        } else {
            ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
            showListView(false);
        }
    }

    private void loadDataFromMaster() {
        if (!isFrom.isEmpty()) {
            CatListItem = new ArrayList<>();
            canonicalName= VedioSongList.this.getClass().getCanonicalName();
            switch (isFrom) {
                case FROM_RECENTLY_PLAYED:
                    MasterActivity.title = getString( R.string.recently_played);
                    CatListItem = new RealmHelper().retrieveRecentlyPlayedList(0);
                    break;
                case FROM_PLAYLIST:
                    if (playlist != null) {
                        MasterActivity.title = playlist.getName();
                        CatListItem = new RealmHelper().retrievePlayListSongs(playlist.getId());
                        canonicalName = FROM_PLAYLIST;
                    }
                    break;
            }
            setListAdapter();
        } else {
            showListView(false);
        }


    }

    private void setListAdapter() {
        if (CatListItem.isEmpty()) {
            showListView(false);
            return;
        } else {
            categoryListWIthAd = new ArrayList<>();
            categoryListWIthAd.addAll(CatListItem);

            setAdapterData(0);

        }
    }

    private void setAdapterData(int itemsPerAd) {
        mContext.setTitle(MasterActivity.title);
        mContext.showWaitIndicator(false);
        // Notify the List that the DataSet has changed...
        if (categoryListWIthAd.isEmpty()) {
            showListView(false);
        } else {
            showListView(true);
            MasterActivity.songListWithAd=new ArrayList<>();
            MasterActivity.songListWithAd.addAll(categoryListWIthAd);
            Adapter = new CategoryFragmentVedioAdapter(mContext,categoryListWIthAd,homeModel,canonicalName);
            mCategoryList.setAdapter(Adapter);
            mCategoryList.setLayoutManager(linearLayoutManager);
            Adapter.setOnItemClickListener(VedioSongList.this);
            if(isFrom.equals(FROM_PLAYLIST)){
                Adapter.setSelectedPlaylist(playlist);
            }
            Adapter.notifyDataSetChanged();
        }
    }

    public void showListView(boolean flag) {
        if (flag) {
            mCategoryList.setVisibility(View.VISIBLE);
            noSongFoundView.setVisibility(View.GONE);

        } else {
            mCategoryList.setVisibility(View.GONE);
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }


    @Override
    public void onStop() {
        super.onStop();
        Utilities.hideKeyboard(getMasterActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Utilities.hideKeyboard(getMasterActivity());
    }


    //Downloading Service calls and receiver methods
    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                downloadQueue(selectedObject, position);
                //  mContext.loadRewardedVideoAd();
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    public void downloadQueue(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.startDownloading(subCategoryModel, position);
            }
        }
    }


    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (VedioSongList.this.isVisible()) {
            if (tmpInfo == null || position == -1) {
                return;
            }
            final int status = tmpInfo.getStatus();
            switch (status) {
                case SubCategoryModel.STATUS_COMPLETE:
                    if (Adapter != null) {
                        Log.e("SongsList", "notified");
                        Adapter.notifyDataSetChanged();
                    }
                    break;
            }
        }
    }

    @Override
    public void restartLoader() {
        if (VedioSongList.this.isVisible()) {
            Log.e("ReloadRecentRecycler", "notified");
            if (isFrom.equals(FROM_RECENTLY_PLAYED)) {
                loadDataFromMaster();
            }
        }
    }

    @Override
    public void stopProgressHandler() {

    }

    @Override
    public void onMetaChanged() {

    }


    @Override
    public void onResume() {
        super.onResume();
        if (isFrom.equals(FROM_RECENTLY_PLAYED)) {
            loadDataFromMaster();
        }
    }
}

