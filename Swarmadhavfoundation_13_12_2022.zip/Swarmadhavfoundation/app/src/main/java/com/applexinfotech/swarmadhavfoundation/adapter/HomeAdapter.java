package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.fragment.CategoryFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.SubCategoryFolderAudioFragments;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2018.
 */
public class HomeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    private final LayoutInflater layoutInflater;

    // The list of banner ads and menu items.
    private ArrayList<Object> recyclerViewItems;
    private final MainActivity mContext;
    private static  int LIST_AD_DELTA = 0;
    private static final int CONTENT = 0;
    private static final int AD = 1;
    // A menu item view type.
    private static final int MENU_ITEM_VIEW_TYPE = 0;

    // The banner ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;
    private final RecyclerView mRecyclerView;

    private final int resource;
    private final View.OnClickListener mOnClickListener = new MyOnClickListener();

    public HomeAdapter(MainActivity context, int resource, ArrayList<Object> list, RecyclerView recyclerView)
    {
        mContext = context;
        this.recyclerViewItems = list;
        Log.e("noOfItem", String.valueOf(recyclerViewItems.size()));
        this.resource = resource;
        mRecyclerView=recyclerView;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getItemViewType(int position) {
        int viewType = MENU_ITEM_VIEW_TYPE;
       /* if (LIST_AD_DELTA != 0) {   // LIST_AD_DELTA will be 0  when showListBannerAd=false in constants OR noInternet
            Object recyclerViewItem = recyclerViewItems.get(position);
            if (recyclerViewItem instanceof UnifiedNativeAd) {
                viewType = UNIFIED_NATIVE_AD_VIEW_TYPE;
            }
        }*/
        return viewType;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
           /* case UNIFIED_NATIVE_AD_VIEW_TYPE:
                View unifiedNativeLayoutView = LayoutInflater.from(
                        parent.getContext()).inflate(R.layout.,
                        parent, false);
                return new UnifiedNativeAdViewHolder(unifiedNativeLayoutView);*/
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                View menuItemLayoutView = LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.category_item, parent, false);
                menuItemLayoutView.setOnClickListener(mOnClickListener);
                return new MenuItemViewHolder(menuItemLayoutView);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
          /*  case UNIFIED_NATIVE_AD_VIEW_TYPE:
                UnifiedNativeAd nativeAd = (UnifiedNativeAd) recyclerViewItems.get(position);
                populateNativeAdView(nativeAd, ((UnifiedNativeAdViewHolder) holder).getAdView());
                break;*/
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                MenuItemViewHolder menuItemHolder = (MenuItemViewHolder) holder;
                HomeModel content = (HomeModel) recyclerViewItems.get(position);
                String TypeHMSt = content.getTypeHm();
                if (TypeHMSt.equals("Audio")) {
                    menuItemHolder.folderLinearLayout.setVisibility(View.VISIBLE);
                    menuItemHolder.folderFrameLayout.setVisibility(View.VISIBLE);
                    menuItemHolder.text_cat_name.setTypeface(mContext.getTypeFace());
                    menuItemHolder.text_cat_name.setText(content.getCategory_name());

                    if (InternetStatus.isInternetOn(mContext)) {
                        Picasso.with(mContext).load(content.getCategory_image()).into(menuItemHolder.imageView_cat);
                    } else {
                        if (content.getCategory_image() != null) {
                            Bitmap bitmap = BitmapFactory.decodeFile(content.getCategory_image());
                            if (bitmap != null) {
                                menuItemHolder.imageView_cat.setImageBitmap(bitmap);
                            } else {
                                Picasso.with(mContext).load(content.getCategory_image()).placeholder(R.drawable.no_image).fit().into(menuItemHolder.imageView_cat);
                            }
                        }
                    }
                }else {
                    menuItemHolder.folderLinearLayout.setVisibility(View.GONE);
                    menuItemHolder.folderFrameLayout.setVisibility(View.GONE);
                }
                break;
        }
    }

    @Override
    public int getItemCount() {
        return recyclerViewItems.size();
    }


    class MenuItemViewHolder extends RecyclerView.ViewHolder {
        private FrameLayout folderFrameLayout;
        private final ImageView imageView_cat;
        private final TextView text_cat_name;
        private LinearLayout folderLinearLayout;



        MenuItemViewHolder(View itemView) {
            super(itemView);
             imageView_cat = itemView.findViewById(R.id.imageView_cat);
             text_cat_name = itemView.findViewById(R.id.text_cat_name);
             folderLinearLayout= itemView.findViewById(R.id.folderLinearLayout);
            folderFrameLayout= itemView.findViewById(R.id.folderFrameLayout);
            
        }
    }

    private class MyOnClickListener implements View.OnClickListener {
        private HomeModel homeModel;

        @Override
        public void onClick(View v) {
            int itemPosition = mRecyclerView.getChildLayoutPosition(v);
            MasterActivity.songWithAd=new ArrayList<>();
            if(recyclerViewItems.get(itemPosition) instanceof HomeModel){
                 homeModel = (HomeModel) recyclerViewItems.get(itemPosition);

                mContext.bundle = new Bundle();
                if (InternetStatus.isInternetOn(mContext)) {
                    MasterActivity.songWithAd = new ArrayList<>();
                    String CategorySub=homeModel.getIsSubcategoryAvailable();
                    if(CategorySub.equals("0")){
                        Fragment categoryList = new CategoryFragment();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("CAT_ID", homeModel);
                        categoryList.setArguments(bundle);
                        mContext.ReplaceFragment(categoryList);
                    }else if(CategorySub.equals("1")){
                        Fragment categoryList = new SubCategoryFolderAudioFragments();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("CAT_ID", homeModel);
                        categoryList.setArguments(bundle);
                        mContext.ReplaceFragment(categoryList);
                    }
                } else {
                    Fragment investProgramDetail = new  CategoryFragment();
                    Bundle bundle = new Bundle();
                    for(int i=0;i<HomeFragment.realmArray.size();i++){
                        if(HomeFragment.realmArray.get(i).getCategory_id().equalsIgnoreCase(homeModel.getCategory_id())){
                            bundle.putSerializable("CAT_ID", HomeFragment.realmArray.get(i));
                            break;
                        }
                    }
                    investProgramDetail.setArguments(bundle);
                    mContext.ReplaceFragment(investProgramDetail);
                }
            }

        }
    }

    public void refresh(){
        notifyDataSetChanged();
    }
}
