package com.applexinfotech.swarmadhavfoundation.fragment;

import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.CategoryAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchAudioMainAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchSubcategoryAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchviedoAudioSongListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.CustomEditText;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.DrawableClickListener;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;
import com.applexinfotech.swarmadhavfoundation.vedio.SearchVedioMainAdapter;
import com.applexinfotech.swarmadhavfoundation.vedio.SearchVideoSubCategoyAdapter;
import com.google.android.gms.ads.InterstitialAd;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class SearchFragment extends MasterFragment {

    MainActivity mContext;
    ArrayList<SubCategoryModel> CatListItem = new ArrayList<>();
    HomeModel homeModel = new HomeModel();
    private RecyclerView AudioCategories_search_typeRe,AudioSub_search_type2Re,AudioSongs_search_type2Re,
            VideoCategories_search_type2Re,video_sub_rev_search_type2Re,video_song_search_type2;

    private LinearLayout AudioCategoriesLi,AudioSubCategoriesli,AudioSongsLi,
            VideoCategoriesLi,VideoSubCategoriesLi,VideoSongsLi;
    private String category_id;
    private Bundle bundle;
    private CategoryAdapter Adapter;

    InterstitialAd interstitial;
    private CustomEditText searchView;

    private LinearLayout noSongFoundView;
    private CardView searchCardView;
    public ArrayList<SubCategoryModel> mItem = new ArrayList<>();
    public String lastSearchedString = "";
    TextView noSongFoundTv;
    NestedScrollView nestedScrollView;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
      //  ((MainActivity) getActivity()).setDownloadStateListener(this);

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //mContext.hideDrawer();
        mContext.showDrawerBack();

        mContext.setTitle(getString(R.string.search));

        AudioCategoriesLi=view.findViewById(R.id.AudioCategoriesLi);
        AudioSubCategoriesli=view.findViewById(R.id.AudioSubCategoriesli);
        AudioSongsLi=view.findViewById(R.id.AudioSongsLi);
        VideoCategoriesLi=view.findViewById(R.id.VideoCategoriesLi);
        VideoSubCategoriesLi=view.findViewById(R.id.VideoSubCategoriesLi);
        VideoSongsLi=view.findViewById(R.id.VideoSongsLi);
        nestedScrollView=view.findViewById(R.id.nestedScrollView);


        AudioCategories_search_typeRe=view.findViewById(R.id.AudioCategories_search_type);
        AudioSub_search_type2Re=view.findViewById(R.id.AudioSub_search_type2);
        AudioSongs_search_type2Re=view.findViewById(R.id.AudioSongs_search_type2);
        VideoCategories_search_type2Re=view.findViewById(R.id.VideoCategories_search_type2);
        video_sub_rev_search_type2Re=view.findViewById(R.id.video_sub_rev_search_type2);
        video_song_search_type2=view.findViewById(R.id.video_song_search_type2);


        searchView = view.findViewById(R.id.search_view);
        searchCardView = view.findViewById(R.id.search_card_view);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        noSongFoundTv = view.findViewById(R.id.noSongFoundTv);
        searchView.requestFocus();
        Utilities.showKeyboard(getMasterActivity());
        bundle = getArguments();

        if (bundle != null) {
            homeModel = (HomeModel) bundle.getSerializable("CAT_ID");
            category_id = homeModel.getCategory_id();
        }

        searchView.setDrawableClickListener(new DrawableClickListener() {
            public void onClick(DrawableClickListener.DrawablePosition target) {
                switch (target) {
                    case RIGHT:
                        //Do something here
                        searchView.setText("");
                        showListView(true);
                        break;
                }
            }

        });

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Utilities.hideKeyboard(getMasterActivity());
            }
        });

        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() == 0) {
                    Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_search);

                    mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.hintTextColor), PorterDuff.Mode.MULTIPLY));

                    searchView.setCompoundDrawablesWithIntrinsicBounds(mDrawable, null, null, null);

                } else {
                    Drawable img = ContextCompat.getDrawable(mContext,R.drawable.ic_cancel);
                    Drawable mDrawable = ContextCompat.getDrawable(mContext,R.drawable.ic_search);

                    img.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.hintTextColor), PorterDuff.Mode.MULTIPLY));
                    mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.hintTextColor), PorterDuff.Mode.MULTIPLY));

                    searchView.setCompoundDrawablesWithIntrinsicBounds(mDrawable, null, img, null);
                }
                //after the change calling the method and passing the search input

                if (!editable.toString().equalsIgnoreCase("") /*|| editable.length()>3*/) {
                    lastSearchedString = editable.toString();
                    loadCategoryData();
                }

            }
        });

        isInternet = InternetStatus.isInternetOn(mContext);


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });
    }


    private void getSearchedSongList(String searchKey) {
        // this.mContext.showWaitIndicator(true);
        Log.e("searchKey", "=" + searchKey);
        //network request
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.title, searchKey));
        dishRequest.sendRequest(Constants.API_SEARCH_SONG_STATUS_URL, carData, searchCallback);
        //network request
    }

    final NetworkRequest.NetworkRequestCallback searchCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            // mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());

                    String status = jObject.optString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        JSONObject data = jObject.getJSONObject("data");
                        JSONArray audio_list= data.getJSONArray("audio_list");
                        ArrayList<SubCategoryModel> audio_listItem = new ArrayList<>();
                        Log.d("data.length()", "" + audio_list.length());
                        if(!(audio_list.length()==0)) {
                            for (int i = 0; i < audio_list.length(); i++) {
                                AudioSongsLi.setVisibility(View.VISIBLE);
                                SubCategoryModel categoryModel = new SubCategoryModel();
                                categoryModel.setItem_id(audio_list.getJSONObject(i).getString("audio_id")+"audio_id");
                                categoryModel.setItem_name(audio_list.getJSONObject(i).getString("audio_title"));
                                categoryModel.setItem_description(audio_list.getJSONObject(i).getString("audio_description"));
                                categoryModel.setItem_file(audio_list.getJSONObject(i).getString("audio_file"));
                                categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                                categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("audio_title"));
                                categoryModel.setLyrics_file(audio_list.getJSONObject(i).getString("audio_lyrics"));
                                categoryModel.setLyrics_filePdf(audio_list.getJSONObject(i).getString("pdf_file"));
                                categoryModel.setCategory_id(audio_list.getJSONObject(i).getString("audio_category_id"));
                                categoryModel.setUpdate_count(audio_list.getJSONObject(i).getString("update_count"));
                                categoryModel.setVideo_url("null");
                                audio_listItem.add(categoryModel);
                            }
                            SearchviedoAudioSongListAdapter audio_listItemAdaptervi = new SearchviedoAudioSongListAdapter(mContext, audio_listItem, AudioSongs_search_type2Re);
                            AudioSongs_search_type2Re.setAdapter(audio_listItemAdaptervi);
                            AudioSongs_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            AudioSongsLi.setVisibility(View.GONE);
                        }

                        ArrayList<SubCategoryModel> video_listItem = new ArrayList<>();
                        JSONArray video_list= data.getJSONArray("video_list");

                        if(!(video_list.length()==0)) {
                            for (int j = 0; j < video_list.length(); j++) {
                                VideoSongsLi.setVisibility(View.VISIBLE);
                                SubCategoryModel categoryModel1 = new SubCategoryModel();
                                categoryModel1.setItem_id(video_list.getJSONObject(j).getString("video_id"));
                                categoryModel1.setItem_name(video_list.getJSONObject(j).getString("video_title"));
                                categoryModel1.setItem_description(video_list.getJSONObject(j).getString("video_description"));
                                categoryModel1.setItem_file(video_list.getJSONObject(j).getString("video_file"));
                                categoryModel1.setItem_image(video_list.getJSONObject(j).getString("front_cover"));
                                categoryModel1.setDownload_name(video_list.getJSONObject(j).getString("video_title"));
                                categoryModel1.setVideo_url(video_list.getJSONObject(j).optString("video_file"));
                                categoryModel1.setCategory_id(video_list.getJSONObject(j).getString("video_category_id"));
                                categoryModel1.setUpdate_count(video_list.getJSONObject(j).getString("update_count"));
                                video_listItem.add(categoryModel1);
                            }

                            SearchviedoAudioSongListAdapter Adaptervi = new SearchviedoAudioSongListAdapter(mContext, video_listItem, video_song_search_type2);
                            video_song_search_type2.setAdapter(Adaptervi);
                            video_song_search_type2.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            VideoSongsLi.setVisibility(View.GONE);
                        }

                        ArrayList<Object> CatArray = new ArrayList<>();
                        ArrayList<HomeModel> audio_category_list = new ArrayList<>();
                        JSONArray audioCatdata = data.getJSONArray("audio_category_list");
                        if(!(audioCatdata.length()==0)) {
                            AudioCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < audioCatdata.length(); i++) {
                                HomeModel home = new HomeModel();
                                home.setCategory_id(audioCatdata.getJSONObject(i).getString(Constants.CATEGORY_ID));
                                home.setCategory_image(audioCatdata.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                                home.setCategory_name(audioCatdata.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                                home.setIsSubcategoryAvailable(audioCatdata.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                                home.setTypeHm("Audio");
                                audio_category_list.add(home);
                                CatArray.add(home);
                            }

                            SearchAudioMainAdapter Adapter = new SearchAudioMainAdapter(mContext, R.layout.search_adapter_layout, CatArray, AudioCategories_search_typeRe);
                            AudioCategories_search_typeRe.setAdapter(Adapter);
                            AudioCategories_search_typeRe.setLayoutManager(new GridLayoutManager(getActivity(), 5));
                        }else {
                            AudioCategoriesLi.setVisibility(View.VISIBLE);
                        }


                        ArrayList<Object> audio_subCatArray = new ArrayList<>();
                        ArrayList<SubHomeCategory> audio_subcategory = new ArrayList<>();
                        JSONArray  audiosubdata = data.getJSONArray("audio_subcategory_list");
                        if(!(audiosubdata.length()==0)) {
                            AudioSubCategoriesli.setVisibility(View.VISIBLE);
                            for (int i = 0; i < audiosubdata.length(); i++) {
                                SubHomeCategory home = new SubHomeCategory();
                                home.setAudio_subcategory_id(audiosubdata.getJSONObject(i).getString("audio_subcategory_id"));
                                home.setAudio_subcategory_name(audiosubdata.getJSONObject(i).getString("audio_subcategory_name"));
                                home.setAudio_subcategory_image(audiosubdata.getJSONObject(i).getString("audio_subcategory_image"));
                                home.setCategory_id(audiosubdata.getJSONObject(i).getString("category_id"));
                                home.setCategory_name(audiosubdata.getJSONObject(i).getString("category_name"));
                                home.setTypeHm("Audio");
                                audio_subcategory.add(home);
                                audio_subCatArray.add(home);
                            }

                            SearchSubcategoryAdapter searchAudioMainAdapter = new SearchSubcategoryAdapter(mContext, R.layout.search_adapter_layout, audio_subCatArray, AudioSub_search_type2Re);
                            AudioSub_search_type2Re.setAdapter(searchAudioMainAdapter);
                            AudioSub_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 5));
                        }else {
                            AudioSubCategoriesli.setVisibility(View.GONE);
                        }


                        ArrayList<Object> video_CatArray = new ArrayList<>();
                        ArrayList<HomeModel> video_categoryarry = new ArrayList<>();
                        JSONArray videoCategoryList = data.getJSONArray("video_category_list");
                        if(!(videoCategoryList.length()==0)) {

                            VideoCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < videoCategoryList.length(); i++) {
                                HomeModel home = new HomeModel();
                                home.setCategory_id(videoCategoryList.getJSONObject(i).getString(Constants.CATEGORY_ID));
                                home.setCategory_image(videoCategoryList.getJSONObject(i).getString(Constants.CATEGORY_IMAGE));
                                home.setCategory_name(videoCategoryList.getJSONObject(i).getString(Constants.CATEGORY_NAME));
                                home.setIsSubcategoryAvailable(videoCategoryList.getJSONObject(i).getString(Constants.CatisSubcategoryAva));
                                home.setTypeHm("Video");
                                video_categoryarry.add(home);
                                video_CatArray.add(home);
                            }

                            SearchVedioMainAdapter Adapter1 = new SearchVedioMainAdapter(mContext, R.layout.search_adapter_layout, video_CatArray, VideoCategories_search_type2Re);
                            VideoCategories_search_type2Re.setAdapter(Adapter1);
                            VideoCategories_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 5));
                        }else {
                            VideoCategoriesLi.setVisibility(View.GONE);
                        }

                        ArrayList<Object> videosubcategoryarry = new ArrayList<>();
                        ArrayList<SubHomeCategory> videosubcategorylist = new ArrayList<>();
                        JSONArray videosublist = data.getJSONArray("video_subcategory_list");
                        if(!(videosublist.length()==0)) {
                            VideoSubCategoriesLi.setVisibility(View.VISIBLE);
                            for (int i = 0; i < videosublist.length(); i++) {
                                SubHomeCategory home = new SubHomeCategory();
                                home.setAudio_subcategory_id(videosublist.getJSONObject(i).getString("video_subcategory_id"));
                                home.setAudio_subcategory_name(videosublist.getJSONObject(i).getString("video_subcategory_name"));
                                home.setAudio_subcategory_image(videosublist.getJSONObject(i).getString("video_subcategory_image"));
                                home.setCategory_id(videosublist.getJSONObject(i).getString("video_category_id"));
                                home.setCategory_name(videosublist.getJSONObject(i).getString("video_category_name"));
                                home.setTypeHm("Video");
                                videosubcategorylist.add(home);
                                videosubcategoryarry.add(home);
                            }

                            SearchVideoSubCategoyAdapter Adapter2 = new SearchVideoSubCategoyAdapter(mContext, R.layout.search_adapter_layout, videosubcategoryarry, video_sub_rev_search_type2Re);
                            video_sub_rev_search_type2Re.setAdapter(Adapter2);
                            video_sub_rev_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 5));
                        }else {
                            VideoSubCategoriesLi.setVisibility(View.GONE);
                        }

                    } else {
                        noSongFoundTv.setText("No Data");
                        //showListView(false);
                    }
                } else {
                    //showListView(false);
                }

            } catch (Exception e) {
                //mContext.showWaitIndicator(false);
                Log.e("Exception", e.toString());
                e.printStackTrace();

            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            //mContext.showWaitIndicator(false);
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        if (!lastSearchedString.equalsIgnoreCase("")) {
            loadCategoryData();
        }

    }

    private void loadCategoryData() {
        if (isInternet) {
            Log.e("server request data", "=");
            getSearchedSongList(lastSearchedString);
        } else {
            Utilities.hideKeyboard(getMasterActivity());
            ToastUtil.showLongToastMessage(mContext,
                    mContext.getString(R.string.check_if_you_are_connected_to_network));
        }

    }


    public void showListView(boolean flag) {
        if (flag) {
            noSongFoundView.setVisibility(View.GONE);

        } else {
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }


    @Override
    public void onStop() {
        super.onStop();
        Utilities.hideKeyboard(getMasterActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Utilities.hideKeyboard(getMasterActivity());
    }

   /* //Downloading Service calls and receiver methods
    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                downloadQueue(selectedObject, position);
             //   mContext.loadRewardedVideoAd();
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    public void downloadQueue(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.startDownloading(subCategoryModel, position);
            }
        }
    }

    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (SearchFragment.this.isVisible()) {
                if (tmpInfo == null || position == -1) {
                    return;
                }
                final int status = tmpInfo.getStatus();
                switch (status) {
                    case SubCategoryModel.STATUS_COMPLETE:
                        if (Adapter != null) {
                            Log.e("SearchFragment","notified");
                            Adapter.notifyDataSetChanged();
                        }
                        break;
                }
            }
    }*/

   /* private boolean isCurrentListViewItemVisible(int position) {
        int first = mCategoryList.getFirstVisiblePosition();
        int last = mCategoryList.getLastVisiblePosition();
        return first <= position && position <= last;
    }

    private CategoryAdapter.ViewHolder getViewHolder(int position) {
        int childPosition = position - mCategoryList.getFirstVisiblePosition();
        View view = mCategoryList.getChildAt(childPosition);
        return (CategoryAdapter.ViewHolder) view.getTag();
    }

    private int getAdapterItemPosition(String id) {
        for (int position = 0; position < CatListItem.size(); position++)
            if (CatListItem.get(position).getItem_id().equalsIgnoreCase(id))
                return position;
        return 0;
    }*/
    //Downloading Service calls and receiver methods ends
}
