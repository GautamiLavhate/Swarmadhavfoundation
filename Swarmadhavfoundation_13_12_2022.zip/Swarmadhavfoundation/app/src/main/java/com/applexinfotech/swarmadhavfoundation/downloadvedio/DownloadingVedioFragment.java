package com.applexinfotech.swarmadhavfoundation.downloadvedio;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;

import static com.crashlytics.android.Crashlytics.TAG;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.downloadQueue;

public class DownloadingVedioFragment extends MasterFragment implements DownloadListener, OnItemClickListener<SubCategoryModel> {

    MainActivity mContext;
    HomeModel homeModel = new HomeModel();
    private ListView mCategoryList;
    private String category_id;
    private Bundle bundle;
    public DownloadingVedioAdapter Adapter;

    InterstitialAd interstitial;

    public static RelativeLayout topContainer;
    private ProgressBar mProgress;
    private SeekBar mSeekBar;
    private int overflowcounter = 0;
    private View rootView;


    private LinearLayout noSongFoundView;
    TextView textView_download;
    public ArrayList<SubCategoryModel> mItem = new ArrayList<SubCategoryModel>();
    public String lastSearchedString = "";
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private Parcelable state;


    public DownloadingVedioFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = (MainActivity) getMasterActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_downloading, container, false);

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCategoryList = (ListView) view.findViewById(R.id.listView_cat_list);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        textView_download = (TextView) view.findViewById(R.id.textView_download);
        textView_download.setTypeface(mContext.getTypeFace());
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeToRefresh);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    Log.e("server request data", "=");
                    showDownloadingData();

                } else {
                    showListView(false);
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
        // Restore previous state (including selected item index and scroll position)
        if (state != null) {
            Log.d(TAG, "trying to restore listview state..");
            mCategoryList.onRestoreInstanceState(state);
        }

        showDownloadingData();

    }

    private void showDownloadingData() {
        if (!downloadQueue.isEmpty()) {
            showListView(true);
            Adapter = new DownloadingVedioAdapter(mContext, R.layout.category_item, downloadQueue, homeModel, DownloadingVedioFragment.this.getClass().getCanonicalName());
            mCategoryList.setAdapter(Adapter);
            Toast.makeText(mContext,"Downloading Videos : "+String.valueOf(mCategoryList.getAdapter().getCount()),Toast.LENGTH_LONG).show();
          //  Adapter.setOnItemClickListener(DownloadingFragment.this);
            Adapter.notifyDataSetChanged();
        } else {
            showListView(false);
        }
    }

    @Override
    public void onPause() {
        // Save ListView state @ onPause
        Log.d(TAG, "saving listview state @ onPause");
        state = mCategoryList.onSaveInstanceState();
        super.onPause();
    }


    public void showListView(boolean flag) {
        if (flag) {
            mCategoryList.setVisibility(View.VISIBLE);
            noSongFoundView.setVisibility(View.GONE);

        } else {
            mCategoryList.setVisibility(View.GONE);
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }

    //Downloading Service calls and receiver methods
    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                // downloadQueue(selectedObject, position);
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (DownloadingVedioFragment.this.isVisible()) {
            if (tmpInfo == null || position == -1) {
                return;
            }
            final int status = tmpInfo.getStatus();
            switch (status) {
                case SubCategoryModel.STATUS_DOWNLOADING:
                    if (!downloadQueue.isEmpty()) {
                        if (Adapter != null) {
                            int viewPosition = getAdapterItemPosition(tmpInfo.getItem_id());
                           // Log.e("DOWNLOADING", "viewPosition" + String.valueOf(viewPosition));
                            final SubCategoryModel appInfo = downloadQueue.get(viewPosition);
                            if (appInfo.getItem_id().equalsIgnoreCase(tmpInfo.getItem_id())) {
                                if (isCurrentListViewItemVisible(viewPosition)) {
                                    DownloadingVedioAdapter.ViewHolder holder = getViewHolder(viewPosition);
                                    //holder.downloadProgress.setProgress(tmpInfo.getProgress());
                                    holder.downloadProgressCircular.setVisibility(View.VISIBLE);
                                    holder.tv.setVisibility(View.VISIBLE);
                                    holder.downloadProgressCircular.setProgress(tmpInfo.getProgress());
                                    holder.tv.setText(String.valueOf(tmpInfo.getProgress())+"%");
                                    holder.close.setVisibility(View.VISIBLE);
                                    holder.download.setClickable(false);

                                    holder.close.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            String url=tmpInfo.getItem_file();

                                            if (!downloadQueue.isEmpty()){
                                                for (SubCategoryModel model : downloadQueue){
                                                    if (model.getItem_id().equals(tmpInfo.getItem_id())){
                                                        stopDownloading(tmpInfo,viewPosition);
                                                        downloadQueue.remove(viewPosition);
                                                        mCategoryList.removeViewInLayout(holder.linearLayoutVideo);
                                                        Adapter.notifyDataSetChanged();
                                                        if (downloadQueue.isEmpty()){
                                                            noSongFoundView.setVisibility(View.VISIBLE);
                                                        }
                                                        break;
                                                    }
                                                }
                                            }

//                                            holder.linearLayoutsong.setVisibility(View.GONE);

                                        }
                                    });
                                }
                            }

                        }
                    }
                    break;
                case SubCategoryModel.STATUS_COMPLETE:
                    if (!downloadQueue.isEmpty()) {
                        if (Adapter != null) {
                            Adapter.notifyDataSetChanged();
                        }
                    }
                    else{
                        showListView(false);
                    }
                    break;
            }
        }
    }
    private void stopDownloading(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.stopDownloading(subCategoryModel, position);
            }
        }
    }

    private boolean isCurrentListViewItemVisible(int position) {
        int first = mCategoryList.getFirstVisiblePosition();
        int last = mCategoryList.getLastVisiblePosition();
        return first <= position && position <= last;
    }

    private DownloadingVedioAdapter.ViewHolder getViewHolder(int position) {
        int childPosition = position - mCategoryList.getFirstVisiblePosition();
        View view = mCategoryList.getChildAt(childPosition);
        return (DownloadingVedioAdapter.ViewHolder) view.getTag();
    }

    private int getAdapterItemPosition(String id) {
        for (int position = 0; position < downloadQueue.size(); position++)
            if (downloadQueue.get(position).getItem_id().equalsIgnoreCase(id))
                return position;
        return 0;
    }
    //Downloading Service calls and receiver methods ends


}
