package com.applexinfotech.swarmadhavfoundation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.fragment.SubCategoryFolderAudioFragments;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.security.Permission;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class LoginActivity extends MasterActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS=0;
    private EditText UserName,password;
    private Button Loginbutton;
    private ProgressDialog dialog;
    private String user,pass;
    private SessionManager sessionManager;
    ImageView show_pass_btn;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    CheckBox rememberMe;
    TextView txtRegisterNow,txtSendEmail;
    BottomSheetDialog bottomSheetRegisterNow;
    Button btnWhatsapp;
    String messageToSend,number;
    public LoginActivity() {
        // Constructor body
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen_layout);

        UserName=findViewById(R.id.Username);
        password=findViewById(R.id.Username1);
        Loginbutton=findViewById(R.id.LogIn);
        show_pass_btn=findViewById(R.id.show_pass_btn);
        rememberMe=findViewById(R.id.saveLoginCheckBox);
        txtRegisterNow=findViewById(R.id.txtRegisterNow);
        txtRegisterNow.setPaintFlags(txtRegisterNow.getPaintFlags()| Paint.UNDERLINE_TEXT_FLAG);

        //Bottom popup for Registration
        bottomSheetRegisterNow=new BottomSheetDialog(LoginActivity.this);
        View sheetView=getLayoutInflater().inflate(R.layout.bottom_sheet_login,null);
        bottomSheetRegisterNow.setContentView(sheetView);
        //Contents of Bottom Sheet
        btnWhatsapp=(Button)sheetView.findViewById(R.id.btnWhatsApp);
        txtSendEmail=(TextView)sheetView.findViewById(R.id.txtSendEmail);
        txtSendEmail.setPaintFlags(txtSendEmail.getPaintFlags()| Paint.UNDERLINE_TEXT_FLAG);
        ////////////////////////////////////
        sharedPreferences=getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        editor=sharedPreferences.edit();
        /////////////////To get Stored Data/////////////////////////////////
        String mail=sharedPreferences.getString("MobileNume","");
        String passwords=sharedPreferences.getString("passowrd","");
        ////////////////////////////////////////////////////////////////////

        UserName.setText(mail);
        password.setText(passwords);


        sessionManager=new SessionManager(LoginActivity.this);

        isInternet = InternetStatus.isInternetOn(this);

        Loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (UserName.length() > 0 && password.length() > 0) {
                    try {
                        if (isInternet) {
                            getCategory();
                        }else {
                            Toast.makeText(getApplicationContext(),
                                    "connection not found...plz check connection", Toast.LENGTH_LONG).show();
                        }
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(Objects.requireNonNull(getCurrentFocus()).getWindowToken(), 0);
                } else {
                    Toast.makeText(getApplicationContext(), "Enter UserName and Password...!!! ", Toast.LENGTH_LONG).show();
                }

            }
        });
        show_pass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){

                    show_pass_btn.setImageResource(R.drawable.ic_remove_red_eye_black_24dp);
                    //Show Password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    show_pass_btn.setImageResource(R.drawable.ic_visibility_off_black_24dp);
                    //Hide Password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });
        txtRegisterNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               bottomSheetRegisterNow.show();
            }
        });
        txtSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_SEND);
                String[] recipients={"contact@swarmadhavfoundation.org"};
                String sendEmail=getString(R.string.send_message);
                intent.putExtra(Intent.EXTRA_EMAIL, recipients);
                intent.putExtra(Intent.EXTRA_SUBJECT,"New registration request");
                intent.putExtra(Intent.EXTRA_TEXT,sendEmail);
                intent.setType("text/html");
                intent.setPackage("com.google.android.gm");
                startActivity(Intent.createChooser(intent, "Send mail"));
                bottomSheetRegisterNow.dismiss();
            }
        });


        btnWhatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWhatsApp(v);
            }
        });

    }


    public void openWhatsApp(View view){
        try {
            messageToSend=getString(R.string.send_message);
            String text="Hi whatsapp";
            String toNumber="918668460516";
//            Intent intent1=new Intent(getApplicationContext(),LoginActivity.class);
//            PendingIntent pi=PendingIntent.getActivity(getApplicationContext(),0,intent1,0);
            Intent intent=new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://api.whatsapp.com/send?phone="+toNumber+"&text="+messageToSend));
            startActivity(intent);
            bottomSheetRegisterNow.dismiss();
        }catch (Exception e){

        }


    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case MY_PERMISSIONS_REQUEST_SEND_SMS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                    PendingIntent pi=PendingIntent.getActivity(getApplicationContext(),0,intent,0);

                    SmsManager sms=SmsManager.getDefault();
                    sms.sendTextMessage(number,null,messageToSend,pi,null);

                    Toast.makeText(LoginActivity.this,"SMS Sent",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(LoginActivity.this,"Failed to send SMS",Toast.LENGTH_LONG).show();
                    return;
                }
        }


    }

    @SuppressLint("NewApi")
    @Override
    public void onBackPressed() {
        finishAffinity();
        return;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (dialog != null) {
            dialog.dismiss();
            dialog = null;
        }
    }


    private void getCategory() {
        dialog=new ProgressDialog(LoginActivity.this);
        dialog.show();

        user=UserName.getText().toString();
        pass=password.getText().toString();

        NetworkRequest dishRequest = new NetworkRequest(LoginActivity.this);
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(
                Constants.mobile_ID, user));
        carData.add(new BasicNameValuePair(
                Constants.password_ID,pass));
        dishRequest.sendRequest(Constants.API_Post_Login_user_URL,
                carData, catCallback);
    }


    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            dialog.dismiss();
            try {
                if (response != null) {
                    Log.d("SUBCATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    String response_message=jObject.getString("response_message");
                    if (status.equalsIgnoreCase("1")) {
                        JSONArray data = jObject.getJSONArray("data");
                        Log.d("data.length()", "" + data.length());

                        String user_id=data.getJSONObject(0).getString("user_id");
                        String name=data.getJSONObject(0).getString("name");
                        String mobile=data.getJSONObject(0).getString("mobile");
                        String email=data.getJSONObject(0).getString("email");
                        String address=data.getJSONObject(0).getString("address");
                        String dob=data.getJSONObject(0).getString("dob");
                        String login_status=data.getJSONObject(0).getString("login_status");
                        String image=data.getJSONObject(0).getString("image");

                        ToastUtil.showLongToastMessage(getApplicationContext(),response_message);
                        //ToastUtil.showLongToastMessage(getApplicationContext(),user_id);

//                        Intent accesscat=new Intent();
//                        accesscat.putExtra("userId",user_id);
//                        accesscat.setClass(LoginActivity.this, SubCategoryFolderAudioFragments.class);
//                        startActivity(accesscat);
                        if(rememberMe.isChecked()) {
                            if (login_status.equals("0")){
                                editor.putString("MobileNume",UserName.getText().toString());
                                editor.putString("passowrd","");
                                editor.commit();
                                Intent iset = new Intent();
                                iset.putExtra("SetPss",user_id);
                                iset.putExtra("MobileNume",UserName.getText().toString());
                                iset.setClass(LoginActivity.this, SetPasswordActivity.class);
                                startActivity(iset);
                                finish();
                            } else {
                                editor.putString("MobileNume",UserName.getText().toString());
                                editor.putString("passowrd",password.getText().toString());
                                editor.commit();
                                sessionManager.createLoginSession(user_id,name,mobile,address,dob,image,email);
                                Intent i = new Intent();
                                i.setClass(LoginActivity.this, MainActivity.class);
                                startActivity(i);
                                finish();
                            }
                        }else{
                            editor.putString("MobileNume","");
                            editor.putString("passowrd","");
                            editor.commit();
                            if (login_status.equals("0")){
                                Intent iset = new Intent();
                                iset.putExtra("SetPss",user_id);
                                iset.putExtra("MobileNume",UserName.getText().toString());
                                iset.setClass(LoginActivity.this, SetPasswordActivity.class);
                                startActivity(iset);
                                finish();
                            } else {
                                sessionManager.createLoginSession(user_id,name,mobile,address,dob,image,email);
                                Intent i = new Intent();
                                i.setClass(LoginActivity.this, MainActivity.class);
                                startActivity(i);
                                finish();
                            }
                        }

                    }else{
                        dialog.dismiss();
                        ToastUtil.showLongToastMessage(getApplicationContext(),response_message);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
               dialog.dismiss();
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            dialog.dismiss();

        }
    };
}
