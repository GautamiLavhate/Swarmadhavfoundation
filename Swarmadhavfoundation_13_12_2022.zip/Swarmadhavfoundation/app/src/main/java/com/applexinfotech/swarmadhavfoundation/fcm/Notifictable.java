package com.applexinfotech.swarmadhavfoundation.fcm;

public class Notifictable {

    public static final String DATABASE_TABLE = "Notifictable";
    public static final String KEY_id = "id";
    public static final String KEY_title= "title";
    public static final String KEY_description = "description";
    public static final String KEY_notification_image = "notification_image";
    public static final String KEY_alert = "alert";
    public static final String KEY_new_alert = "New_alert";

    static final String CREATE_TABLE = " CREATE TABLE " + DATABASE_TABLE + "("
    + KEY_new_alert + " TEXT," + KEY_alert + " TEXT," + KEY_id + " TEXT," + KEY_title + " TEXT," + KEY_description + " TEXT," +
            KEY_notification_image + " TEXT );";
}
