package com.applexinfotech.swarmadhavfoundation.downloadvedio;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.ViewPagerAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.tabs.TabLayout;

public class DownloadsMainVedioFragment extends MasterFragment implements TabLayout.OnTabSelectedListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private TabLayout tabLayout;
    private ViewPager viewPager;
    public MainActivity mContext;
    Fragment fragment;
    private Bundle bundle;
    InterstitialAd interstitial;



    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private int mPage;


    public DownloadsMainVedioFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static DownloadsMainVedioFragment newInstance(String param1, String param2) {
        DownloadsMainVedioFragment fragment = new DownloadsMainVedioFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_downloads_main, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.downloads));

        viewPager=view.findViewById(R.id.viewpager_downloads);
        tabLayout=view.findViewById(R.id.downloads_tabs);
        setupViewPager(viewPager);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(this);


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

    }
    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFragment(new DownloadsVedio(), "Downloaded");
        adapter.addFragment(new DownloadingVedioFragment(), "Downloading");
        viewPager.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }


    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        mPage = tab.getPosition();
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
}
