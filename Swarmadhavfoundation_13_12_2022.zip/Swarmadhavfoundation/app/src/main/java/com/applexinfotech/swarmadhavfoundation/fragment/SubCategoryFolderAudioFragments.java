package com.applexinfotech.swarmadhavfoundation.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.AudioSubCategoryFargmentAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchSubcategoryAdapter;
import com.applexinfotech.swarmadhavfoundation.adapter.SearchviedoAudioSongListAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment.hideKeyboard;

public class SubCategoryFolderAudioFragments extends MasterFragment{
    private MainActivity mContext;
    private RecyclerView listView_category,AudioSub_search_type2Re,AudioSongs_search_type2Re;
    private ArrayList<Object> CatArray = new ArrayList<>();
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    private int numberOfColumns=2;
    private String category_id,CategoryName,user_id;
    private Bundle bundle;
    private HomeModel homeModel = new HomeModel();
    private LinearLayout Linerlayourserach;
    private EditText search;
    private LinearLayout noSongFoundView;
    NestedScrollView nestedScrollView;
    SessionManager sessionManager;
    private LinearLayout relsearch,CategoryListLi,AudioCategoriesLi,AudioSubCategoriesli,AudioSongsLi;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext.showWaitIndicator(false);

        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
       // mContext.hideDrawer();
        mContext.showDrawerBack();
        listView_category = view.findViewById(R.id.listView_category);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());
        Linerlayourserach= view.findViewById(R.id.Linerlayourserach);
        search=(EditText) view.findViewById(R.id.search);
        Linerlayourserach.setVisibility(View.VISIBLE);
        relsearch=view.findViewById(R.id.relsearch);
        CategoryListLi=view.findViewById(R.id.CategoryListLi);

        AudioSubCategoriesli=view.findViewById(R.id.AudioSubCategoriesli);
        AudioSongsLi=view.findViewById(R.id.AudioSongsLi);

        AudioSub_search_type2Re=view.findViewById(R.id.AudioSub_search_type2);
        AudioSongs_search_type2Re=view.findViewById(R.id.AudioSongs_search_type2);
        sessionManager=new SessionManager(getMasterActivity());
        bundle = getArguments();

        if (bundle != null) {
            homeModel = (HomeModel) bundle.getSerializable("CAT_ID");
            category_id = homeModel.getCategory_id();
            CategoryName= homeModel.getCategory_name();
        }
        user_id=sessionManager.getKEY_Userid();
        //Toast.makeText(mContext,user_id,Toast.LENGTH_LONG).show();

        mContext.setTitle(CategoryName);

        if (InternetStatus.isInternetOn(getMasterActivity())) {
            getSubAudioCategory();
        } else {

        }

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);

                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    getSubAudioCategory();
                } else {

                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        if(search.getText().toString().equals("")){
            CategoryListLi.setVisibility(View.VISIBLE);
            relsearch.setVisibility(View.GONE);
            AudioSub_search_type2Re.setAdapter(null);
            AudioSongs_search_type2Re.setAdapter(null);
            if (InternetStatus.isInternetOn(getMasterActivity())) {
                getSubAudioCategory();
            }
        }

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        getSubAudioCategory();
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        getSubAudioCategory();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.length()>0){
                        listView_category.setAdapter(null);
                        getSubAudioSearch(s.toString());
                    }else {
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        getSubAudioCategory();
                    }
                }
            }

        });

        search.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_DEL) {
                    String _text= search.getText().toString();
                    if(_text.isEmpty()){
                        CategoryListLi.setVisibility(View.VISIBLE);
                        relsearch.setVisibility(View.GONE);
                        showListView(true);
                        AudioSub_search_type2Re.setAdapter(null);
                        AudioSongs_search_type2Re.setAdapter(null);
                        if (InternetStatus.isInternetOn(getMasterActivity())) {
                            getSubAudioCategory();
                        }
                    }
                    //editText is now empty
                }

                return false;
            }
        });

        nestedScrollView=view.findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Utilities.hideKeyboard(getMasterActivity());
            }
        });
    }

    private void getSubAudioCategory() {
        mContext.showWaitIndicator(true);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.CATEGORY_ID, category_id));
        carData.add(new BasicNameValuePair(Constants.user_ID,user_id));
        dishRequest.sendRequest(Constants.API_audio_subcategory_list, carData, catCallback);
    }

    private final NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    hideKeyboard(mContext);
                    Log.d("CATEGORY_API ", "" + response.toString());
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                    ArrayList<SubHomeCategory> arrayList = new ArrayList<>();
                    CatArray = new ArrayList<>();
                    JSONArray data = jObject.getJSONArray("data");

                    Log.d("data.length()", "" + data.length());
//                    String accesible=data.getJSONObject(2).getString("is_accessible");
//                    if (accesible.equalsIgnoreCase("0")){
//                        Toast.makeText(mContext,"",Toast.LENGTH_LONG);
//                    }
                    for (int i = 0; i < data.length(); i++) {
                        SubHomeCategory home = new SubHomeCategory();
                        home.setAudio_subcategory_id(data.getJSONObject(i).getString("audio_subcategory_id"));
                        home.setAudio_subcategory_name(data.getJSONObject(i).getString("audio_subcategory_name"));
                        home.setAudio_subcategory_image(data.getJSONObject(i).getString("audio_subcategory_image"));
                        home.setCategory_id(data.getJSONObject(i).getString("category_id"));
                        home.setCategory_name(data.getJSONObject(i).getString("category_name"));
                        home.setTypeHm("Audio");
                        arrayList.add(home);
                        CatArray.add(home);
                    }
                    showListView(true);
                    setHomeAdapter();
                } else if (status.equalsIgnoreCase("0")) {
                    showListView(false);
                }

                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };

    private void getSubAudioSearch(String catergor) {
        mContext.showWaitIndicator(false);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.CATEGORY_ID, category_id));
        carData.add(new BasicNameValuePair(Constants.subcategory_name, catergor));
        dishRequest.sendRequest(Constants.API_audio_subcat_search_list,
                carData, catCallbackSearch);
    }

    private final NetworkRequest.NetworkRequestCallback catCallbackSearch = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.optString("response_status");
                    CategoryListLi.setVisibility(View.GONE);
                    relsearch.setVisibility(View.VISIBLE);
                    if (status.equalsIgnoreCase("1")) {
                        JSONObject data = jObject.getJSONObject("data");
                        JSONArray audio_list= data.getJSONArray("audio_list");
                        ArrayList<SubCategoryModel> audio_listItem = new ArrayList<>();
                        Log.d("data.length()", "" + audio_list.length());
                        if(!(audio_list.length()==0)) {
                            for (int i = 0; i < audio_list.length(); i++) {
                                AudioSongsLi.setVisibility(View.VISIBLE);
                                SubCategoryModel categoryModel = new SubCategoryModel();
                                categoryModel.setItem_id(audio_list.getJSONObject(i).getString("audio_id")+"audio_id");
                                categoryModel.setItem_name(audio_list.getJSONObject(i).getString("audio_title"));
                                categoryModel.setItem_description(audio_list.getJSONObject(i).getString("audio_description"));
                                categoryModel.setItem_file(audio_list.getJSONObject(i).getString("audio_file"));
                                categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                                categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("audio_title"));
                                categoryModel.setLyrics_file(audio_list.getJSONObject(i).getString("audio_lyrics"));
                                categoryModel.setLyrics_filePdf(audio_list.getJSONObject(i).getString("pdf_file"));
                                categoryModel.setVideo_url("null");
                                audio_listItem.add(categoryModel);
                            }
                            SearchviedoAudioSongListAdapter audio_listItemAdaptervi = new SearchviedoAudioSongListAdapter(mContext, audio_listItem, AudioSongs_search_type2Re);
                            AudioSongs_search_type2Re.setAdapter(audio_listItemAdaptervi);
                            AudioSongs_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 3));
                        }else {
                            AudioSongsLi.setVisibility(View.GONE);
                        }


                        ArrayList<Object> audio_subCatArray = new ArrayList<>();
                        ArrayList<SubHomeCategory> audio_subcategory = new ArrayList<>();
                        JSONArray  audiosubdata = data.getJSONArray("audio_subcategory_list");
                        if(!(audiosubdata.length()==0)) {
                            AudioSubCategoriesli.setVisibility(View.VISIBLE);
                            for (int i = 0; i < audiosubdata.length(); i++) {
                                SubHomeCategory home = new SubHomeCategory();
                                home.setAudio_subcategory_id(audiosubdata.getJSONObject(i).getString("subcategory_id"));
                                home.setAudio_subcategory_name(audiosubdata.getJSONObject(i).getString("subcategory_name"));
                                home.setAudio_subcategory_image(audiosubdata.getJSONObject(i).getString("subcategory_image"));
                                home.setCategory_id(audiosubdata.getJSONObject(i).getString("category_id"));
                                home.setCategory_name(audiosubdata.getJSONObject(i).getString("category_name"));
                                home.setTypeHm("Audio");
                                audio_subcategory.add(home);
                                audio_subCatArray.add(home);
                            }

                            SearchSubcategoryAdapter searchAudioMainAdapter = new SearchSubcategoryAdapter(mContext, R.layout.search_adapter_layout, audio_subCatArray, AudioSub_search_type2Re);
                            AudioSub_search_type2Re.setAdapter(searchAudioMainAdapter);
                            AudioSub_search_type2Re.setLayoutManager(new GridLayoutManager(getActivity(), 4));
                        }else {
                            AudioSubCategoriesli.setVisibility(View.GONE);
                        }

                        showListView(true);
                    } else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                        AudioSubCategoriesli.setVisibility(View.GONE);
                        AudioSongsLi.setVisibility(View.GONE);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };



    private void setHomeAdapter() {
        mContext.showWaitIndicator(false);
        AudioSubCategoryFargmentAdapter Adapter = new AudioSubCategoryFargmentAdapter(mContext, R.layout.category_item, CatArray, listView_category);
        listView_category.setAdapter(Adapter);
        listView_category.setLayoutManager(new GridLayoutManager(getActivity(), numberOfColumns));
        Adapter.notifyDataSetChanged();
    }


    private void showListView(boolean flag) {
        if (flag) {
            listView_category.setVisibility(View.VISIBLE);
            noSongFoundView.setVisibility(View.GONE);

        } else {
            listView_category.setVisibility(View.GONE);
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }
}
