package com.applexinfotech.swarmadhavfoundation.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.AddVideoPlay.AddPlaylistVedioDialog;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.fragment.AddPlaylistDialog;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.CATEGORY;
import static com.facebook.FacebookSdk.getApplicationContext;


/**
 * Created by JD(jikadrajaydeep@gmail.com) on 03-01-2016.
 */
public class DownloadingAdapter extends ArrayAdapter<SubCategoryModel> {
    private final String fragmentTag;
    private final RealmHelper realmHelper;
    private final LayoutInflater layoutInflater;
    private final ArrayList<SubCategoryModel> mItem;
    String categoryImage;
    private final MainActivity mContext;
    private OnItemClickListener mListener;
    private SubCategoryModel selectedObject;
    private final int resource;
    private ProgressDialog pDialog;

    private final Typeface font;
    private final HomeModel homeModel;
    private static ArrayList<SongModel> songsID = new ArrayList<>();
    private PopupMenu menu;

    public static class ViewHolder {

        private ImageView cat_image, imagePlay;
        private ImageButton play,playlist,popupMenu;
        public ImageButton download,close,pause,playDownload;
        private TextView tv_title, tv_desc, tv_duration;
        private String urls;
        private String imgpath;
        private LinearLayout layout_main,linearlayoutAudio;
        public ProgressBar downloadProgress,mProgress;
        public TextView tv;
        public LinearLayout linearLayoutsong;
    }

    public DownloadingAdapter(MainActivity context, int resource, ArrayList<SubCategoryModel> list, HomeModel homeModel, String fragmentTag) {
        super(context, resource);
        mContext = context;
        this.mItem = list;
        this.resource = resource;
        this.homeModel = homeModel;
        this.fragmentTag = fragmentTag;
        font = Typeface.createFromAsset(mContext.getAssets(), "ProximaNova-Light.otf");
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //Get path of song name
        realmHelper = new RealmHelper();
        songsID = realmHelper.retrieveoAudioListDEmo();

    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    public int getCount() {
        return mItem.size();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        final ViewHolder mViewHolder;
        LayoutInflater inflater = (LayoutInflater) (mContext).getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        try {

            if (itemView == null) {

                itemView = inflater.inflate(R.layout.subcategory_list_item, null, true);

                mViewHolder = new ViewHolder();

                mViewHolder.cat_image = itemView.findViewById(R.id.image);

                mViewHolder.play = itemView.findViewById(R.id.play);
                mViewHolder.download = itemView.findViewById(R.id.download);
                mViewHolder.playlist= itemView.findViewById(R.id.add_to_playlist);
                mViewHolder.popupMenu = itemView.findViewById(R.id.popup_menu);
                mViewHolder.linearlayoutAudio= itemView.findViewById(R.id.linearlayoutAudio);
                mViewHolder.close=itemView.findViewById(R.id.img_btn_close);
                mViewHolder.pause=itemView.findViewById(R.id.btn_pause_downloading);
                mViewHolder.playDownload=itemView.findViewById(R.id.btn_play_downloading);
                mViewHolder.tv_title = itemView.findViewById(R.id.tv_title);
                mViewHolder.tv_desc = itemView.findViewById(R.id.tv_desc);
                mViewHolder.tv_duration = itemView.findViewById(R.id.tv_duration);
                mViewHolder.linearLayoutsong=itemView.findViewById(R.id.linearLayputSongDetails);
                mViewHolder.layout_main = itemView.findViewById(R.id.layout_main);
                mViewHolder.downloadProgress = itemView.findViewById(R.id.download_progress_normal);
                mViewHolder.mProgress=itemView.findViewById(R.id.circularProgressbarSong);
                mViewHolder.tv=itemView.findViewById(R.id.tv);
                mViewHolder.imagePlay = itemView.findViewById(R.id.img_play);
                itemView.setTag(mViewHolder);

            } else {
                mViewHolder = (ViewHolder) itemView.getTag();
            }

            if (mItem.get(position) != null) {
                String videost = mItem.get(position).getVideo_url();
                Log.e("videost", videost);
                if (videost.equals("null")) {
                    mViewHolder.linearlayoutAudio.setVisibility(View.VISIBLE);
                    mViewHolder.download.setVisibility(View.GONE);
                    mViewHolder.playlist.setVisibility(View.GONE);
                    mViewHolder.popupMenu.setVisibility(View.GONE);

                    //mViewHolder.tv_title.setTypeface(font);
                    mViewHolder.tv_desc.setTypeface(font);
                    mViewHolder.tv_duration.setTypeface(font);

                    mViewHolder.tv_title.setText(mItem.get(position).getItem_name());
                    mViewHolder.tv_desc.setText(mItem.get(position).getItem_description());


                    Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                    mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    mViewHolder.download.setImageDrawable(mDrawable);
                    Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                    arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    mViewHolder.play.setImageDrawable(arrowDrawable);
                    Drawable popupMenuDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_more_new);
                    popupMenuDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    mViewHolder.popupMenu.setImageDrawable(popupMenuDrawable);


                    Glide.with(mContext).load(mItem.get(position).getItem_image()).placeholder(R.drawable.no_image).into(mViewHolder.cat_image);

                    mViewHolder.popupMenu.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(final View v) {

                            if (menu != null) {
                                menu.dismiss();
                            }
                            menu = new PopupMenu(mContext, v);
                            menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                @Override
                                public boolean onMenuItemClick(MenuItem item) {
                                    switch (item.getItemId()) {
                                        case R.id.popup_song_play:
                                            mViewHolder.layout_main.performClick();
                                            break;
                                        case R.id.popup_song_addto_playlist:
                                            if (mItem != null && !mItem.isEmpty() && mItem.size() > position) {
                                                SubCategoryModel selectedObject = mItem.get(position);
                                                String videoSt=selectedObject.getVideo_url();
                                                if(videoSt.equals("null")) {
                                                    FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                    AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("DownloadingAdapter", selectedObject,"Audio");
                                                    infoDialog.setCancelable(false);
                                                    infoDialog.show(fragmentManager, "Dialog");
                                                }else {
                                                    FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                    AddPlaylistVedioDialog infoDialog = AddPlaylistVedioDialog.newInstance("DownloadingAdapter", selectedObject,"Vedio");
                                                    infoDialog.setCancelable(false);
                                                    infoDialog.show(fragmentManager, "Dialog");
                                                }
                                            }
                                            break;
                                    }
                                    return false;
                                }
                            });
                            menu.inflate(R.menu.popup_song);
                            menu.show();
                        }
                    });


                    mViewHolder.play.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            StorageUtil storage = new StorageUtil(getApplicationContext());
                            if (storage.loadAudio() != null) {
                                if (mContext.serviceBound && mContext.isPlaying()) {
                                    storage.clearCachedAudioPlaylist();
                                    storage.storeAudio(mItem);
                                    storage.storeAudioIndex(position);
                                    storage.storeMode(0);
                                    storage.storeIsPlayingFrom("Category");
                                    mContext.setShuffleMode(false);
                                    mContext.setRepeatMode(false);
                                    mContext.setNoOfRepeats(0);
                                    mContext.setMode(0);
                                    mContext.stopProgressHandler();
                                    Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                                    mContext.sendBroadcast(broadcastIntent);
                                } else if (mContext.serviceBound) {
                                    storage.clearCachedAudioPlaylist();
                                    storage.storeAudio(mItem);
                                    storage.storeAudioIndex(position);
                                    storage.storeMode(0);
                                    storage.storeIsPlayingFrom("Category");
                                    mContext.setShuffleMode(false);
                                    mContext.setRepeatMode(false);
                                    mContext.setNoOfRepeats(0);
                                    mContext.setMode(0);
                                    mContext.stopProgressHandler();
                                    mContext.playSong();
                                }

                            } else if (mContext.serviceBound) {
                                storage.clearCachedAudioPlaylist();
                                storage.storeAudio(mItem);
                                storage.storeAudioIndex(position);
                                storage.storeMode(0);
                                storage.storeIsPlayingFrom("Category");
                                mContext.setShuffleMode(false);
                                mContext.setRepeatMode(false);
                                mContext.setNoOfRepeats(0);
                                mContext.setMode(0);
                                mContext.playSong();
                            }


                            Fragment investProgramDetail = new Streaming();
                            MainActivity.AudioType="MainAudio";
                            Bundle bundle = new Bundle();
                            bundle.putString("isFrom", CATEGORY);
                            bundle.putInt("mode", 0);
                            bundle.putSerializable("data", mItem);
                            bundle.putInt("position", position);

                            investProgramDetail.setArguments(bundle);
                            mContext.ReplaceFragment(investProgramDetail);
                        }
                    });


                } else {
                    Log.e("videost", videost);
                    mViewHolder.linearlayoutAudio.setVisibility(View.GONE);
                    mViewHolder.tv_title.setText("");
                    mViewHolder.tv_desc.setText("");

                }
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        return itemView;
    }

}