package com.applexinfotech.swarmadhavfoundation.fragment;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.LocalSongAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.gson.Gson;

import java.util.ArrayList;

public class LocalMusicFragment extends MasterFragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 11;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private MainActivity mContext;
    private RecyclerView songlistRecycler;
    private LinearLayout noSongList;
    private LocalSongAdapter songListAdapter;

    public LocalMusicFragment() {
        // Required empty public constructor
    }

    public static LocalMusicFragment newInstance(String param1, String param2) {
        LocalMusicFragment fragment = new LocalMusicFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_local_music, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext = (MainActivity) getActivity();
        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.local_music));
        songlistRecycler = view.findViewById(R.id.local_playlist_recycler);
        noSongList = view.findViewById(R.id.noItemFound);
        noSongList.setVisibility(View.GONE);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        songlistRecycler.setLayoutManager(linearLayoutManager);
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });
        requestRead();

    }

    private void requestRead() {
        if (ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
        } else {
            getAllAudioFromDevice(mContext);
        }
    }

    private void getAllAudioFromDevice(final Context context) {

        final ArrayList<SubCategoryModel> localSongList = new ArrayList<>();

        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
          String[] projection = {MediaStore.Audio.AudioColumns._ID,MediaStore.Audio.AudioColumns.DATA,MediaStore.Audio.AudioColumns.TITLE, MediaStore.Audio.AudioColumns.ALBUM,MediaStore.Audio.AudioColumns.ARTIST,MediaStore.Audio.Albums.ALBUM_ID,};
        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";
        //  Cursor c = context.getContentResolver().query(uri, projection, MediaStore.Audio.Media.DATA + " like ? ", new String[]{"%yourFolderName%"}, null);
        Cursor c = context.getContentResolver().query(uri,
                projection,
                selection,
                null,
                sortOrder);
        if (c != null) {
            while (c.moveToNext()) {

                SubCategoryModel audioModel = new SubCategoryModel();
                String id=c.getString(0);
                String path = c.getString(1);
                String title = c.getString(2);
                String album = c.getString(3);
                String artist = c.getString(4);
                String albumId = c.getString(5);


                String name = path.substring(path.lastIndexOf("/") + 1);

                audioModel.setItem_id(id);
                audioModel.setDownload_name(title);
                audioModel.setCategory_name(album);
                audioModel.setItem_description(artist);
                audioModel.setItem_name(title);
                audioModel.setItem_file(path);
                try {
                    if(albumId!=null && !albumId.isEmpty()){
                        audioModel.setItem_image(String.valueOf(getAlbumArtUri(Long.parseLong(albumId))));
                    }
                } catch (NumberFormatException e) {
                    Log.e("ERROR",e.toString());
                    e.printStackTrace();
                }
                audioModel.setCategory_id(albumId);


                Log.e("Name :" + name, " Album :" + album);
                Log.e("Path :" + path, " Artist :" + artist);

                localSongList.add(audioModel);
            }
            c.close();
        }
        String json = new Gson().toJson(localSongList);
        Log.e("audioList :", json);

        if (localSongList != null && !localSongList.isEmpty()) {
            noSongList.setVisibility(View.GONE);
            songListAdapter = new LocalSongAdapter(mContext, localSongList, this);
            songlistRecycler.setAdapter(songListAdapter);
            songListAdapter.notifyDataSetChanged();
        } else {
            noSongList.setVisibility(View.VISIBLE);
            songlistRecycler.setVisibility(View.GONE);
        }


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getAllAudioFromDevice(mContext);
            } else {
                // Permission Denied
                requestRead();
                Toast.makeText(mContext, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private static Uri getAlbumArtUri(long albumId) {
        return ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId);
    }

}
