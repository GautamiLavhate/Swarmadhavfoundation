package com.applexinfotech.swarmadhavfoundation.model;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 1/2/2016.
 */
public class HomeModel extends MasterModel
{
    private static final long serialVersionUID = 6104048947898684570L;

    private String category_id;
    private String category_name;
    private String category_image;
    private String isSubcategoryAvailable;
    private String TypeHm;

    public String getTypeHm() {
        return TypeHm;
    }

    public void setTypeHm(String typeHm) {
        TypeHm = typeHm;
    }

    public String getIsSubcategoryAvailable() {
        return isSubcategoryAvailable;
    }

    public void setIsSubcategoryAvailable(String isSubcategoryAvailable) {
        this.isSubcategoryAvailable = isSubcategoryAvailable;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_image() {
        return category_image;
    }

    public void setCategory_image(String category_image) {
        this.category_image = category_image;
    }
}
