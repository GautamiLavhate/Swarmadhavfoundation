package com.applexinfotech.swarmadhavfoundation.fragment;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.BuildConfig;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.CircularSeekBar;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.MusicStateListener;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.ArrayList;

import jp.wasabeef.glide.transformations.BlurTransformation;

import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.ASSET_IMAGE_FOLDER_PATH;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 03-01-2016.
 */
public class Streaming extends MasterFragment implements MusicStateListener {
    private View rootView;
    private ImageView backgroundImageView;
    private TextView artistNameView;
    private TextView albumNameView;
    private ImageView trackImageView;
    private TextView trackNameView;
    private TextView currentDuration;
    private CircularSeekBar seekBarView;
    private TextView finalDuration;
    private ImageButton prevButton;
    private ImageButton playButton;
    private ImageButton nextButton;
    private ImageButton repeatButton;
    private ImageButton shuffleButton;
    private ImageButton viewPDF,viewLyries,add_to_playlistimg;
    private final Handler mHandler = new Handler();
    private Utilities utils;
    private ProgressBar progressBar;
    //  private AsyncRunner mTask;
    private Boolean isPlaying;
    String imageUrl;
    private Bundle bundle;
    //    protected static FFmpegMediaPlayer freePlayer;
    MainActivity mContext;
    private boolean isRepeat = false;
    private boolean isShuffle = false;
    ArrayList<SubCategoryModel> ListItem = new ArrayList<>();
    ArrayList<String> ListItemFile = new ArrayList<>();
    ArrayList<String> ListItemName = new ArrayList<>();
    ArrayList<String> ListItemImage = new ArrayList<>();
    int ListPosition;
    SubHomeCategory homeModelSub;
    HomeModel homeModel;
    SubCategoryModel subCategoryModelList;
    private static final float BLUR_RADIUS = 25f;
    String item_description = null, trackUrl = null, item_id = null, item_image = null, item_name = null;
    private int mode;
    ProgressDialog mProgressDialog;
    String Filefolder,LyriesTextview;
    private InterstitialAd interstitial;
    private  ArrayList<Object> categoryListWIthAd;
    private AdView adView;
    private InterstitialAd interstitialAd;
    private SubCategoryModel currentlyPlaying;
    private String isFrom;
    private int noOfRepeats;
    private RelativeLayout playPauseLayout;
    private static final String[] PERMISSIONS = {android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // get root view
        mContext = (MainActivity) getMasterActivity();
        ActivityCompat.requestPermissions(mContext, PERMISSIONS, 112);
        rootView = inflater.inflate(R.layout.streaming_player, container, false);
        //Utilities.hideKeyboard(getMasterActivity());
      //  mContext.hideDrawer();
        mContext.showDrawerBack();

        utils = new Utilities();
        ((MainActivity) getActivity()).setMusicStateListenerListener(this);
        ((MainActivity) getActivity()).bottum_layout.setVisibility(View.GONE);

        bundle = getArguments();
        if (bundle != null) {
       if(MainActivity.AudioType.equals("SUBCATID")) {


               mode = bundle.getInt("mode");
               isFrom = bundle.getString("isFrom");
               Log.e("mode", ":" + String.valueOf(mode));
               Log.e("isFrom", ":" + isFrom);

               ListItem = (ArrayList<SubCategoryModel>) bundle.getSerializable("data");
               ListPosition = bundle.getInt("position");

               Log.d("ListPosition", "" + ListPosition);
               if (bundle.containsKey("CAT_ID")) {
                   homeModelSub = (SubHomeCategory) bundle.getSerializable("CAT_ID");
               }
               if (ListItem != null && ListItem.size() > 0 && ListPosition < ListItem.size()) {
                   mContext.setTitle(" " + ListItem.get(ListPosition).getItem_name());
                   //Filefolder = ListItem.get(ListPosition).getLyrics_filePdf();
                   Filefolder="http://maven.apache.org/maven-1.x/maven.pdf";
                   LyriesTextview= ListItem.get(ListPosition).getLyrics_file();
               }

       }else if(MainActivity.AudioType.equals("MainAudio")) {
               mode = bundle.getInt("mode");
               isFrom = bundle.getString("isFrom");
               Log.e("mode", ":" + String.valueOf(mode));
               Log.e("isFrom", ":" + isFrom);

               ListItem = (ArrayList<SubCategoryModel>) bundle.getSerializable("data");
               ListPosition = bundle.getInt("position");


               Log.d("ListPosition", "" + ListPosition);
               if (bundle.containsKey("CAT_ID")) {
                   homeModel = (HomeModel) bundle.getSerializable("CAT_ID");
               }
               if (ListItem != null && ListItem.size() > 0 && ListPosition < ListItem.size()) {
                   mContext.setTitle(" " + ListItem.get(ListPosition).getItem_name());
                   Filefolder = ListItem.get(ListPosition).getLyrics_filePdf();
                   LyriesTextview= ListItem.get(ListPosition).getLyrics_file();
               }

           }
       }

        // initialize ui elements
        backgroundImageView = rootView.findViewById(R.id.backgroundImage);
        albumNameView = rootView.findViewById(R.id.albumName);
        trackImageView = rootView.findViewById(R.id.trackImage);
        trackNameView = rootView.findViewById(R.id.trackName);
        currentDuration = rootView.findViewById(R.id.currentDuration);
        seekBarView = rootView.findViewById(R.id.seekBar);
        finalDuration = rootView.findViewById(R.id.finalDuration);
        prevButton = rootView.findViewById(R.id.prevButton);
        playButton = rootView.findViewById(R.id.playButton);
        nextButton = rootView.findViewById(R.id.nextButton);
        playPauseLayout = rootView.findViewById(R.id.play_pause_layout);
        repeatButton = rootView.findViewById(R.id.repeatButton);
        shuffleButton = rootView.findViewById(R.id.shuffleButton);
        progressBar = rootView.findViewById(R.id.progressBar3);
        viewPDF = rootView.findViewById(R.id.viewPDF);
        viewLyries= rootView.findViewById(R.id.viewLyries);
        add_to_playlistimg= rootView.findViewById(R.id.add_to_playlistimg);
        albumNameView.setMovementMethod(new ScrollingMovementMethod());
        setProgressAndButtonState(false);


        Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_forward_next);
        mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.ActionBar), PorterDuff.Mode.MULTIPLY));
       // nextButton.setImageDrawable(mDrawable);
        ViewCompat.setBackgroundTintList(nextButton, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.iconPrimaryColor)));
        Drawable mDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_back_prev);
        mDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.ActionBar), PorterDuff.Mode.MULTIPLY));
      //  prevButton.setImageDrawable(mDrawable1);
        ViewCompat.setBackgroundTintList(prevButton, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.iconPrimaryColor)));
        ViewCompat.setBackgroundTintList(playPauseLayout, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.ActionBar)));
        seekBarView.setPointerColor(ContextCompat.getColor(mContext, R.color.NewSubCatrgory));
        seekBarView.setCircleColor(ContextCompat.getColor(mContext, R.color.iconPrimaryColor));
        seekBarView.setCircleProgressColor(ContextCompat.getColor(mContext, R.color.NewListItems));

        if (isFrom.equalsIgnoreCase(Constants.CATEGORY_MINI_PLAYER) || isFrom.equalsIgnoreCase(Constants.HOME)) {
            progressBar.setVisibility(View.GONE);
        }
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mContext.isPlaying()) {
                    ((MainActivity) getActivity()).bottum_layout.setVisibility(View.VISIBLE);
                    setProgressAndButtonState(true);
                    mContext.onBackPressed();
                } else {
                    ((MainActivity) getActivity()).bottum_layout.setVisibility(View.GONE);
                    setProgressAndButtonState(false);
                    mContext.onBackPressed();
                }
              //  ((MainActivity) getActivity()).bottum_layout.setVisibility(View.VISIBLE);


            }
        });

        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mContext.isPlaying()) {
                    ((MainActivity) getActivity()).bottum_layout.setVisibility(View.VISIBLE);
                    setProgressAndButtonState(true);
                    mContext.onBackPressed();
                } else {
                    ((MainActivity) getActivity()).bottum_layout.setVisibility(View.GONE);
                    setProgressAndButtonState(false);
                    mContext.onBackPressed();
                }
            }
        });

            updateBottomPlayer();

        setShuffleRepeatColor(mContext.isRepeat(), mContext.isShuffle());


        playButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // check for already playing
                if (MasterActivity.player != null) {

                        if (mContext.isPlaying()) {
                            mContext.pauseSong();
                            // Changing button image to play button
                            setPlayPauseIcon(false);
                            // }
                        } else {
                        // Resume song
                        Log.e("isFromMiniPlayer", String.valueOf(MasterActivity.isFromMiniPlayer));
                        if (isFrom.equalsIgnoreCase(Constants.CATEGORY_MINI_PLAYER) || isFrom.equalsIgnoreCase(Constants.HOME) && MasterActivity.isFromMiniPlayer) {
                            MasterActivity.isFromMiniPlayer = false;
                            mContext.startPlaying();
                            // Changing button image to pause button
                            setPlayPauseIcon(true);
                        } else {
                            if (MasterActivity.isPlayerPrepared()) {
                                mContext.startPlaying();
                                // Changing button image to pause button
                                setPlayPauseIcon(true);
                            }
                        }
                        playButton.setEnabled(false);
                        playButton.setClickable(false);
                        // }
                    }
                }
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                setProgressAndButtonState(false);
                mHandler.removeCallbacks(mUpdateTimeTask);
                mContext.setNextTrack();
            }
        });

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                setProgressAndButtonState(false);
                mHandler.removeCallbacks(mUpdateTimeTask);
                mContext.setPreviousTrack();
            }
        });

        repeatButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                alertFormElements();
            }
        });

        shuffleButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (isShuffle) {
                    isShuffle = false;
                    ToastUtil.showShortToastMessage(getActivity(), getString(R.string.shuffl_off));
                    //shuffleButton.setBackgroundResource(R.drawable.shuffle_off);
                    setShuffleRepeatColor(mContext.isRepeat(), isShuffle);
                } else {
                    // make repeat to true
                    isShuffle = true;
                    ToastUtil.showShortToastMessage(getActivity(), getString(R.string.shuffle_on));
                    // make shuffle to false
                    isRepeat = false;
                    mContext.setRepeatMode(isRepeat);
                    // shuffleButton.setBackgroundResource(R.drawable.shuffle_on);
                    //  repeatButton.setBackgroundResource(R.drawable.repeat_off);
                    setShuffleRepeatColor(isRepeat, isShuffle);
                }
                mContext.setShuffleMode(isShuffle);
            }
        });

        seekBarView.setOnSeekBarChangeListener(new CircularSeekBar.OnCircularSeekBarChangeListener() {
            @Override
            public void onProgressChanged(CircularSeekBar seekBar, int progress, boolean fromUser) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onStartTrackingTouch(CircularSeekBar seekBar) {
                mHandler.removeCallbacks(mUpdateTimeTask);
            }

            @Override
            public void onStopTrackingTouch(CircularSeekBar seekBar) {

                mHandler.removeCallbacks(mUpdateTimeTask);
                //int totalDuration = mContext.mPlayer.getDuration();
                long totalDuration = mContext.getDuration();
                if (totalDuration > 0) {
                    long currentPosition = utils.progressToTimer(seekBar.getProgress(),totalDuration);

                    progressBar.setVisibility(View.VISIBLE);

                    //showWaitIndicator(true);
                    // forward or backward to certain seconds
                    mContext.seekTo(currentPosition);
                }
                // update timer progress again
                updateProgressBar();
                //   }
            }
        });

//        viewPDF.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (Filefolder.startsWith("https")) {
//                    if (Filefolder == null || Filefolder.equals("https://applexgroup.com/swarmadhav") || Filefolder.equals(" ")) {
//                        ToastUtil.showShortToastMessage(mContext, "No Pdf Data");
//                    } else {
//                        Intent target = new Intent(Intent.ACTION_VIEW);
//                        target.setDataAndType(Uri.parse(Filefolder), "application/pdf");
//                        target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//
//                        try {
//                            mContext.startActivity(target);
//                        } catch (ActivityNotFoundException e) {
//                            // Instruct the user to install a PDF reader here, or something
//                        }
//                    }
//                }else {
//
//                    if (Filefolder == null || Filefolder.equals(Constants.DIRECTORY_PATH+Constants.PDF_FOLDER_PATH)) {
//                        ToastUtil.showShortToastMessage(mContext, "No Pdf Data");
//                    } else {
//                        String Pdfoffline=Filefolder.replace("%20","");
//
//                        if (!hasPermissions(mContext, PERMISSIONS)) {
//
//                            Log.v("", "download() Method DON'T HAVE PERMISSIONS ");
//
//                            Toast t = Toast.makeText(getApplicationContext(), "You don't have read access !", Toast.LENGTH_LONG);
//                            t.show();
//
//                        } else {
//                            File pdfFile = new File(Pdfoffline);
//
//                            Log.v("", "view() Method pdfFile " + pdfFile.getAbsolutePath());
//
//                            //Uri path = FileProvider.getUriForFile(mContext, BuildConfig.APPLICATION_ID +  ".fileprovider", pdfFile);
//                            String path=Filefolder;
//
//                            Log.v("", "view() Method path " + path);
//
//                            Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
//                            pdfIntent.setDataAndType(Uri.parse(path), "application/pdf");
//                            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                            pdfIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//
//                            try {
//                                //startActivity(pdfIntent);
//                                ShowPDFFragment showpdf=new ShowPDFFragment();
//                                mContext.ReplaceFragment(showpdf);
//                            } catch (ActivityNotFoundException e) {
//                                Toast.makeText(mContext, "No Application available to view PDF", Toast.LENGTH_SHORT).show();
//                            }
//                        }
//
//                    }
//                }
//            }
//        });

        viewLyries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment investProgramDetail = new LyricsDialogFragment();
                Bundle bundle = new Bundle();
                bundle.putString("Lyries", LyriesTextview);
                investProgramDetail.setArguments(bundle);
                mContext.ReplaceFragment(investProgramDetail);
            }
        });

        add_to_playlistimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ListItem != null && ListItem.size() > 0 && ListPosition < ListItem.size()) {
                    subCategoryModelList =  (SubCategoryModel)ListItem.get(ListPosition);
                    String videoSt=subCategoryModelList.getVideo_url();
                    if(videoSt.equals("null")) {
                        FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                        AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("SongList", subCategoryModelList,"Audio");
                        infoDialog.setCancelable(false);
                        infoDialog.show(fragmentManager, "Dialog");
                    }else {
                        FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                        AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("SongList", subCategoryModelList,"Vedio");
                        infoDialog.setCancelable(false);
                        infoDialog.show(fragmentManager, "Dialog");
                    }

                }
            }
        });

        return rootView;
    }
    private void setPlayClickable() {
        boolean flag = false;
        if (MasterActivity.isPlayerPrepared()) {
            flag = true;
        }
        playButton.setEnabled(flag);
        playButton.setClickable(flag);
    }

    private void setProgressAndButtonState(boolean flag) {
        int visibility = View.GONE;
        if (!flag) {
            visibility = View.VISIBLE;
        }
        progressBar.setVisibility(visibility);
        nextButton.setEnabled(flag);
        prevButton.setEnabled(flag);
        nextButton.setClickable(flag);
        prevButton.setClickable(flag);
        seekBarView.setIsTouchEnabled(flag);
    }

    private void downloadPdfQue(SubCategoryModel subCategoryModel,int position){
        if (MasterActivity.downloadServiceBound){
            if (MasterActivity.downloadService != null){
                MasterActivity.downloadService.startDownloadingPdf(subCategoryModel,position);
            }
        }
    }

    private void updateView(SubCategoryModel currentlyPlaying, int mode) {
        Log.e("update view", "UPDATE");
        albumNameView.setText(currentlyPlaying.getItem_description());
        trackNameView.setText(currentlyPlaying.getItem_name());
        if (isVisible()) {
            if (currentlyPlaying.getItem_name() != null) {
                mContext.setTitle(" " + currentlyPlaying.getItem_name());
            }
        }
        if (currentlyPlaying.getItem_image().startsWith("https") || mode==3) {
            Glide.with(mContext).load(currentlyPlaying.getItem_image()).apply(RequestOptions.bitmapTransform(new BlurTransformation(25, 3))).placeholder(R.drawable.no_image).fitCenter().into(backgroundImageView);
            Glide.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fitCenter().into(trackImageView);
           // Picasso.with(getActivity()).load(currentlyPlaying.getItem_image()).transform(new BlurTransformation(mContext)).placeholder(R.drawable.no_image).fit().into(backgroundImageView);
           // Picasso.with(getActivity()).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fit().into(trackImageView);
        }else if(mode==4){
            Glide.with(mContext).load(ASSET_IMAGE_FOLDER_PATH+currentlyPlaying.getItem_image()).apply(RequestOptions.bitmapTransform(new BlurTransformation(25, 3))).placeholder(R.drawable.no_image).fitCenter().into(backgroundImageView);
            Glide.with(mContext).load(ASSET_IMAGE_FOLDER_PATH+currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fitCenter().into(trackImageView);
            //.with(getActivity()).load(ASSET_IMAGE_FOLDER_PATH+currentlyPlaying.getItem_image()).transform(new BlurTransformation(mContext)).placeholder(R.drawable.no_image).fit().into(backgroundImageView);
           // Picasso.with(getActivity()).load(ASSET_IMAGE_FOLDER_PATH+currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fit().into(trackImageView);
        } else {
            Glide.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fitCenter().into(backgroundImageView);

//            if (currentlyPlaying.getItem_image() != null) {
//                Bitmap bitmap = BitmapFactory.decodeFile(currentlyPlaying.getItem_image());
//                if(bitmap!=null){
//                    backgroundImageView.setImageBitmap(bitmap);
//                    trackImageView.setImageBitmap(bitmap);
//                }else {
//                    Glide.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fitCenter().into(backgroundImageView);
//                   // Picasso.with(mContext).load(currentlyPlaying.getItem_image()).placeholder(R.drawable.no_image).fit().into(backgroundImageView);
//                }
//            }
        }
        if (MasterActivity.isPlayerPrepared()) {
            // Changing button image to play button
            setPlayPauseIcon(mContext.isPlaying());
        } else {
            setPlayPauseIcon(false);
        }
        mHandler.removeCallbacks(mUpdateTimeTask);
        if (MasterActivity.isPlayerPrepared()) {
           // Log.e("restartLoader", "UPDATE_PROGRESS");
            updateProgressBar();
        }
    }


    @Override
    public void restartLoader() {
        mHandler.removeCallbacks(mUpdateTimeTask);
      //  Log.e("restartLoader", "UPDATE_PROGRESS");
        if (mContext.isPlaying()) {
            updateProgressBar();
        }
    }
    @Override
    public void stopProgressHandler() {
        Log.e("stopProgressHandler", "REMOVE_CALLBACKS");
        mHandler.removeCallbacks(mUpdateTimeTask);
    }

    @Override
    public void onMetaChanged() {
      //  Log.e("onMetaChanged", "UPDATE_VIEW");
        updateBottomPlayer();

    }

    private void updateBottomPlayer() {
        StorageUtil storage = new StorageUtil(getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        int audioIndex = storage.loadAudioIndex();
        int mode = storage.loadMode();
        if (audioList == null) {
            return;
        }
        updateView(audioList.get(audioIndex),mode);
    }


    private final Runnable mUpdateTimeTask = new Runnable() {
        public void run() {

            try {
                if (mContext.isPlaying()) {
                    setPlayClickable();
                    long totalDuration = mContext.getDuration();
                    long currentDurations = mContext.getCurrentPosition();
                    // Log.e("totalDuration: ", String.valueOf(totalDuration));
                  //   Log.e("currentDurations: ", String.valueOf(currentDurations));
                    if (totalDuration > 0) {
                        // Displaying Total Duration time
                        long reduse = totalDuration - currentDurations;
                        // Log.e("reduse: ", String.valueOf(reduse));
                        finalDuration.setText("-" + utils.milliSecondsToTimer(reduse));
                        // Displaying time completed playing
                        currentDuration.setText("" + utils.milliSecondsToTimer(currentDurations));

                        // Updating progress bar
                        int progress = (utils.getProgressPercentage(currentDurations, totalDuration));
                       //  Log.e("progress: ", String.valueOf(progress));

                        //Log.d("Progress", ""+progress);
                        seekBarView.setProgress(progress);

                        if (mContext.isPlaying()) {
                            setProgressAndButtonState(true);
                        } else {
                            setProgressAndButtonState(false);
                        }

                    }
                    // Running this thread after 100 milliseconds
                    mHandler.postDelayed(this, 100);
                }
            } catch (Exception e) {

                e.printStackTrace();
            }


        }
    };


    public void updateProgressBar() {

        try {

            // if (mContext.mPlayer != null) {
            mHandler.postDelayed(mUpdateTimeTask, 100);
            //    }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

   /* public class BlurTransformation implements Transformation {

        final RenderScript rs;

        public BlurTransformation(Context context) {
            super();
            rs = RenderScript.create(context);
        }

        @Override
        public Bitmap transform(Bitmap bitmap) {
            // Create another bitmap that will hold the results of the filter.
            Bitmap blurredBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);

            // Allocate memory for Renderscript to work with
            Allocation input = Allocation.createFromBitmap(rs, blurredBitmap, Allocation.MipmapControl.MIPMAP_FULL, Allocation.USAGE_SHARED);
            Allocation output = Allocation.createTyped(rs, input.getType());

            // Load up an instance of the specific script that we want to use.
            ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
            script.setInput(input);

            // Set the blur radius
            script.setRadius(5f);

            // Start the ScriptIntrinisicBlur
            script.forEach(output);

            // Copy the output to the blurred bitmap
            output.copyTo(blurredBitmap);

            bitmap.recycle();

            return blurredBitmap;
        }

        @Override
        public String key() {
            return "blur";
        }

    }*/


    //* Show AlertDialog with some form elements.

    public void alertFormElements() {


        // * Inflate the XML view. activity_main is in
        // * res/layout/form_elements.xml

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View formElementsView = inflater.inflate(R.layout.form_elements,
                null, false);

        // You have to list down your form elements

        final RadioGroup countRadioGroup = formElementsView
                .findViewById(R.id.countRadioGroup);

        RadioButton radio_3 = formElementsView.findViewById(R.id.radio_3);
        RadioButton radio_5 = formElementsView.findViewById(R.id.radio_5);
        RadioButton radio_9 = formElementsView.findViewById(R.id.radio_9);
        RadioButton radio_11 = formElementsView.findViewById(R.id.radio_11);
        RadioButton radio_108 = formElementsView.findViewById(R.id.radio_108);

        final EditText countEditText = formElementsView
                .findViewById(R.id.countEditText);
        Button buttonOn = formElementsView.findViewById(R.id.onButton);
        Button buttonOff = formElementsView.findViewById(R.id.offButton);

        if (mContext.getNoOfRepeats() != 0) {
            if (MasterActivity.isFromRadio) {
                int checkValue = mContext.getNoOfRepeats();
                switch (checkValue) {
                    case 3:
                        radio_3.setChecked(true);
                        break;
                    case 5:
                        radio_5.setChecked(true);
                        break;
                    case 9:
                        radio_9.setChecked(true);
                        break;
                    case 11:
                        radio_11.setChecked(true);
                        break;
                    case 108:
                        radio_108.setChecked(true);
                        break;
                }
            } else {
                countEditText.setText(String.valueOf(mContext.getNoOfRepeats()));
            }
        }
        // the alert dialog
        final AlertDialog dialog = new AlertDialog.Builder(mContext).setView(formElementsView)
                .setTitle(R.string.how_many_times_to_repeat).show();

        buttonOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String toastString = "";
                // get selected radio button from radioGroup
                int selectedId = countRadioGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                RadioButton selectedRadioButton = formElementsView.findViewById(selectedId);
                if (selectedRadioButton != null) {
                    toastString += getString(R.string.selected_radio_button_is) + selectedRadioButton.getTag() + "\n";
                    ToastUtil.showLongToastMessage(mContext, toastString);
                    noOfRepeats = Integer.parseInt(selectedRadioButton.getTag().toString());
                    MasterActivity.isFromRadio = true;
                } else {
                    if (TextUtils.isEmpty(countEditText.getText())) {
                        ToastUtil.showLongToastMessage(mContext, getString(R.string.select_how_many_times_to_repeat));
                        return;
                    }
                    toastString += getString(R.string.selectoin_is) + countEditText.getText() + "\n";
                    ToastUtil.showLongToastMessage(mContext, toastString);
                    noOfRepeats = Integer.parseInt(countEditText.getText().toString());
                    MasterActivity.isFromRadio = false;
                }
                // make repeat to true
                isRepeat = true;
                ToastUtil.showShortToastMessage(getActivity(), getString(R.string.repeat_on));
                // make shuffle to false
                isShuffle = false;
                mContext.setShuffleMode(isShuffle);
                // repeatButton.setBackgroundResource(R.drawable.repeat_on);
                //shuffleButton.setBackgroundResource(R.drawable.shuffle_off);
                setShuffleRepeatColor(isRepeat, isShuffle);
                mContext.setNoOfRepeats(noOfRepeats);
                mContext.setRepeatMode(isRepeat);
                dialog.cancel();
                // Utilities.hideKeyboard(getMasterActivity());
            }

        });
        buttonOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if (isRepeat) {
                isRepeat = false;
                ToastUtil.showShortToastMessage(getActivity(), getString(R.string.repeat_off));
                //  repeatButton.setBackgroundResource(R.drawable.repeat_off);
                setShuffleRepeatColor(isRepeat, isShuffle);
                Utilities.hideKeyboard(getMasterActivity());
                dialog.cancel();
                // Utilities.hideKeyboard(getMasterActivity());
                //  }
                mContext.setNoOfRepeats(0);
                mContext.setRepeatMode(isRepeat);
                setShuffleRepeatColor(isRepeat, isShuffle);
            }
        });
    }

    public void setShuffleRepeatColor(boolean isRepeat, boolean isShuffle) {
        int repeatColor, shuffleColor;
        if (isRepeat) {
            repeatColor = R.drawable.ic_reload_sawrn;
            shuffleColor = R.drawable.ic_shuffle_off_swarn;
        } else if (isShuffle) {
            repeatColor = R.drawable.ic_reload_off_swarn;
            shuffleColor = R.drawable.ic_shuffle_swarn;
        } else {
            repeatColor = R.drawable.ic_reload_off_swarn;
            shuffleColor = R.drawable.ic_shuffle_off_swarn;
        }

        Drawable mDrawable = ContextCompat.getDrawable(mContext, repeatColor);
       // mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, repeatColor), PorterDuff.Mode.MULTIPLY));
        repeatButton.setImageDrawable(mDrawable);
        ViewCompat.setBackgroundTintList(repeatButton, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.iconPrimaryColor)));
        Drawable mDrawable1 = ContextCompat.getDrawable(mContext, shuffleColor);
      //  mDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, shuffleColor), PorterDuff.Mode.MULTIPLY));
        shuffleButton.setImageDrawable(mDrawable1);
        ViewCompat.setBackgroundTintList(shuffleButton, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.iconPrimaryColor)));

    }

    public void setPlayPauseIcon(boolean isPlaying) {

        if (isPlaying) {
            Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.pause);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.ActionBar), PorterDuff.Mode.MULTIPLY));
            playButton.setImageDrawable(mDrawable);
            ViewCompat.setBackgroundTintList(playButton, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.iconPrimaryColor)));
            playButton.setPadding(0, 0, 0, 0);
        } else {
            Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_action_play);
            mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.ActionBar), PorterDuff.Mode.MULTIPLY));
            playButton.setImageDrawable(mDrawable);
            ViewCompat.setBackgroundTintList(playButton, ColorStateList.valueOf(ContextCompat.getColor(mContext, R.color.iconPrimaryColor)));
            playButton.setPadding(8, 0, 0, 0);
        }

    }
}