package com.applexinfotech.swarmadhavfoundation.common.util;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
