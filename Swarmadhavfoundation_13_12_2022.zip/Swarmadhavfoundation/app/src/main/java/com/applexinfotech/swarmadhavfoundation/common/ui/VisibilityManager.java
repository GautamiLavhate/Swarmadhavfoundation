package com.applexinfotech.swarmadhavfoundation.common.ui;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 13/09/15.
 */
public class VisibilityManager {
    private boolean mIsVisible = false;

    public void setIsVisible(boolean visible) {
        mIsVisible = visible;
    }

    public boolean getIsVisible() {
        return mIsVisible;
    }
}