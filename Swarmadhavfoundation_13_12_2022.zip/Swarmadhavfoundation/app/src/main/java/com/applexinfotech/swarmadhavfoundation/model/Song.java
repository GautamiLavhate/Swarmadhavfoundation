package com.applexinfotech.swarmadhavfoundation.model;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Song extends RealmObject {
    @PrimaryKey
    private String item_id;
    private String item_name;
    private String item_description;
    private String download_name;
    private String item_file;
    private String item_image;
    private String lyrics_file;

    private String category_id;
    private String category_name;
    private String category_image;
    private String video_url;
    private String lyrics_filePdf;
    private String update_count;

    public String getUpdate_count() {
        return update_count;
    }

    public void setUpdate_count(String update_count) {
        this.update_count = update_count;
    }




    public String getLyrics_filePdf() {
        return lyrics_filePdf;
    }

    public void setLyrics_filePdf(String lyrics_filePdf) {
        this.lyrics_filePdf = lyrics_filePdf;
    }

    public Song() {
    }

    public Song(SubCategoryModel subCategoryModel) {
        this.item_id = subCategoryModel.getItem_id();
        this.item_name = subCategoryModel.getItem_name();
        this.item_description = subCategoryModel.getItem_description();
        this.download_name = subCategoryModel.getDownload_name();
        this.item_file = subCategoryModel.getItem_file();
        this.item_image = subCategoryModel.getItem_image();
        this.lyrics_file = subCategoryModel.getLyrics_file();
        this.category_id = subCategoryModel.getCategory_id();
        this.category_name = subCategoryModel.getCategory_name();
        this.category_image = subCategoryModel.getCategory_image();
        this.video_url = subCategoryModel.getVideo_url();
        this.lyrics_filePdf = subCategoryModel.getLyrics_filePdf();
        this.update_count = subCategoryModel.getUpdate_count();
    }

    public String getVideo_url() {
        return video_url;
    }

    public void setVideo_url(String video_url) {
        this.video_url = video_url;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getItem_description() {
        return item_description;
    }

    public void setItem_description(String item_description) {
        this.item_description = item_description;
    }

    public String getDownload_name() {
        return download_name;
    }

    public void setDownload_name(String download_name) {
        this.download_name = download_name;
    }

    public String getItem_file() {
        return item_file;
    }

    public void setItem_file(String item_file) {
        this.item_file = item_file;
    }

    public String getItem_image() {
        return item_image;
    }

    public void setItem_image(String item_image) {
        this.item_image = item_image;
    }

    public String getLyrics_file() {
        return lyrics_file;
    }

    public void setLyrics_file(String lyrics_file) {
        this.lyrics_file = lyrics_file;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_image() {
        return category_image;
    }

    public void setCategory_image(String category_image) {
        this.category_image = category_image;
    }
}
