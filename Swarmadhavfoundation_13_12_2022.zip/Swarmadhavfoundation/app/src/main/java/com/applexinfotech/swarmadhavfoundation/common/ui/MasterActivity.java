package com.applexinfotech.swarmadhavfoundation.common.ui;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.equalizer.AudioSessionChangedListener;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.MusicStateListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.HomeModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.service.DownloadService;
import com.applexinfotech.swarmadhavfoundation.service.MediaPlayerService;

import java.io.File;
import java.util.ArrayList;

import static com.applexinfotech.swarmadhavfoundation.service.MediaPlayerService.SESSION_ID_NOT_SET;

/**
 * Created by JD(jikadrajaydeep@gmail.com) on 02-01-2016.
 */
public class MasterActivity extends AppCompatActivity {

    public boolean isInternet;

    public static Typeface font;

    ProgressDialog mProgressDialog;

    public Bundle bundle = new Bundle();

    public static ArrayList<HomeModel> CatArrayMaster = new ArrayList<>();

    public static int listScreen = 0, playScreen = 0;
    public NotificationManager mNotificationManager;
    public static boolean musicBound = false;
    public static Intent playIntent;

    public static boolean isFromMiniPlayer = true;
    public static MediaPlayerService player;
    public static boolean serviceBound = false;
    public static BroadcastReceiver mPlaybackStatus;
    public static final ArrayList<MusicStateListener> mMusicStateListener = new ArrayList<>();
    public static final ArrayList<AudioSessionChangedListener> mAudioSessionChangeListener = new ArrayList<com.applexinfotech.swarmadhavfoundation.equalizer.AudioSessionChangedListener>();
    public static boolean isFromRadio = false;
    public static DownloadService downloadService;
    public static boolean downloadServiceBound;
    public static boolean notificationBound;
    public static final ArrayList<DownloadListener> mDownloadStateListener = new ArrayList<>();
    public static ArrayList<HomeModel> catArrayList = new ArrayList();
    public static ArrayList<SubCategoryModel> mostPlayedList = new ArrayList();
    public static ArrayList<SubCategoryModel> mostDownloadedList = new ArrayList();
    public static ArrayList<SubCategoryModel> assetsSongList = new ArrayList();

    public static  ArrayList<HomeModel> catArrayListvedio = new ArrayList();

    public static ArrayList<Object> songWithAd = new ArrayList<>();  // for category fragment
    public static ArrayList<Object> songListWithAd = new ArrayList<>(); //for songList fragment
    public static ArrayList<Object> categoryListWithAd = new ArrayList<>(); //for home fragment

    public static String title;

    public Integer verifyP = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        isInternet = InternetStatus.isInternetOn(this);
    }

    public void setVerifyP(Integer i) {
            verifyP = i;
    }
    public Integer getVerifyP() {
        return verifyP;
    }
    public void setTitle(String title) {
        TextView titleTextView = findViewById(R.id.title_text);
        titleTextView.setVisibility(View.VISIBLE);
        titleTextView.setText(title);

    }

    public void setTextSize(int title_text_size) {
        TextView titleTextView = findViewById(R.id.title_text);
        titleTextView.setTextSize(title_text_size);
    }

    public Typeface getTypeFace() {
        font = Typeface.createFromAsset(getAssets(), "ProximaNova-Light.otf");
        return font;
    }

//    public void showDrawer() {
//        ImageView drawer_indicator = findViewById(R.id.drawer_indicator);
//        drawer_indicator.setVisibility(View.VISIBLE);
//    }
//
//    public void hideDrawer() {
//        ImageView drawer_indicator = findViewById(R.id.drawer_indicator);
//        drawer_indicator.setVisibility(View.INVISIBLE);
//    }

    public void showDrawerBack() {
        ImageButton drawer_back = findViewById(R.id.drawer_back);
        drawer_back.setVisibility(View.VISIBLE);
        hideSearch();
        hideNotification();
    }

    public void hideDrawerBack() {
        ImageButton drawer_back = findViewById(R.id.drawer_back);
        drawer_back.setVisibility(View.INVISIBLE);
        showSearch();
    }

    public void showSearch() {
        ImageButton actionSearch = findViewById(R.id.action_search);
        actionSearch.setVisibility(View.VISIBLE);
    }

    public void hideSearch() {
        ImageButton actionSearch = findViewById(R.id.action_search);
        //actionSearch.setImageDrawable(getDrawable(R.drawable.ic_notification_swar));
        actionSearch.setVisibility(View.GONE);
    }
    public void showNotification() {
        ImageButton actionSearch = findViewById(R.id.action_notification);
        actionSearch.setVisibility(View.VISIBLE);
    }

    public void hideNotification() {
        ImageButton actionSearch = findViewById(R.id.action_notification);

        actionSearch.setVisibility(View.GONE);
    }

    public void showWaitIndicator(boolean state) {
        showWaitIndicator(state, "");
    }

    public void showWaitIndicator(boolean state, String message) {
        try {
            try {

                if (state) {
                    if (mProgressDialog!=null && mProgressDialog.isShowing()) {
                        mProgressDialog.dismiss();
                    }
                    mProgressDialog = new ProgressDialog(MasterActivity.this,
                            R.style.TransparentProgressDialog);
                    mProgressDialog
                            .setProgressStyle(android.R.style.Widget_ProgressBar_Large);
                    mProgressDialog.setCancelable(false);
                    mProgressDialog.show();
                } else {
                    mProgressDialog.dismiss();
                }

            } catch (Exception e) {


            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        try {
            if(mPlaybackStatus!=null){
                unregisterReceiver(mPlaybackStatus);
            }
        } catch (final Throwable e) {
        }
        super.onDestroy();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void setNextTrack() {
        player.playNextTrack();
    }

    public static boolean isPlayerPrepared() {
        if (player == null) {
            return false;
        }
        return player.isPlayerPrepared();
    }

    public static boolean isSongCompleted() {
        if (player == null) {
            return false;
        }
        return player.isSongCompleted();
    }

    public void setPreviousTrack() {
        player.playPreviousTrack();
    }

    public void seekTo(long currentPosition) {
        player.seekTo(currentPosition);
    }

    public long getDuration() {
        // Log.e("player.getDuration(): " , String.valueOf(player.getDuration()));
        return player.getDuration();
    }

    public long getCurrentPosition() {
        return player.getCurrentPosition();
    }

    public boolean isPlaying() {
        if (player != null)
            return player.isMediaPlaying();
        else
            return false;
    }

    public void setShuffleMode(Boolean bool) {
        player.setShuffleMode(bool);
    }

    public void setRepeatMode(Boolean bool) {
        player.setRepeat(bool);
    }

    public boolean isShuffle() {
        if (player != null)
            return player.isShuffle();
        else
            return false;
    }

    public boolean isRepeat() {
        if (player != null)
            return player.isRepeat();
        else
            return false;
    }

    public void setNoOfRepeats(int count) {
        player.setNoOfRepeats(count);
    }

    public int getNoOfRepeats() {
        return player.getNoOfRepeats();
    }


    public void playSong() {
        player.playSong();
    }

    public void setMode(int mode) { //from download=1 or Streaming=0
        player.setMode(mode);
    }

    public void startPlaying() {
        player.resumeMediaPlay();
    }
    public void setIsFromUSB(Boolean bool) {
        if (player != null)
        player.setFromUSB(bool);
    }
    public void setSongList(ArrayList<SubCategoryModel> ListItem) {
        //pass list
        //  player.setAudioList(null);
        player.setAudioList(ListItem);
    }

    public void setSongPosition(int position) {
        //pass list
        player.setAudioIndex(position);
    }

    public void pauseSong() {
        player.pauseMediaPlay();
    }

    public SubCategoryModel getActiveAudio() {
        return player.getActiveAudio();
    }

    public int getAudioIndex() {
        return player.getAudioIndex();
    }

    public int getAudioSessionId() {
        if(player!=null){
            return player.getAudioSessionId();
        }
       return SESSION_ID_NOT_SET;
    }
    @Override
    protected void onStop() {
        super.onStop();
    }

    public static boolean fileAlreadyExist(String fileName) {
        String path = Constants.DIRECTORY_PATH + Constants.SONG_FOLDER_PATH;
        File myDir = null;
        myDir = new File(path);

        File outputFile = new File(myDir, fileName);
        Log.e("file", "" + outputFile);
        if (outputFile.exists()) {
            Log.e("fileAlreadyExist", "exist" + outputFile);
            return true;
        } else
            Log.e("fileAlreadyExist", "not exist");
        return false;
    }

    public void storeToRecentlyPlayed(SubCategoryModel activeAudio) {
        Log.e("ID : ", "==" + activeAudio.getItem_id());
        RealmHelper realmHelper = new RealmHelper();
        realmHelper.saveRecentlyPlayed(activeAudio);
    }

    public void requestSongStatusChangevedio() {
        StorageUtil storage = new StorageUtil(getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        int playedAudioIndex = storage.loadPlayedAudioIndex();
        Log.e("playedAudioIndex", String.valueOf(playedAudioIndex));
        if (audioList == null || playedAudioIndex == -1) {
            return;
        }

    }


}
