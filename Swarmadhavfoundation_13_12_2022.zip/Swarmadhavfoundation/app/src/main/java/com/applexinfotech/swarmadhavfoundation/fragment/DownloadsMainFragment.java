package com.applexinfotech.swarmadhavfoundation.fragment;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.adapter.ViewPagerAdapter;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.google.android.gms.ads.InterstitialAd;

public class DownloadsMainFragment extends MasterFragment implements TabLayout.OnTabSelectedListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private MainActivity mContext;
    Fragment fragment;
    private Bundle bundle;
    private InterstitialAd interstitial;
    Downloads downloads;
    String str;
    int demo;
    int demo2;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private int mPage;
    String value;


    public DownloadsMainFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static DownloadsMainFragment newInstance(String param1, String param2) {
        DownloadsMainFragment fragment = new DownloadsMainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_downloads_main, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle(getString(R.string.downloads));

        viewPager=view.findViewById(R.id.viewpager_downloads);
        tabLayout=view.findViewById(R.id.downloads_tabs);
        setupViewPager(viewPager);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(this);

        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        bundle=getArguments();
//       demo= bundle.getInt("COUNT");
//       Toast.makeText(mContext,String.valueOf(demo),Toast.LENGTH_LONG).show();
    }
    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFragment(new Downloads(),"Downloaded");
        adapter.addFragment(new DownloadingFragment(), "Downloading");
        viewPager.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        mPage = tab.getPosition();
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
}
