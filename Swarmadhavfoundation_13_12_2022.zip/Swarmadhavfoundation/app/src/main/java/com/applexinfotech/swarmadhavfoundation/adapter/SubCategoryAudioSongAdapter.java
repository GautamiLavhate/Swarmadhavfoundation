package com.applexinfotech.swarmadhavfoundation.adapter;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.CircularImageView;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.ClickGuard;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.downloadvedio.DownloadsMainVedioFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.AddPlaylistDialog;
import com.applexinfotech.swarmadhavfoundation.fragment.ShowPDFFragment;
import com.applexinfotech.swarmadhavfoundation.fragment.Streaming;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.Playlist;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;
import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.DOWNLOADS;
import static com.facebook.FacebookSdk.getApplicationContext;
import static com.applexinfotech.swarmadhavfoundation.MainActivity.Broadcast_PLAY_NEW_AUDIO;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.ASSET_IMAGE_FOLDER_PATH;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.CATEGORY;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_ASSETS;
import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.FROM_PLAYLIST;

public class SubCategoryAudioSongAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final RealmHelper realmHelper;
    private final LayoutInflater layoutInflater;

    // The list of banner ads and menu items.
    private ArrayList<Object> categoryListWIthAd;
    private final MainActivity mContext;
    private static int LIST_AD_DELTA = 0;
    private final String fragmentTag;
    private final SubHomeCategory homeModel;
    ArrayList<Playlist> playList;
    private Playlist selectedPlaylist;
    // A menu item view type.
    private static final int MENU_ITEM_VIEW_TYPE = 0;
    private PopupMenu menu;
    private int userMode = 0;
    // The banner ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;
    private static ArrayList<SongModel> songsID = new ArrayList<>();
    private OnItemClickListener mListener;
    String isFrom;
    private String fileName, imageName,lyricsFileName,lyricsPdf;

    private final ArrayList<SubCategoryModel> mItem = new ArrayList<>();
    private AlertDialog playlistDialog;
    SubCategoryModel subCategoryModel=new SubCategoryModel();


    public void setSelectedPlaylist(Playlist selectedPlaylist) {
        this.selectedPlaylist = selectedPlaylist;
    }

    public SubCategoryAudioSongAdapter(MainActivity context, ArrayList<Object> list, SubHomeCategory homeModel, String canonicalName, int listNoAdDelta) {
        mContext = context;
        this.categoryListWIthAd = list;
        Log.e("noOfItem", String.valueOf(this.categoryListWIthAd.size()));
        this.homeModel = homeModel;
        this.fragmentTag = canonicalName;
        LIST_AD_DELTA = listNoAdDelta;
        layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        isFrom=CATEGORY;
        if (fragmentTag.equals(FROM_PLAYLIST)) {
            userMode = 2;
        }else if (fragmentTag.equals(FROM_ASSETS)) {
            userMode = 4;
            isFrom=FROM_ASSETS;
        } else {
            userMode = 0;
        }

        for (Object recyclerItem : categoryListWIthAd) {
            if (recyclerItem instanceof SubCategoryModel) {
                SubCategoryModel model = (SubCategoryModel) recyclerItem;
                if (fragmentTag.equalsIgnoreCase("com.applex.swarsageetmala.fragment.SubCategoryAudioSongFragment")) {
                    if (homeModel != null) {
                        if (homeModel.getAudio_subcategory_name()!= null) {
                            model.setCategory_id(homeModel.getAudio_subcategory_id());
                            model.setCategory_image(homeModel.getAudio_subcategory_image());
                            model.setCategory_name(homeModel.getAudio_subcategory_name());
                            model.setTypeHm(homeModel.getTypeHm());
                        }
                    }
                }
                mItem.add(model);
            }


        }


        //Get path of song name
        realmHelper = new RealmHelper();
    }


    @Override
    public int getItemViewType(int position) {
        int viewType = MENU_ITEM_VIEW_TYPE;
      /*  if (LIST_AD_DELTA != 0) {   // LIST_AD_DELTA will be 0  when showListBannerAd=false in constants OR noInternet
            Object recyclerViewItem = categoryListWIthAd.get(position);
            if (recyclerViewItem instanceof UnifiedNativeAd) {
                viewType = UNIFIED_NATIVE_AD_VIEW_TYPE;
            }
        }*/
        return viewType;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
          /*  case UNIFIED_NATIVE_AD_VIEW_TYPE:
                View unifiedNativeLayoutView = LayoutInflater.from(
                        parent.getContext()).inflate(R.layout.,
                        parent, false);
                return new UnifiedNativeAdViewHolder(unifiedNativeLayoutView);*/
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                View menuItemLayoutView = LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.subcategory_list_item, parent, false);
                // menuItemLayoutView.setOnClickListener(mOnClickListener);
                return new SubCategoryAudioSongAdapter.MenuItemViewHolder(menuItemLayoutView);


        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            /*case UNIFIED_NATIVE_AD_VIEW_TYPE:
                UnifiedNativeAd nativeAd = (UnifiedNativeAd) categoryListWIthAd.get(position);
               // populateNativeAdView(nativeAd, ((UnifiedNativeAdViewHolder) holder).getAdView());
                break;*/
            case MENU_ITEM_VIEW_TYPE:
                // fall through
            default:
                final SubCategoryAudioSongAdapter.MenuItemViewHolder menuItemHolder = (SubCategoryAudioSongAdapter.MenuItemViewHolder) holder;
                final SubCategoryModel content = (SubCategoryModel) categoryListWIthAd.get(position);

                //Get path of song name
                songsID = new ArrayList<>();
                songsID = realmHelper.retrieveoAudioListDEmo();
                //menuItemHolder.tv_title.setTypeface(mContext.getTypeFace());
                menuItemHolder.tv_desc.setTypeface(mContext.getTypeFace());
                menuItemHolder.tv_duration.setTypeface(mContext.getTypeFace());

                menuItemHolder.tv_title.setText(content.getItem_name());
                menuItemHolder.tv_desc.setText(content.getItem_description());


                Drawable mDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                mDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.download.setImageDrawable(mDrawable);

                Drawable arrowDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                arrowDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.play.setImageDrawable(arrowDrawable);

                Drawable shareDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_share_new);
                shareDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.share.setImageDrawable(shareDrawable);

                Drawable playListDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_play_new);
                playListDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.addToPlaylist.setImageDrawable(playListDrawable);

                Drawable popupMenuDrawable = ContextCompat.getDrawable(mContext, R.drawable.ic_more_new);
                popupMenuDrawable.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                menuItemHolder.popupMenu.setImageDrawable(popupMenuDrawable);

                String access_status=content.getIs_accesible();
                //Toast.makeText(mContext,access_status,Toast.LENGTH_LONG).show();
               if (fragmentTag.equals(FROM_ASSETS)){
                    menuItemHolder.play.setVisibility(View.VISIBLE);
                   // menuItemHolder.download.setVisibility(View.VISIBLE);
                    menuItemHolder.share.setVisibility(View.GONE);
                    menuItemHolder.addToPlaylist.setVisibility(View.GONE);
                    menuItemHolder.popupMenu.setVisibility(View.GONE);
                   // menuItemHolder.mProgress.setVisibility(View.GONE);
                }else{
                    //menuItemHolder.play.setVisibility(View.VISIBLE);
                    menuItemHolder.popupMenu.setVisibility(View.VISIBLE);
                    menuItemHolder.download.setVisibility(View.VISIBLE);
                    //menuItemHolder.mProgress.setVisibility(View.GONE);
                    if (songsID != null) {

                        if (songsID.size() > 0) {

                            for (int i = 0; i < songsID.size(); i++) {

                                if (content.getItem_id().equals(songsID.get(i).getItem_id())) {

                                    if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                        // download
                                        menuItemHolder.download.setVisibility(View.GONE);
                                        menuItemHolder.download_complete.setVisibility(View.VISIBLE);
                                        content.setDownloaded(false);

                                    } else {

                                        content.setDownloaded(true);
                                        menuItemHolder.download.setVisibility(View.VISIBLE);
//                                        //menu.getMenu().findItem(R.id.download).setEnabled(true);
//                                        menu.getMenu().findItem(R.id.download).setTitle("Update");
                                    }
                                    break;
                                } else {
//                                    menuItemHolder.download.setVisibility(View.VISIBLE);
//                                    //menu.getMenu().findItem(R.id.download).setEnabled(true);
//                                    content.setDownloaded(false);
                                }
                            }
                        }
                    }else {
//                        menuItemHolder.download.setVisibility(View.GONE);
//                        menu.getMenu().findItem(R.id.download).setEnabled(false);
//                        content.setDownloaded(true);
                    }
                }
                if(fragmentTag.equals(FROM_ASSETS)){
                    Glide.with(mContext).load(ASSET_IMAGE_FOLDER_PATH+content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);
                   // Picasso.with(mContext).load(ASSET_IMAGE_FOLDER_PATH+content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);
                }
                else if (content.getItem_image().startsWith("https")) {
                    Glide.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);
                    //Picasso.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);
                } else {

                    Glide.with(mContext).load(content.getItem_image()).placeholder(R.drawable.no_image).into(menuItemHolder.cat_image);

                }
//                SubCategoryModel model=new SubCategoryModel();
//                model.setIs_accesible(model.getIs_accesible());
//                String accesible=subCategoryModel.getIs_accesible();
//                Toast.makeText(mContext,accesible,Toast.LENGTH_LONG).show();
                menuItemHolder.popupMenu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        if (menu != null) {
                            menu.dismiss();
                        }
                        menu = new PopupMenu(mContext, v);
                        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
                                    case R.id.popup_song_remove_playlist:
                                        boolean isCurrantSong = false;
                                        if (categoryListWIthAd != null && !categoryListWIthAd.isEmpty() && categoryListWIthAd.size() > position) {
                                            if (categoryListWIthAd.get(position) instanceof SubCategoryModel) {
                                                SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                                                StorageUtil storage = new StorageUtil(getApplicationContext());
                                                int currentPlaylistId = storage.loadCurrentPlaylistId();
                                                int mode=storage.loadMode();
                                                if ( mode == 2 && currentPlaylistId != -1) {
                                                    int selectedId = selectedPlaylist.getId();
                                                    if (currentPlaylistId == selectedId) {  //means current playlist is playing
                                                        String currentlyPlayingId = storage.loadAudio().get(storage.loadAudioIndex()).getItem_id();
                                                        isCurrantSong = currentlyPlayingId.equalsIgnoreCase(selectedObject.getItem_id());
                                                    }
                                                }
                                                if (isCurrantSong) {
                                                    Toast.makeText(mContext, R.string.you_can_not_remove_current_song, Toast.LENGTH_SHORT).show();
                                                } else {
                                                    removeSongFromPlaylist(selectedObject, position);
                                                }
                                            }
                                        }
                                        break;
                                    case R.id.popup_song_play:
                                        menuItemHolder.layout_main.performClick();
                                        break;
                                    case R.id.popup_song_addto_playlist:
                                        if (categoryListWIthAd != null && !categoryListWIthAd.isEmpty() && categoryListWIthAd.size() > position) {
                                            if (categoryListWIthAd.get(position) instanceof SubCategoryModel) {
                                                SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                                                String videoSt=selectedObject.getVideo_url();
                                                if(videoSt.equals("null")) {
                                                    FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                    AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("SongList", selectedObject,"Audio");
                                                    infoDialog.setCancelable(false);
                                                    infoDialog.show(fragmentManager, "Dialog");
                                                }else {
                                                    FragmentManager fragmentManager = mContext.getSupportFragmentManager();
                                                    AddPlaylistDialog infoDialog = AddPlaylistDialog.newInstance("SongList", selectedObject,"Vedio");
                                                    infoDialog.setCancelable(false);
                                                    infoDialog.show(fragmentManager, "Dialog");
                                                }
                                            }
                                        }
                                        break;
                                    case R.id.download:
                                        menuItemHolder.download.performClick();
                                        break;
                                    case R.id.downloadLyrics:
                                        SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                                        String Filefolder = selectedObject.getLyrics_filePdf();
                                        if(Filefolder==null || Filefolder.equals("http://swarsangitmala.in/") || Filefolder.equals(" ") ){
                                            ToastUtil.showShortToastMessage(mContext,"No Pdf Data");
                                        }else {
                                            Intent target = new Intent(Intent.ACTION_VIEW);
                                            target.setDataAndType(Uri.parse(Filefolder), "application/pdf");
                                            target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                                            try {
                                                mContext.startActivity(target);
                                            } catch (ActivityNotFoundException e) {
                                                // Instruct the user to install a PDF reader here, or something
                                            }
                                        }
                                        break;

                                }
                                return false;
                            }
                        });

                        menu.inflate(R.menu.popup_song);
                        menu.show();
                        if (fragmentTag.equals(FROM_PLAYLIST))
                            menu.getMenu().findItem(R.id.popup_song_remove_playlist).setVisible(true);
                        menu.getMenu().findItem(R.id.download).setVisible(true);
                        menu.getMenu().findItem(R.id.downloadLyrics).setVisible(false);
                       //menu.getMenu().findItem(R.id.popup_song_addto_playlist).setVisible(false);

                            if (songsID != null) {

                                if (songsID.size() > 0) {

                                    for (int i = 0; i < songsID.size(); i++) {

                                        if (content.getItem_id().equals(songsID.get(i).getItem_id())) {

                                            if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                                // download
                                                //menu.getMenu().findItem(R.id.download).setEnabled(false);
                                                menu.getMenu().findItem(R.id.download).setVisible(false);
                                                menu.getMenu().findItem(R.id.popup_song_downloaded).setVisible(true);
                                                menu.getMenu().findItem(R.id.popup_song_downloaded).setEnabled(false);
                                                //menu.getMenu().findItem(R.id.).setIcon(R.drawable.ic_download_complete);
                                                content.setDownloaded(false);

                                            } else {

                                                content.setDownloaded(true);
                                                menu.getMenu().findItem(R.id.download).setEnabled(true);
                                                menu.getMenu().findItem(R.id.download).setTitle("Update");
                                            }
                                            break;
                                        } else {
                                            menu.getMenu().findItem(R.id.download).setEnabled(true);
                                            content.setDownloaded(false);
                                        }
                                    }
                                }
                            }else {
                                menuItemHolder.download.setVisibility(View.GONE);
                                menu.getMenu().findItem(R.id.download).setEnabled(false);
                                content.setDownloaded(true);
                            }
                    }
                });

                menuItemHolder.download_complete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(mContext,"This song is downloaded...",Toast.LENGTH_LONG).show();
                    }
                });
                menuItemHolder.play.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        menuItemHolder.layout_main.performClick();
                    }


                });

                menuItemHolder.download.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //fresh download
                        SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                        selectedObject.setDownloaded(true);
                        int pos = getAudioIndexFromList(selectedObject.getItem_id());
                        mListener.onItemClick(v, pos, selectedObject);
                        menuItemHolder.download.setClickable(false);
                        ClickGuard.guard(menuItemHolder.download);
//                        Toast.makeText(mContext,"Downloading...",Toast.LENGTH_LONG).show();
//                        menuItemHolder.mProgress.setVisibility(View.VISIBLE);
                        menuItemHolder.download.setEnabled(false);
                        if (mListener != null) {
                            if (selectedObject.getCategory_id() == null) {
                                if (homeModel != null) {
                                    if (homeModel.getCategory_name() != null) {
                                        selectedObject.setCategory_id(homeModel.getAudio_subcategory_id());
                                        selectedObject.setCategory_image(homeModel.getAudio_subcategory_image());
                                        selectedObject.setCategory_name(homeModel.getAudio_subcategory_name());
                                        selectedObject.setTypeHm(homeModel.getTypeHm());
                                    }
                                }
                            }
                            if (selectedObject.isDownloaded) {

                                if (songsID != null) {

                                    if (songsID.size() > 0) {

                                        for (int i = 0; i < songsID.size(); i++) {

                                            if (content.getItem_id().equals(songsID.get(i).getItem_id())) {
                                                if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                                    // download
                                                    content.setDownloaded(false);
                                                    ToastUtil.showShortToastMessage(getApplicationContext(), "Already Downloading.." + selectedObject.getDownload_name());

                                                } else {
                                                    deleteSong(songsID,i);
                                                    //update code
                                                    pos = getAudioIndexFromList(selectedObject.getItem_id());
                                                    mListener.onItemClick(v, pos, selectedObject);
                                                    menuItemHolder.download.setClickable(false);
                                                    ClickGuard.guard(menuItemHolder.download);
                                                    selectedObject.setDownloaded(true);
                                                }
                                                break;
                                            }

                                        }
                                    }

                                }
                            } else {
                                //fresh download
                                pos = getAudioIndexFromList(selectedObject.getItem_id());
                                mListener.onItemClick(v, pos, selectedObject);
                                menuItemHolder.download.setClickable(false);
                                ClickGuard.guard(menuItemHolder.download);
                                selectedObject.setDownloaded(true);

                            }
                        }
                    }
                });

                if (!content.getItem_file().startsWith("https")) {
                    menuItemHolder.download.setVisibility(View.GONE);
                    content.setDownloaded(true);
                } else {
                    Drawable mDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_dowload_new);
                    mDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                    menuItemHolder.download.setImageDrawable(mDrawable1);
                    if (songsID != null) {

                        if (songsID.size() > 0) {

                            for (int i = 0; i < songsID.size(); i++) {

                                if (content.getItem_id().equals(songsID.get(i).getItem_id())) {
                                    if (content.getUpdate_count().equals(songsID.get(i).getUpdate_count())) {
                                        menuItemHolder.download.setVisibility(View.GONE);
                                        content.setDownloaded(true);
                                        menuItemHolder.download.setClickable(false);
                                        ClickGuard.guard(menuItemHolder.download);
                                        menuItemHolder.download.setOnClickListener(null);

                                    } else {
                                        content.setDownloaded(true);
                                        Drawable arrowDrawable1 = ContextCompat.getDrawable(mContext, R.drawable.ic_download_complete);

                                        arrowDrawable1.setColorFilter(new PorterDuffColorFilter(ContextCompat.getColor(mContext, R.color.iconPrimaryColor), PorterDuff.Mode.MULTIPLY));
                                        menuItemHolder.download.setBackgroundResource(0);
                                        menuItemHolder.download.setImageDrawable(arrowDrawable1);

                                    }
                                    break;
                                } else {
                                    content.setDownloaded(true);
                                }
                            }
                        }
                    }
                }


                menuItemHolder.layout_main.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                           SubCategoryModel selectedObject = (SubCategoryModel) categoryListWIthAd.get(position);
                            StorageUtil storage = new StorageUtil(getApplicationContext());
                            storage.clearCachedAudioPlaylist();
                            storage.storeAudio(mItem);
                            storage.storeAudioIndex(getAudioIndexFromList(selectedObject.getItem_id()));
                            storage.storeMode(userMode);
                            storage.storeIsPlayingFrom(isFrom);
                            mContext.setShuffleMode(false);
                            mContext.setRepeatMode(false);
                            mContext.setNoOfRepeats(0);
                            mContext.setMode(userMode);
                            mContext.stopProgressHandler();
                            if (MasterActivity.serviceBound && mContext.isPlaying()) {
                                if (selectedObject.getIs_accesible().equalsIgnoreCase("1")){
                                    Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
                                    mContext.sendBroadcast(broadcastIntent);
                                }else {
                                    //menuItemHolder.play.setVisibility(View.GONE);
                                }
                            } else if (MasterActivity.serviceBound) {
                                if (selectedObject.getIs_accesible().equalsIgnoreCase("1")) {
                                    mContext.playSong();
                                }
                                else {
                                    //menuItemHolder.play.setVisibility(View.GONE);
                                }
                            }
                            if (fragmentTag.equals(FROM_PLAYLIST)) {
                                storage.storeCurrentPlaylistId(selectedPlaylist.getId());
                            }

                            if (selectedObject.getIs_accesible().equalsIgnoreCase("1")){
                                Toast.makeText(mContext,"You can access song",Toast.LENGTH_LONG).show();
                                Fragment investProgramDetail = new Streaming();
                                MainActivity.AudioType="SUBCATID";
                                Bundle bundle = new Bundle();
                                bundle.putString("isFrom", isFrom);
                                bundle.putInt("mode", userMode);
                                bundle.putSerializable("data", mItem);
                                bundle.putInt("position", getAudioIndexFromList(selectedObject.getItem_id()));
                                bundle.putSerializable("CAT_ID", homeModel);
                                investProgramDetail.setArguments(bundle);
                                mContext.ReplaceFragment(investProgramDetail);
                            }else {
                                //menuItemHolder.play.setVisibility(View.GONE);
                                //Toast.makeText(mContext,"You can not access song",Toast.LENGTH_LONG).show();
                                menuItemHolder.download.setVisibility(View.GONE);
                                menuItemHolder.popupMenu.setVisibility(View.GONE);
                                AlertDialog();
                            }
                            //mContext.ReplaceFragment(investProgramDetail);



                    }
                });
                break;
        }
    }
    private void downloadPdfQue(SubCategoryModel subCategoryModel,int position){
        if (MasterActivity.downloadServiceBound){
            if (MasterActivity.downloadService != null){
                MasterActivity.downloadService.startDownloadingPdf(subCategoryModel,position);
            }
        }
    }
    public void AlertDialog(){
        final AlertDialog.Builder builder=new AlertDialog.Builder(mContext,R.style.NewCustomAlertDialog) ;
        builder.setMessage("You don't have access to play this song")
                .setCancelable(false)
                .setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .create()
                .show();

    }
    private void removeSongFromPlaylist(SubCategoryModel selectedObject, int position) {
        realmHelper.removeSongFromPlaylist(selectedPlaylist, selectedObject);
        StorageUtil storage = new StorageUtil(getApplicationContext());
        int currentPlaylistId = storage.loadCurrentPlaylistId();
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        String currentlyPlayingId = audioList.get(storage.loadAudioIndex()).getItem_id();
        if (audioList != null) {
            int selectedPlayList = selectedPlaylist.getId();
            if (storage.loadMode() == 2 && currentPlaylistId != -1) { //means not playing from playlist
                if (currentPlaylistId == selectedPlayList) {
                    for (SubCategoryModel model : audioList) {
                        if (model.getItem_id().equalsIgnoreCase(selectedObject.getItem_id())) {
                            audioList.remove(model);
                            storage.storeAudio(audioList);
                            break;
                        }
                    }
                    ArrayList<SubCategoryModel> currentQueue = storage.loadAudio();
                    for (int i = 0; i < currentQueue.size(); i++) {
                        if (currentQueue.get(i).getItem_id().equals(currentlyPlayingId)) {
                            storage.storeAudioIndex(i);
                            Log.e("New Index == ",String.valueOf(i));
                            break;
                        }
                    }

                }
            }
        }
        ToastUtil.showShortToastMessage(getApplicationContext(), selectedObject.getItem_name() + " removed from " + selectedPlaylist.getName());
        categoryListWIthAd.remove(position);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return categoryListWIthAd.size();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

   public class MenuItemViewHolder extends RecyclerView.ViewHolder {
        private final CircularImageView cat_image;
       public  ImageButton play;
        final ImageButton download;

        private final TextView tv_title;
        private final TextView tv_desc;
        private final TextView tv_duration;
        private String urls;
        private String imgpath;
        private final LinearLayout layout_main;
        LinearLayout linearLayoutSongDetail;
        public final ProgressBar downloadProgress;
       public   ProgressBar mProgress;
        final ImageButton share;
        final ImageButton addToPlaylist;
        final ImageButton popupMenu;
        private ImageButton download_complete;

        MenuItemViewHolder(View itemView) {
            super(itemView);
            cat_image = itemView.findViewById(R.id.image);

            play = itemView.findViewById(R.id.play);
            download = itemView.findViewById(R.id.download);
            share = itemView.findViewById(R.id.share_download);
            addToPlaylist = itemView.findViewById(R.id.add_to_playlist);
            popupMenu = itemView.findViewById(R.id.popup_menu);
            download_complete=itemView.findViewById(R.id.download_completed);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_desc = itemView.findViewById(R.id.tv_desc);
            tv_duration = itemView.findViewById(R.id.tv_duration);

            layout_main = itemView.findViewById(R.id.layout_main);
            downloadProgress = itemView.findViewById(R.id.download_progress_normal);
            mProgress=itemView.findViewById(R.id.circularProgressbarSong);
            linearLayoutSongDetail=itemView.findViewById(R.id.linearLayputSongDetails);
        }
    }

    private int getAudioIndexFromList(String itemId) {
        int position = 0;
        for (int i = 0; i < mItem.size(); i++) {
            if (mItem.get(i).getItem_id().equals(itemId)) {
                position = i;
                break;
            }
        }
        return position;
    }


    private void deleteSong(ArrayList<SongModel> songList, int position) {
        fileName = songList.get(position).getDownload_name() + ".mp3";
        imageName = songList.get(position).getDownload_name() + ".jpg";
        lyricsPdf= songList.get(position).getDownload_name() + ".pdf";
        lyricsFileName= songList.get(position).getDownload_name();
        Log.d("SONG_PATH", "" + songList.get(position).getItem_file());
        Log.e("DIRECTORY_PATH", Constants.DIRECTORY_PATH);
        File songDir = new File(Constants.DIRECTORY_PATH
                +  Constants.SONG_FOLDER_PATH);
        if (!songDir.exists()) {
            return;
        }

        // Output stream to write file
        File outputFile = new File(songDir, fileName);
        if (outputFile.exists()) {
            boolean deleted = outputFile.delete();
            Log.e("songDeleted", "==" + deleted);
        }



        //delete image file
        File imgDir = new File(Constants.DIRECTORY_PATH +  Constants.IMAGE_FOLDER_PATH);
        if (!imgDir.exists()) {
            return;
        }

        // Output stream to write file
        File file = new File(imgDir, imageName);
        if (file.exists()) {
            boolean deleted = file.delete();
            Log.e("imageDeleted", "==" + deleted);
        }


        //delete image file
        File Lyricespdf = new File(Constants.DIRECTORY_PATH +  Constants.PDF_FOLDER_PATH);
        if (!Lyricespdf.exists()) {
            return;
        }

        // Output stream to write file
        File file2 = new File(Lyricespdf,lyricsPdf);
        if (file2.exists()) {
            boolean deleted = file.delete();
            Log.e("lyricsPdfDeleted", "==" + deleted);
        }


        RealmHelper realmHelper = new RealmHelper();
        Log.e("itemId", songList.get(position).getItem_id());
        realmHelper.deleteSongData(songList.get(position).getItem_id());

        StorageUtil storage = new StorageUtil(getApplicationContext());
        ArrayList<SubCategoryModel> audioList = storage.loadAudio();
        int audioIndex = storage.loadAudioIndex();
        if (audioList != null && audioIndex!=-1) {
            String currentlyPlayingId = audioList.get(audioIndex).getItem_id();
            if (!audioList.get(0).getItem_file().startsWith("https")) { //means not playing from download
                for (SubCategoryModel model:audioList) {
                    String currentSongId = songList.get(position).getItem_id();
                    if (model.getItem_id().equalsIgnoreCase(currentSongId)) {
                        audioList.remove(model);
                        storage.storeAudio(audioList);
                        break;
                    }
                }

                ArrayList<SubCategoryModel> currentQueue = storage.loadAudio();
                for (int i = 0; i < currentQueue.size(); i++) {
                    if (currentQueue.get(i).getItem_id().equals(currentlyPlayingId)) {
                        storage.storeAudioIndex(i);
                        Log.e("New Index == ",String.valueOf(i));
                        break;
                    }
                }
            }
        }
        songList.remove(position);
        notifyDataSetChanged();

    }

}

