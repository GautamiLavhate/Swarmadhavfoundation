package com.applexinfotech.swarmadhavfoundation.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class StorageUtil {

    private final String STORAGE = "com.applex.swarsageetmala.audioplayer.STORAGE";
    private SharedPreferences preferences;
    private final Context context;
    

    public StorageUtil(Context context) {
        this.context = context;
    }

    public void storeAudio(ArrayList<SubCategoryModel> arrayList) {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(arrayList);
        editor.putString("audioArrayList", json);
        editor.apply();
    }

    public ArrayList<SubCategoryModel> loadAudio() {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = preferences.getString("audioArrayList", null);
        Type type = new TypeToken<ArrayList<SubCategoryModel>>() {
        }.getType();
        return gson.fromJson(json, type);
    }

    public void storeAudioIndex(int index) {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("audioIndex", index);
        editor.apply();
    }

    public int loadAudioIndex() {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        return preferences.getInt("audioIndex", -1);//return -1 if no data found
    }

    public void clearCachedAudioPlaylist() {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();
    }

    public void storeMode(int index) {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("mode", index);   //4=fromAssets,3=fromLocalSOngList,2=fromPlaylist,1=fromDownload,0=other
        editor.apply();
    }

    public int loadMode() {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        return preferences.getInt("mode", -1);//return -1 if no data found
    }

    public void storePlayedAudioIndex(int index) {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("PlayedAudioIndex", index);
        editor.apply();
    }

    public int loadPlayedAudioIndex() {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        return preferences.getInt("PlayedAudioIndex", -1);//return -1 if no data found
    }

    public void storeIsPlayingFrom(String index) {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("isPlayingFrom", index);
        editor.apply();
    }

    public String loadIsPlayingFrom() {  //shows currently playing from
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        return preferences.getString("isPlayingFrom", null);//return null if no data found
    }

    public void storeCurrentPlaylistId(int playlistId) {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("playlistId", playlistId);
        editor.apply();
    }

    public int loadCurrentPlaylistId() {
        preferences = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
        return preferences.getInt("playlistId", -1);//return -1 if no data found
    }

}
