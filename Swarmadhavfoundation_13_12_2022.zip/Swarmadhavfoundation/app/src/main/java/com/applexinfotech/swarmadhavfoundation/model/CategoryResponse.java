package com.applexinfotech.swarmadhavfoundation.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CategoryResponse {
    @SerializedName("response_status")
    @Expose
    private Integer response_status;
    @SerializedName("response_message")
    @Expose
    private String response_message;
    @SerializedName("data")
    @Expose
    private ArrayList<HomeModel> data = null;
    @SerializedName("mostPlayed")
    @Expose
    private ArrayList<SubCategoryModel> songData = null;
    @SerializedName("mostDownloaded")
    @Expose
    private ArrayList<SubCategoryModel> mostDownloaded = null;
    @SerializedName("assetSongs")
    @Expose
    private ArrayList<SubCategoryModel> assetSongs = null;

    public Integer getResponse_status() {
        return response_status;
    }

    public void setResponse_status(Integer response_status) {
        this.response_status = response_status;
    }

    public String getResponse_message() {
        return response_message;
    }

    public void setResponse_message(String response_message) {
        this.response_message = response_message;
    }

    public ArrayList<HomeModel> getData() {
        return data;
    }

    public void setData(ArrayList<HomeModel> data) {
        this.data = data;
    }

    public ArrayList<SubCategoryModel> getSongData() {
        return songData;
    }

    public void setSongData(ArrayList<SubCategoryModel> songData) {
        this.songData = songData;
    }

    public ArrayList<SubCategoryModel> getMostDownloaded() {
        return mostDownloaded;
    }

    public void setMostDownloaded(ArrayList<SubCategoryModel> mostDownloaded) {
        this.mostDownloaded = mostDownloaded;
    }

    public ArrayList<SubCategoryModel> getAssetSongs() {
        return assetSongs;
    }

    public void setAssetSongs(ArrayList<SubCategoryModel> assetSongs) {
        this.assetSongs = assetSongs;
    }
}
