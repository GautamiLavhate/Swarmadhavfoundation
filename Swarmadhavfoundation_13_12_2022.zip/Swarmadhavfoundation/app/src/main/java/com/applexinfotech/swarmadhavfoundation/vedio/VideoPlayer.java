package com.applexinfotech.swarmadhavfoundation.vedio;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.StorageUtil;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import tcking.github.com.giraffeplayer2.DefaultMediaController;
import tcking.github.com.giraffeplayer2.DefaultPlayerListener;
import tcking.github.com.giraffeplayer2.GiraffePlayer;
import tcking.github.com.giraffeplayer2.PlayerListener;
import tcking.github.com.giraffeplayer2.VideoInfo;
import tcking.github.com.giraffeplayer2.VideoView;

import static com.applexinfotech.swarmadhavfoundation.common.util.Constants.LOCAL_SONGS;


public class VideoPlayer extends MasterActivity implements OnItemClickListener {

    private VideoView mVideoView;

    String url, videoUrl;
    private Context context;
    private String path;
    int index;
    int isFromDownloads = 0;
    private ArrayList<SubCategoryModel> audioList = new ArrayList<>();
    private int audioIndex;
    private SubCategoryModel activeAudio;
    private int userMode;
    private RecyclerView recyclerPlaylist;
    private FloatingActionButton imagePlaylist, imageClosePlaylist;
    boolean isPlaylistVisible = false;
    private StorageUtil storage;
    private PlaylistVideoplayerAdapter adapter;
    private TextView tvSongName;
    private String isPlayingFrom;

   /* @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
        context = this;
        path = Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH;

        Utilities.hideKeyboard(this);
        mVideoView = (VideoView) findViewById(R.id.video_view);
        recyclerPlaylist = findViewById(R.id.recycler_playlist);
        imagePlaylist = findViewById(R.id.img_playlist);
        imageClosePlaylist = findViewById(R.id.img_close_playlist);
        tvSongName = findViewById(R.id.tv_song_name);

        if (mVideoView != null) {
            mVideoView.setPlayerListener(playerListener);
            DefaultMediaController mediaController = new DefaultMediaController(this);
            // mVideoView.getMediaController().bind(mediaController);
        }

        final FrameLayout mPlayerCollapsed = (FrameLayout) findViewById(R.id.player_col);
        final FrameLayout mPlayerExpanded = (FrameLayout) findViewById(R.id.player_exp);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); //for horizontal scrolling
        recyclerPlaylist.setLayoutManager(mLayoutManager);
        storage = new StorageUtil(getApplicationContext());

        adapter = new PlaylistVideoplayerAdapter(this);
        adapter.setOnItemClickListener(this);
        recyclerPlaylist.setAdapter(adapter);
        audioList = storage.loadAudio();
        adapter.setPlayList(audioList);
        isPlayingFrom=storage.loadIsPlayingFrom();
        final LinearLayout mBottomSheet = (LinearLayout) findViewById(R.id.bottom_sheet);

        mBottomSheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               *//* imagePlaylist.setVisibility(View.VISIBLE);
                tvSongName.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        imagePlaylist.setVisibility(View.GONE);
                        tvSongName.setVisibility(View.GONE);
                    }
                }, 5000);*//*
            }
        });

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        Log.e("height", String.valueOf(height));
        BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(mBottomSheet);
        bottomSheetBehavior.setPeekHeight(height/6);
        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_EXPANDED: {
                        mPlayerCollapsed.setVisibility(View.GONE);
                        mPlayerExpanded.setVisibility(View.VISIBLE);
                    }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {
                        mPlayerCollapsed.setVisibility(View.VISIBLE);
                        mPlayerExpanded.setVisibility(View.GONE);
                    }
                    break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });


        imagePlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPlaylistVisible) {
                    isPlaylistVisible = false;
                    BottomSheetBehavior.from(mBottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    isPlaylistVisible = true;
                    BottomSheetBehavior.from(mBottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                    //recyclerPlaylist.setVisibility(View.VISIBLE);
                }
            }
        });
        imageClosePlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetBehavior.from(mBottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
            }
        });
        playVideo();
    }



    private void playVideo() {
        try {
            //Load data from SharedPreferences
            audioIndex = storage.loadAudioIndex();
            userMode = storage.loadMode();
            if (audioIndex != -1 && audioIndex < audioList.size()) {
                //index is in a valid range
                activeAudio = audioList.get(audioIndex);
                // nextAudioIndex=audioIndex;
            } else {
                return;
            }
        } catch (NullPointerException e) {
            return;
        }
        activeAudio = audioList.get(audioIndex);
        url = activeAudio.getVideo_url();
        if (url != null) {
            if(isPlayingFrom.equalsIgnoreCase(LOCAL_SONGS)){
                Uri intentUri = Uri.parse(url);
                Log.e("LOCAL_SONGS", "playing from LOCAL_SONGS");
                videoUrl = String.valueOf(intentUri);
            }else{
                String file_extn = Utilities.getFileExtension(activeAudio.getVideo_url());
                Log.e("file_extn",file_extn);
                // Output stream to write file
                String fileName = Utilities.getVideoName( activeAudio.getDownload_name() +"."+ file_extn);
                if (isDownloded(fileName)) {
                    String path = Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH + fileName;
                    Uri intentUri = Uri.parse(path);
                    Log.e("FromDownload", "playing from download");
                    videoUrl = String.valueOf(intentUri);
                } else {
                    Log.e("file : ", "==" + activeAudio.getVideo_url());
                    videoUrl = url;
                }
            }


            Log.e("VideoPlayerActivity ", "videoUrl:" + videoUrl);
            if (mVideoView != null) {

                int orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    // In landscape

                    mVideoView.getVideoInfo().setBgColor(Color.TRANSPARENT).setAspectRatio(VideoInfo.AR_MATCH_PARENT);//config player
                    mVideoView.setVideoPath(videoUrl).setFingerprint(audioIndex);
                    mVideoView.getVideoInfo().setShowTopBar(true);
                    mVideoView.getPlayer().start();
                    tvSongName.setText(activeAudio.getDownload_name());
                    adapter.notifyDataSetChanged();
                    if(!isPlayingFrom.equalsIgnoreCase(LOCAL_SONGS))
                    {
                        storeToRecentlyPlayed(activeAudio);
                    }
                } else {
                    // In portrait

                    mVideoView.getVideoInfo().setBgColor(Color.TRANSPARENT).setAspectRatio(VideoInfo.AR_4_3_FIT_PARENT);//config player
                    mVideoView.setVideoPath(videoUrl).setFingerprint(audioIndex);
                    mVideoView.getVideoInfo().setShowTopBar(true);
                    mVideoView.getPlayer().start();
                    tvSongName.setText(activeAudio.getDownload_name());
                    adapter.notifyDataSetChanged();
                    if(!isPlayingFrom.equalsIgnoreCase(LOCAL_SONGS))
                    {
                        storeToRecentlyPlayed(activeAudio);
                    }
                }
            }

        } else {
            Toast.makeText(context, "Something wrong", Toast.LENGTH_SHORT).show();
        }
    }


    private boolean isDownloded(String url) {
        if (fileAlreadyExist(url)) {
            return true;
        } else return false;
    }


    @Override
    public void onBackPressed() {
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().pause();
        }
        super.onBackPressed();
    }

    private PlayerListener playerListener = new DefaultPlayerListener() {//example of using playerListener
        @Override
        public void onPreparing(GiraffePlayer giraffePlayer) {

          *//*  imagePlaylist.setVisibility(View.VISIBLE);
            tvSongName.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    imagePlaylist.setVisibility(View.GONE);
                    tvSongName.setVisibility(View.GONE);
                }
            }, 5000);*//*
            // Toast.makeText(mContext, "start playing:" + giraffePlayer.getVideoInfo().getUri(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCompletion(GiraffePlayer giraffePlayer) {
            /// Toast.makeText(mContext, "play completion:" + giraffePlayer.getVideoInfo().getUri(), Toast.LENGTH_SHORT).show();
            skipToNext();

        }

    };


    @Override
    public void onItemClick(View v, int position, Object o) {
        mVideoView.getPlayer().pause();
        audioIndex = position;
        new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);
        tvSongName.setText(audioList.get(audioIndex).getItem_name());
        adapter.notifyDataSetChanged();
        playVideo();

    }

    @Override
    public void onPause() {
        super.onPause();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().pause();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().stop();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().pause();
            mVideoView.getPlayer().release();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().start();
            mVideoView.setPlayerListener(playerListener);
        }

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        checkOrientation(newConfig);
    }
    private void checkOrientation(Configuration newConfig){
        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.d("OrientationMyApp", "Current Orientation : Landscape");
            if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().aspectRatio(VideoInfo.AR_MATCH_PARENT);
            }
            // Your magic here for landscape mode
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Log.d("OrientationMyApp", "Current Orientation : Portrait");
            if(mVideoView!=null &&   videoUrl != null) {
                mVideoView.getPlayer().aspectRatio(VideoInfo.AR_4_3_FIT_PARENT);
            }
            // Your magic here for portrait mode
        }
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
        context = this;
        path = Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH;

        Utilities.hideKeyboard(this);
        mVideoView = (VideoView) findViewById(R.id.video_view);
        recyclerPlaylist = findViewById(R.id.recycler_playlist);
        imagePlaylist = findViewById(R.id.img_playlist);
        imageClosePlaylist = findViewById(R.id.img_close_playlist);
        tvSongName = findViewById(R.id.tv_song_name);
        if (mVideoView != null) {
            mVideoView.setPlayerListener(playerListener);
            DefaultMediaController mediaController = new DefaultMediaController(this);
            // mVideoView.getMediaController().bind(mediaController);
        }

        final FrameLayout mPlayerCollapsed = (FrameLayout) findViewById(R.id.player_col);
        final FrameLayout mPlayerExpanded = (FrameLayout) findViewById(R.id.player_exp);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); //for horizontal scrolling
        recyclerPlaylist.setLayoutManager(mLayoutManager);
        storage = new StorageUtil(getApplicationContext());

        adapter = new PlaylistVideoplayerAdapter(this);
        adapter.setOnItemClickListener(this);
        recyclerPlaylist.setAdapter(adapter);
        audioList = storage.loadAudio();
        adapter.setPlayList(audioList);
        isPlayingFrom=storage.loadIsPlayingFrom();
        final LinearLayout mBottomSheet = (LinearLayout) findViewById(R.id.bottom_sheet);


       /* mBottomSheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imagePlaylist.setVisibility(View.VISIBLE);
                tvSongName.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        imagePlaylist.setVisibility(View.GONE);
                        tvSongName.setVisibility(View.GONE);
                    }
                }, 5000);
            }
        });*/

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        Log.e("height", String.valueOf(height));
        BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(mBottomSheet);
        bottomSheetBehavior.setPeekHeight(height/6);
        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_EXPANDED: {
                        mPlayerCollapsed.setVisibility(View.GONE);
                        mPlayerExpanded.setVisibility(View.VISIBLE);
                    }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {
                        mPlayerCollapsed.setVisibility(View.VISIBLE);
                        mPlayerExpanded.setVisibility(View.GONE);
                    }
                    break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });

        imagePlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPlaylistVisible) {
                    isPlaylistVisible = false;
                    BottomSheetBehavior.from(mBottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    isPlaylistVisible = true;
                    BottomSheetBehavior.from(mBottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                    //recyclerPlaylist.setVisibility(View.VISIBLE);
                }
            }
        });
        imageClosePlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetBehavior.from(mBottomSheet).setState(BottomSheetBehavior.STATE_COLLAPSED);
            }
        });
        playVideo();
    }
    private void skipToNext() {
        StorageUtil storage = new StorageUtil(getApplicationContext());
        audioList = storage.loadAudio();
        adapter.setPlayList(audioList);
        audioIndex = storage.loadAudioIndex();
        userMode = storage.loadMode();
        isPlayingFrom=storage.loadIsPlayingFrom();
        if (!audioList.isEmpty()) {
            if (audioIndex == audioList.size() - 1) {
                //if last in playlist
                audioIndex = 0;
                storage.storeAudioIndex(audioIndex);
                activeAudio = audioList.get(audioIndex);
            } else {
                //get next in playlist

                audioIndex = ++audioIndex;
                storage.storeAudioIndex(audioIndex);
                activeAudio = audioList.get(audioIndex);
            }

            //Update stored index
            new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);
            playVideo();
        } else {
            Toast.makeText(context, "video play completed", Toast.LENGTH_SHORT).show();
            //finish();

        }
    }

    public void skipToPrevious() {
        StorageUtil storage = new StorageUtil(getApplicationContext());
        audioList = storage.loadAudio();
        audioIndex = storage.loadAudioIndex();
        userMode = storage.loadMode();
        if (!audioList.isEmpty()) {
            if (audioIndex == 0) {
                //if first in playlist
                //set index to the last of audioList
                audioIndex = audioList.size() - 1;
                storage.storeAudioIndex(audioIndex);
                activeAudio = audioList.get(audioIndex);
            } else {
                //get previous in playlist
                audioIndex = --audioIndex;
                storage.storeAudioIndex(audioIndex);
                activeAudio = audioList.get(audioIndex);
            }

            //Update stored index
            new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);
            playVideo();
            Log.e("VideoPlayerActivity ", "url4mlist:" + url);
        } else {
            Toast.makeText(context, "video play completed", Toast.LENGTH_SHORT).show();
            //finish();

        }
    }
    private void playVideo() {
        try {
            //Load data from SharedPreferences
            audioIndex = storage.loadAudioIndex();
            userMode = storage.loadMode();
            if (audioIndex != -1 && audioIndex < audioList.size()) {
                //index is in a valid range
                activeAudio = audioList.get(audioIndex);
                // nextAudioIndex=audioIndex;
            } else {
                return;
            }
        } catch (NullPointerException e) {
            return;
        }
        activeAudio = audioList.get(audioIndex);
        url = activeAudio.getVideo_url();
        if (url != null) {
            if(isPlayingFrom.equalsIgnoreCase(LOCAL_SONGS)){
                Uri intentUri = Uri.parse(url);
                Log.e("LOCAL_SONGS", "playing from LOCAL_SONGS");
                videoUrl = String.valueOf(intentUri);
            }else{
                String file_extn = Utilities.getFileExtension(activeAudio.getVideo_url());
                Log.e("file_extn",file_extn);
                // Output stream to write file
                String fileName = Utilities.getVideoName( activeAudio.getDownload_name() +"."+ file_extn);
                if (isDownloded(fileName)) {
                    String path = Constants.DIRECTORY_PATH + Constants.VIDEO_FOLDER_PATH + fileName;
                    Uri intentUri = Uri.parse(path);
                    Log.e("FromDownload", "playing from download");
                    videoUrl = String.valueOf(intentUri);
                } else {
                    Log.e("file : ", "==" + activeAudio.getVideo_url());
                    videoUrl = url;
                }
            }


            Log.e("VideoPlayerActivity ", "videoUrl:" + videoUrl);
            if (mVideoView != null) {
                mVideoView.getVideoInfo().setBgColor(Color.TRANSPARENT).setAspectRatio(VideoInfo.AR_4_3_FIT_PARENT);//config player
                mVideoView.setVideoPath(videoUrl).setFingerprint(audioIndex);
                mVideoView.getVideoInfo().setShowTopBar(true);
                mVideoView.getPlayer().start();
                tvSongName.setText(activeAudio.getDownload_name());
                adapter.notifyDataSetChanged();
                if(!isPlayingFrom.equalsIgnoreCase(LOCAL_SONGS))
                {
                    storeToRecentlyPlayed(activeAudio);
                }
            }

        } else {
            Toast.makeText(context, "Something wrong", Toast.LENGTH_SHORT).show();
        }
    }


    private boolean isDownloded(String url) {
        if (fileAlreadyExist(url)) {
            return true;
        } else return false;
    }


    @Override
    public void onBackPressed() {
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().pause();
        }
        super.onBackPressed();
    }

    private PlayerListener playerListener = new DefaultPlayerListener() {//example of using playerListener
        @Override
        public void onPreparing(GiraffePlayer giraffePlayer) {
            // Toast.makeText(mContext, "start playing:" + giraffePlayer.getVideoInfo().getUri(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCompletion(GiraffePlayer giraffePlayer) {

            skipToNext();
        }
    };

    @Override
    public void onItemClick(View v, int position, Object o) {
        mVideoView.getPlayer().pause();
        audioIndex = position;
        new StorageUtil(getApplicationContext()).storeAudioIndex(audioIndex);
        tvSongName.setText(audioList.get(audioIndex).getItem_name());
        adapter.notifyDataSetChanged();
        playVideo();

    }

    @Override
    public void onPause() {
        super.onPause();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().pause();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().stop();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().pause();
            mVideoView.getPlayer().release();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mVideoView!=null &&   videoUrl != null) {
            mVideoView.getPlayer().start();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        checkOrientation(newConfig);
    }

    private void checkOrientation(Configuration newConfig){
        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.d("OrientationMyApp", "Current Orientation : Landscape");
            if(mVideoView!=null &&   videoUrl != null) {
                mVideoView.getPlayer().aspectRatio(VideoInfo.AR_MATCH_PARENT);
            }
            // Your magic here for landscape mode
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Log.d("OrientationMyApp", "Current Orientation : Portrait");
            if(mVideoView!=null &&   videoUrl != null) {
                mVideoView.getPlayer().aspectRatio(VideoInfo.AR_4_3_FIT_PARENT);
            }
            // Your magic here for portrait mode
        }
    }
}



