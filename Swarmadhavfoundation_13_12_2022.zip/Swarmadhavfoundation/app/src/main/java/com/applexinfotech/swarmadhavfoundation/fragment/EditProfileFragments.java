package com.applexinfotech.swarmadhavfoundation.fragment;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.AppHelper;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.VolleyMultipartRequest;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static android.app.Activity.RESULT_OK;
import static com.applexinfotech.swarmadhavfoundation.USBActivity.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE;

public class EditProfileFragments extends MasterFragment {
    private MainActivity mContext;
    private TextView titlename;
    private String mContent,Path, mmonth = "",Fiximge;
    private Button save;
    private String textColor,backgroundColor,nameSt,mobileST,emailST,addressST,dobST,picST,user_idST;
    private CircularImageView img_plus,img_profile;
    private SessionManager sessionManager;
    private EditText FullName,Mobilenumber,datebirth;
    private int mYear;
    private int mMonth;
    private int mDay;
    private File destination;
    private static final int PICKFILE_RESULT_CODE = 1;
    private static final int REQUEST_IMAGE = 100;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        return inflater.inflate(R.layout.edit_profile_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

      //  mContext.hideDrawer();
        mContext.showDrawerBack();
        mContext.setTitle("Edit Profile");

        save=view.findViewById(R.id.save);

        img_plus=view.findViewById(R.id.img_plus);
        img_profile=view.findViewById(R.id.img_profile);

        img_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPictureDialog();
            }
        });



        titlename=view.findViewById(R.id.titlename);
        FullName=view.findViewById(R.id.FullName);
        Mobilenumber=view.findViewById(R.id.Mobilenumber);
        datebirth=view.findViewById(R.id.datebirth);
        sessionManager=new SessionManager(getMasterActivity());
        emailST =sessionManager.getKEY_email();
        String ImagePath=sessionManager.getKEY_image();
        Picasso.with(getMasterActivity()).load(ImagePath).into(img_profile);
        titlename.setText(sessionManager.getKEY_name());
        FullName.setText(sessionManager.getKEY_name());
        Mobilenumber.setText(sessionManager.getKEY_mobile());
        datebirth.setText(sessionManager.getKEY_dob());


        datebirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) getMasterActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(Objects.requireNonNull(getMasterActivity().getCurrentFocus()).getWindowToken(), 0);
                Calendar mcurrentDate = Calendar.getInstance();
                mYear = mcurrentDate.get(Calendar.YEAR);
                mMonth = mcurrentDate.get(Calendar.MONTH);
                mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker = new DatePickerDialog(
                        getMasterActivity(), new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker,
                                          int selectedyear, int selectedmonth,
                                          int selectedday) {

                        int month = selectedmonth + 1;

                        if (month == 1) {
                            mmonth = "01";

                        } else if (month == 2) {

                            mmonth = "02";

                        } else if (month == 3) {

                            mmonth = "03";

                        } else if (month == 4) {

                            mmonth = "04";

                        } else if (month == 5) {

                            mmonth = "05";

                        } else if (month == 6) {

                            mmonth = "06";

                        } else if (month == 7) {

                            mmonth = "07";

                        } else if (month == 8) {

                            mmonth = "08";

                        } else if (month == 9) {

                            mmonth = "09";

                        } else if (month == 10) {

                            mmonth = "10";

                        } else if (month == 11) {

                            mmonth = "11";

                        } else if (month == 12) {

                            mmonth = "12";

                        }
                        String a = String.valueOf(selectedday);
                        if (a.length() == 1) {
                            a = "0" + selectedday;
                        }
                        final String dt1 = a+ "/" + mmonth + "/" +selectedyear;
                        datebirth.setText(dt1);

                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select Date");
                mDatePicker.show();
            }
        });


        mContext.isInternet = InternetStatus.isInternetOn(getMasterActivity());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mContext.isInternet) {
                    try {
                        EditPostPrductInfo();
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    ToastUtil.showLongToastMessage(mContext, getString(R.string.no_internet_connection_found));
                }

            }
        });

        textColor=getResources().getString(R.color.primaryTextColor).substring(3);
        backgroundColor=getResources().getString(R.color.colorPrimary).substring(3);
        //Log.e("textColor",textColor +"& backgroundColor="+backgroundColor);
        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

    }


    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
        } else {
            showPictureDialog();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showPictureDialog();
            } else {
                checkPermission();
                Toast.makeText(mContext, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void showPictureDialog() {

        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(getActivity());
        pictureDialog.setTitle("Select Action");
        final CharSequence[] pictureDialogItems = {"Remove Photo","Take Photo","Choose from Gallery"};
        pictureDialog.setItems(pictureDialogItems, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case 0:
                        Picasso.with(mContext).load(R.drawable.ic_profile_edit).into(img_profile);
                        break;
                    case 1:
                        TakePhotoFromCamera();
                        break;
                    case 2:
                        ChoosePhotoFromGallery();
                        break;
                }
            }
        });
        pictureDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        pictureDialog.show();
    }

    private void ChoosePhotoFromGallery() {

        Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent,PICKFILE_RESULT_CODE);
    }
    private void TakePhotoFromCamera() {

        Intent it=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(it,REQUEST_IMAGE);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICKFILE_RESULT_CODE && resultCode == RESULT_OK && data != null) {

            String uri1=data.getData().getPath();
            Uri uri=data.getData();
            try
            {
                Bitmap bitmap=MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(),uri);
                img_profile.setImageBitmap(bitmap);
                String partFilename = currentDateFormat();
                Path=data.getData().getPath()+"_"+partFilename;
            }catch (IOException e){
                e.printStackTrace();
            }

        } else if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data != null) {

            Bitmap bitmap = (Bitmap) data.getExtras().get("data");

            String partFilename = currentDateFormat();
            storeCameraPhotoInSDCard(bitmap, partFilename);
            String storeFilename = "photo_" + partFilename;
            Bitmap mBitmap = getImageFileFromSDCard(storeFilename);
            Path = destination.getAbsolutePath();
            img_profile.setImageBitmap(bitmap);
        }
    }
    private String currentDateFormat(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HH_mm_ss");
        String  currentTimeStamp = dateFormat.format(new Date());
        return currentTimeStamp;
    }

    private void storeCameraPhotoInSDCard(Bitmap bitmap, String currentDate){
        File outputFile = new File(Environment.getExternalStorageDirectory(), "photo_" + currentDate);
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private Bitmap getImageFileFromSDCard(String filename){
        Bitmap bitmap = null;
        destination = new File(Environment.getExternalStorageDirectory() + filename);
        try {
            FileInputStream fis = new FileInputStream(destination);
            bitmap = BitmapFactory.decodeStream(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    //multipart
    public void EditPostPrductInfo() {

        mContext.showWaitIndicator(true);
        String url = Constants.API_update_user;
        VolleyMultipartRequest multipartRequest = new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                mContext.showWaitIndicator(false);
             //   sessionManager.UpdateKEY_name(nameSt);
                Toast.makeText(getMasterActivity(), " Save", Toast.LENGTH_LONG).show();
                mContext.onBackPressed();
               /* try {
                    JSONObject jObject = new JSONObject(response.toString());
                    mContext.onBackPressed();
                   *//* String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        Toast.makeText(getMasterActivity(), " Save", Toast.LENGTH_LONG).show();
                        mContext.onBackPressed();
                    } else {
                        Toast.makeText(getMasterActivity(), "No Data Save", Toast.LENGTH_LONG).show();
                        mContext.showWaitIndicator(false);
                    }*//*
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mContext.showWaitIndicator(false);
                NetworkResponse networkResponse = error.networkResponse;
                String errorMessage = "Unknown error";
                if (networkResponse == null) {
                    if (error.getClass().equals(TimeoutError.class)) {
                        errorMessage = "Request timeout";
                    } else if (error.getClass().equals(NoConnectionError.class)) {
                        errorMessage = "Failed to connect server";
                    }
                } else {
                    String result = new String(networkResponse.data);
                    try {
                        JSONObject response = new JSONObject(result);
                        String status = response.getString("status");
                        String message = response.getString("message");

                        Log.e("Error Status", status);
                        Log.e("Error Message", message);

                        if (networkResponse.statusCode == 404) {
                            errorMessage = "Resource not found";
                        } else if (networkResponse.statusCode == 401) {
                            errorMessage = message+" Please login again";
                        } else if (networkResponse.statusCode == 400) {
                            errorMessage = message+ " Check your inputs";
                        } else if (networkResponse.statusCode == 500) {
                            errorMessage = message+" Something is getting wrong";
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Log.i("Error", errorMessage);
                error.printStackTrace();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();


                nameSt = FullName.getText().toString().trim();
                mobileST = Mobilenumber.getText().toString().trim();
                addressST = sessionManager.getKEY_address();
                dobST = datebirth.getText().toString().trim();
                user_idST=sessionManager.getKEY_Userid();
                picST = Path;

              //  emailST =sessionManager.getKEY_email();

                if(picST==null){
                    Fiximge=sessionManager.getKEY_image();
                }else {
                    Fiximge=picST;
                }


                params.put("user_id",user_idST);
                params.put("name", nameSt);
                params.put("mobile", mobileST);
                params.put("email", emailST);
                params.put("address", addressST);
                params.put("dob", dobST);
                params.put("pic",Fiximge);

                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                // file name could found file base or direct access from real path
                // for now just get bitmap data from ImageView
                String filename=Path+".jpg";
                params.put("pic", new DataPart(filename, AppHelper.getFileDataFromDrawable(getMasterActivity(), img_profile.getDrawable()), "image/png"));
                return params;
            }
        };

        Volley.newRequestQueue(getMasterActivity()).add(multipartRequest);

    }
}
