package com.applexinfotech.swarmadhavfoundation.vedio;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.applexinfotech.swarmadhavfoundation.MainActivity;
import com.applexinfotech.swarmadhavfoundation.R;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterActivity;
import com.applexinfotech.swarmadhavfoundation.common.ui.MasterFragment;
import com.applexinfotech.swarmadhavfoundation.common.util.Constants;
import com.applexinfotech.swarmadhavfoundation.common.util.InternetStatus;
import com.applexinfotech.swarmadhavfoundation.common.util.NetworkRequest;
import com.applexinfotech.swarmadhavfoundation.common.util.SessionManager;
import com.applexinfotech.swarmadhavfoundation.common.util.ToastUtil;
import com.applexinfotech.swarmadhavfoundation.common.util.Utilities;
import com.applexinfotech.swarmadhavfoundation.helpers.DownloadListener;
import com.applexinfotech.swarmadhavfoundation.helpers.OnItemClickListener;
import com.applexinfotech.swarmadhavfoundation.helpers.RealmHelper;
import com.applexinfotech.swarmadhavfoundation.model.SongModel;
import com.applexinfotech.swarmadhavfoundation.model.SubCategoryModel;
import com.applexinfotech.swarmadhavfoundation.model.SubHomeCategory;
import com.google.android.gms.ads.InterstitialAd;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.applexinfotech.swarmadhavfoundation.fragment.HomeFragment.hideKeyboard;

public class SubCategoryVideoSongFragment extends MasterFragment implements DownloadListener, OnItemClickListener<SubCategoryModel> {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    MainActivity mContext;
    public static ArrayList<SubCategoryModel> CatListItem = new ArrayList<SubCategoryModel>();
    ArrayList<Object> categoryListWIthAd = new ArrayList<Object>();
    private SubHomeCategory homeModel = new SubHomeCategory();
    private RecyclerView mCategoryList;
    private String category_id,SubCatname,Catgorymainid,user_id;
    private Bundle bundle;
    public SubCategoryVideoSongAdapter Adapter;
    InterstitialAd interstitial;
    private int overflowcounter = 0;
    private LinearLayout noSongFoundView;

    public ArrayList<SubCategoryModel> mItem = new ArrayList<SubCategoryModel>();
    public String lastSearchedString = "";
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    private TextView textenofound;
    private LinearLayout Linerlayourserach;
    private EditText search;
    SessionManager sessionManager;


    public static SubCategoryVideoSongFragment newInstance(String param1, String param2) {
        SubCategoryVideoSongFragment fragment = new SubCategoryVideoSongFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = (MainActivity) getMasterActivity();
        ((MainActivity) getActivity()).setDownloadStateListener(this);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_category, container, false);
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //mContext.hideDrawer();
        mContext.showDrawerBack();

        mContext.setTitle(getString(R.string.play_video_or_download));
        mCategoryList = (RecyclerView) view.findViewById(R.id.listView_cat_list);
        noSongFoundView = view.findViewById(R.id.noItemFound);
        linearLayoutManager = new LinearLayoutManager(mContext);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeToRefresh);
        textenofound = view.findViewById(R.id.textenofound);
        textenofound.setText("No Video Found !!");

        Linerlayourserach= view.findViewById(R.id.Linerlayourserach);
        Linerlayourserach.setVisibility(View.VISIBLE);
        search=(EditText) view.findViewById(R.id.search);
        search.setHint("Search Video ..");
        sessionManager=new SessionManager(getMasterActivity());
        user_id=sessionManager.getKEY_Userid();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    Log.e("server request data", "=");
                    getCategory();

                } else {
                    getDataFromRealm();
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        bundle = getArguments();

        if (bundle != null) {
            homeModel = (SubHomeCategory) bundle.getSerializable("SubCAT_ID");
            category_id = homeModel.getAudio_subcategory_id();
            SubCatname = homeModel.getAudio_subcategory_name();
            Catgorymainid = homeModel.getCategory_id();
        }

        mContext.setTitle(SubCatname+" "+getString(R.string.set_title));



        isInternet = InternetStatus.isInternetOn(mContext);


        mContext.drawer_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.onBackPressed();
            }
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        hideKeyboard(mContext);
                        getCategory();
                    }
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.equals("")) {
                        hideKeyboard(mContext);
                        getCategory();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    if (s.length()>0){
                        mCategoryList.setAdapter(null);
                        getAudioSearch(s.toString());
                    }else{
                        hideKeyboard(mContext);
                        mCategoryList.setAdapter(null);
                        getCategory();
                    }
                }
            }

        });


    }

    private void getDataFromRealm() {
        categoryListWIthAd = new ArrayList<>();
        RealmHelper realmHelper = new RealmHelper();
        ArrayList<SongModel> songList = realmHelper.retrieveSongListByCategory(category_id);
        if (songList != null) {
            Collections.sort(songList, new Comparator<SongModel>() {
                public int compare(SongModel v1, SongModel v2) {
                    return v1.getItem_name().toLowerCase().compareTo(v2.getItem_name().toLowerCase());
                }
            });
            if (songList.size() > 0) {
                for (int i = 0; i < songList.size(); i++) {
                    SubCategoryModel subCategoryModel = new SubCategoryModel();
                    subCategoryModel.setItem_id(songList.get(i).getItem_id());
                    subCategoryModel.setItem_name(songList.get(i).getItem_name());
                    subCategoryModel.setItem_image(songList.get(i).getItem_image());
                    subCategoryModel.setItem_file(songList.get(i).getItem_file());
                    subCategoryModel.setItem_description(songList.get(i).getItem_description());
                    subCategoryModel.setDownload_name(songList.get(i).getDownload_name());
                    subCategoryModel.setCategory_id(songList.get(i).getCategory_id());
                    subCategoryModel.setCategory_name(songList.get(i).getCategory_name());
                    subCategoryModel.setCategory_image(songList.get(i).getCategory_image());
                    subCategoryModel.setVideo_url(songList.get(i).getVideo_url());
                    subCategoryModel.setTypeHm(songList.get(i).getTypeHm());
                    subCategoryModel.setUpdate_count(songList.get(i).getUpdate_count());
                    categoryListWIthAd.add(subCategoryModel);
                }
                setAdapterData();
            }
        }
    }

    private void getCategory() {
        mContext.showWaitIndicator(true);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<NameValuePair>(1);
        carData.add(new BasicNameValuePair(
                Constants.subcategory_id, category_id));
        carData.add(new BasicNameValuePair(
                Constants.user_ID,user_id));
        dishRequest.sendRequest(Constants.API_Subcategories_Vidio_Song_list,
                carData, catCallback);
    }


    NetworkRequest.NetworkRequestCallback catCallback = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {
            Log.d("SUBCATEGORY_API ", "" + response.toString());
            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.getString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        CatListItem = new ArrayList<SubCategoryModel>();
                        categoryListWIthAd = new ArrayList<>();
                        JSONObject data = jObject.getJSONObject("data");
                        JSONArray audio_list= data.getJSONArray("video_list");
                        Log.d("data.length()", "" + data.length());

                        for (int i = 0; i < audio_list.length(); i++) {
                            SubCategoryModel categoryModel = new SubCategoryModel();
                            categoryModel.setItem_id(audio_list.getJSONObject(i).getString("video_id"));
                            categoryModel.setIs_accesible(audio_list.getJSONObject(i).getString("is_accessible"));
                            //String accesible=audio_list.getJSONObject(i).getString("is_accessible");
                            //Toast.makeText(mContext,accesible,Toast.LENGTH_LONG).show();
                            categoryModel.setItem_name(audio_list.getJSONObject(i).getString("video_title"));
                            categoryModel.setItem_description(audio_list.getJSONObject(i).getString("video_description"));
                            categoryModel.setItem_file(audio_list.getJSONObject(i).getString("video_file"));
                            categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                            categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("video_title"));
                            categoryModel.setVideo_url(audio_list.getJSONObject(i).optString("video_file"));
                            categoryModel.setUpdate_count(audio_list.getJSONObject(i).getString("update_count"));
                            CatListItem.add(categoryModel);
                            categoryListWIthAd.add(categoryModel);

                        }

                        showListView(true);
                        mContext.bundle.putSerializable(category_id, CatListItem);
                        setAdapterData();

                    } else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        loadCategoryData();
    }

    private void loadCategoryData() {
        if (InternetStatus.isInternetOn(getMasterActivity())) {
            if (mContext.bundle.containsKey(category_id)) {
                CatListItem = new ArrayList<SubCategoryModel>();
                CatListItem = (ArrayList<SubCategoryModel>) mContext.bundle.getSerializable(category_id);
                categoryListWIthAd = new ArrayList<>();
                categoryListWIthAd.addAll(CatListItem);
                setAdapterData();
                Log.e("existing data", "=");
            } else {
                if (InternetStatus.isInternetOn(getMasterActivity())) {
                    Log.e("server request data", "=");
                    getCategory();
                }
            }
        } else {

            getDataFromRealm();
        }
    }


    public void showListView(boolean flag) {
        if (flag) {
            mCategoryList.setVisibility(View.VISIBLE);
            noSongFoundView.setVisibility(View.GONE);

        } else {
            mCategoryList.setVisibility(View.GONE);
            noSongFoundView.setVisibility(View.VISIBLE);

        }
    }


    @Override
    public void onStop() {
        super.onStop();
        Utilities.hideKeyboard(getMasterActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Utilities.hideKeyboard(getMasterActivity());
    }

    // Do Search...
    public void setAdapterData() {

        // Notify the List that the DataSet has changed...
        if (categoryListWIthAd.isEmpty()) {
            showListView(false);
        } else {
            showListView(true);
            Adapter = new SubCategoryVideoSongAdapter(mContext,categoryListWIthAd, homeModel, SubCategoryVideoSongFragment.this.getClass().getCanonicalName());
            mCategoryList.setAdapter(Adapter);
            mCategoryList.setLayoutManager(linearLayoutManager);
            Adapter.setOnItemClickListener(SubCategoryVideoSongFragment.this);
            Adapter.notifyDataSetChanged();
        }
    }

    //Downloading Service calls and receiver methods
    @Override
    public void onItemClick(View v, int position, SubCategoryModel selectedObject) {
        if (v.getId() == R.id.download) {
            boolean isInternet = InternetStatus.isInternetOn(mContext);
            if (isInternet) {
                downloadQueue(selectedObject, position);
            } else {
                ToastUtil.showLongToastMessage(mContext, mContext.getString(R.string.no_internet_connection_found));
                return;
            }
        }
    }

    public void downloadQueue(SubCategoryModel subCategoryModel, int position) {
        if (MasterActivity.downloadServiceBound) {
            if (MasterActivity.downloadService != null) {
                MasterActivity.downloadService.startDownloading(subCategoryModel, position);
            }
        }
    }


    @Override
    public void onDownloadsBroadcastUpdate(SubCategoryModel tmpInfo, int position) {
        if (SubCategoryVideoSongFragment.this.isVisible()) {
            if (tmpInfo == null || position == -1) {
                return;
            }
            final int status = tmpInfo.getStatus();
            switch (status) {
                case SubCategoryModel.STATUS_COMPLETE:
                    if (Adapter != null) {
                        Log.e("CategoryFragment", "notified");
                        Adapter.notifyDataSetChanged();
                    }
                    break;
            }
        }
        //Downloading Service calls and receiver methods ends
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void getAudioSearch(String catergor) {
        mContext.showWaitIndicator(false);
        NetworkRequest dishRequest = new NetworkRequest(getMasterActivity());
        List<NameValuePair> carData = new ArrayList<>(1);
        carData.add(new BasicNameValuePair(Constants.title, catergor));
        carData.add(new BasicNameValuePair(Constants.CATEGORY_ID, Catgorymainid));
        carData.add(new BasicNameValuePair(Constants.subcategory_id, category_id));
        dishRequest.sendRequest(Constants.API_Video_search,
                carData, catCallbackSearch);
    }

    private final NetworkRequest.NetworkRequestCallback catCallbackSearch = new NetworkRequest.NetworkRequestCallback() {
        @Override
        public void OnNetworkResponseReceived(JSONObject response) {

            mContext.showWaitIndicator(false);
            try {
                if (response != null) {
                    JSONObject jObject = new JSONObject(response.toString());
                    String status = jObject.optString("response_status");
                    if (status.equalsIgnoreCase("1")) {
                        CatListItem = new ArrayList<>();
                        categoryListWIthAd = new ArrayList<>();
                        JSONArray audio_list= jObject.getJSONArray("data");
                        Log.d("data.length()", "" + audio_list.length());

                        for (int i = 0; i < audio_list.length(); i++) {
                            SubCategoryModel categoryModel = new SubCategoryModel();
                            categoryModel.setItem_id(audio_list.getJSONObject(i).getString("video_id"));
                            categoryModel.setItem_name(audio_list.getJSONObject(i).getString("video_title"));
                            categoryModel.setItem_description(audio_list.getJSONObject(i).getString("video_description"));
                            categoryModel.setItem_file(audio_list.getJSONObject(i).getString("video_file"));
                            categoryModel.setItem_image(audio_list.getJSONObject(i).getString("front_cover"));
                            categoryModel.setDownload_name(audio_list.getJSONObject(i).getString("video_title"));
                            categoryModel.setVideo_url(audio_list.getJSONObject(i).optString("video_file"));
                            categoryModel.setUpdate_count(audio_list.getJSONObject(i).getString("update_count"));
                            CatListItem.add(categoryModel);
                            categoryListWIthAd.add(categoryModel);
                        }

                        showListView(true);
                        mContext.bundle.putSerializable(category_id, CatListItem);
                        setAdapterData();


                    } else if (status.equalsIgnoreCase("0")) {
                        showListView(false);
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
                mContext.showWaitIndicator(false);
            }
        }

        @Override
        public void OnNetworkErrorReceived(String error) {
            mContext.showWaitIndicator(false);
        }
    };
}
